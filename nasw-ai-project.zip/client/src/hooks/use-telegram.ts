import { useState, useEffect } from 'react';
import { telegramWebApp } from '../lib/telegram';
import type { TelegramUser } from '../types';

interface UseTelegramReturn {
  user: TelegramUser | null;
  initData: string;
  isAvailable: boolean;
  isLoading: boolean;
  showAlert: (message: string, callback?: () => void) => void;
  showConfirm: (message: string, callback?: (confirmed: boolean) => void) => void;
  hapticFeedback: (type: 'light' | 'medium' | 'heavy' | 'success' | 'error' | 'warning' | 'selection') => void;
  setMainButton: (text: string, onClick: () => void, options?: any) => void;
  hideMainButton: () => void;
  setBackButton: (onClick: () => void, isVisible?: boolean) => void;
  hideBackButton: () => void;
  sendData: (data: any) => void;
  close: () => void;
}

export function useTelegram(): UseTelegramReturn {
  const [user, setUser] = useState<TelegramUser | null>(null);
  const [initData, setInitData] = useState<string>('');
  const [isAvailable, setIsAvailable] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Wait for Telegram WebApp to be available
    const checkTelegram = () => {
      if (telegramWebApp.isAvailable()) {
        setIsAvailable(true);
        setUser(telegramWebApp.getUser());
        setInitData(telegramWebApp.getInitData());
      } else {
        // Fallback for development
        setIsAvailable(false);
        setUser(null);
        setInitData('');
      }
      setIsLoading(false);
    };

    // Check immediately
    checkTelegram();

    // Also check after a short delay in case the script is still loading
    const timer = setTimeout(checkTelegram, 100);

    return () => clearTimeout(timer);
  }, []);

  return {
    user,
    initData,
    isAvailable,
    isLoading,
    showAlert: telegramWebApp.showAlert.bind(telegramWebApp),
    showConfirm: telegramWebApp.showConfirm.bind(telegramWebApp),
    hapticFeedback: telegramWebApp.hapticFeedback.bind(telegramWebApp),
    setMainButton: telegramWebApp.setMainButton.bind(telegramWebApp),
    hideMainButton: telegramWebApp.hideMainButton.bind(telegramWebApp),
    setBackButton: telegramWebApp.setBackButton.bind(telegramWebApp),
    hideBackButton: telegramWebApp.hideBackButton.bind(telegramWebApp),
    sendData: telegramWebApp.sendData.bind(telegramWebApp),
    close: telegramWebApp.close.bind(telegramWebApp),
  };
}
