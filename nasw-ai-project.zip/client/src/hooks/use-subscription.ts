import { useState, useEffect } from 'react';
import { useTelegram } from './use-telegram';

interface UseSubscriptionReturn {
  isSubscribed: boolean;
  isLoading: boolean;
  checkSubscription: () => Promise<void>;
  channelUrl: string;
}

const REQUIRED_CHANNEL_ID = '-1002758240616';
const CHANNEL_URL = 'https://t.me/naswai_official'; // замените на реальный URL канала

export function useSubscription(): UseSubscriptionReturn {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { user, isAvailable } = useTelegram();

  const checkSubscription = async () => {
    if (!user?.id || !isAvailable) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    
    try {
      // Отправляем запрос на сервер для проверки подписки
      const response = await fetch('/api/check-subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          telegramId: user.id.toString(),
          channelId: REQUIRED_CHANNEL_ID
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setIsSubscribed(data.isSubscribed);
      } else {
        // Fallback: считаем что пользователь подписан если не можем проверить
        setIsSubscribed(true);
      }
    } catch (error) {
      console.error('Error checking subscription:', error);
      // Fallback: считаем что пользователь подписан если произошла ошибка
      setIsSubscribed(true);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkSubscription();
  }, [user?.id, isAvailable]);

  return {
    isSubscribed,
    isLoading,
    checkSubscription,
    channelUrl: CHANNEL_URL
  };
}