import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useMutation } from '@tanstack/react-query';
import { GlassCard } from '../ui/glass-card';
import { GlassButton } from '../ui/glass-button';
import { useAppStore } from '../../store/app-store';
import { useTelegram } from '../../hooks/use-telegram';
import { api, invalidateTickets } from '../../lib/api';
import { useToast } from '@/hooks/use-toast';

interface TicketModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TicketModal({ isOpen, onClose }: TicketModalProps) {
  const { user, addTicket } = useAppStore();
  const { hapticFeedback, showAlert } = useTelegram();
  const { toast } = useToast();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);

  const createTicketMutation = useMutation({
    mutationFn: () => api.createTicket(user?.telegramId || '', {
      title,
      description,
      attachments,
    }),
    onSuccess: (data) => {
      addTicket(data.ticket);
      invalidateTickets(user?.telegramId || '');
      hapticFeedback('success');
      
      toast({
        title: "Тикет создан",
        description: "Мы рассмотрим вашу заявку в ближайшее время",
      });
      
      // Reset form and close modal
      setTitle('');
      setDescription('');
      setAttachments([]);
      onClose();
    },
    onError: (error) => {
      hapticFeedback('error');
      showAlert(`Ошибка создания тикета: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim() || !description.trim()) {
      showAlert('Заполните все обязательные поля');
      return;
    }

    createTicketMutation.mutate();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setAttachments(prev => [...prev, ...files]);
    hapticFeedback('light');
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
    hapticFeedback('light');
  };

  const handleClose = () => {
    hapticFeedback('light');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={handleClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-md max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <GlassCard className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">Создать тикет</h3>
              <button
                onClick={handleClose}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                </svg>
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Title */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Тема <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-dark-accent text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-purple-primary"
                  placeholder="Краткое описание проблемы"
                  disabled={createTicketMutation.isPending}
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Описание <span className="text-red-400">*</span>
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-dark-accent text-white p-3 rounded-lg border border-gray-600 h-32 resize-none focus:outline-none focus:ring-2 focus:ring-purple-primary"
                  placeholder="Подробное описание проблемы..."
                  disabled={createTicketMutation.isPending}
                />
              </div>

              {/* File Upload */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Прикрепить файлы
                </label>
                <div className="space-y-2">
                  <label className="glass-button bg-glass-white p-4 rounded-lg border-2 border-dashed border-gray-600 text-center cursor-pointer hover:border-purple-primary transition-colors block">
                    <input
                      type="file"
                      multiple
                      accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.txt"
                      onChange={handleFileChange}
                      className="hidden"
                      disabled={createTicketMutation.isPending}
                    />
                    <svg className="w-8 h-8 mx-auto mb-2 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z"/>
                    </svg>
                    <p className="text-sm text-gray-400">Нажмите для выбора файлов</p>
                    <p className="text-xs text-gray-500 mt-1">
                      Изображения, видео, аудио, документы
                    </p>
                  </label>

                  {/* Attached Files */}
                  {attachments.length > 0 && (
                    <div className="space-y-2">
                      {attachments.map((file, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="flex items-center justify-between p-2 bg-dark-accent rounded-lg"
                        >
                          <div className="flex items-center space-x-2">
                            <svg className="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z"/>
                            </svg>
                            <span className="text-sm text-gray-300 truncate">
                              {file.name}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeAttachment(index)}
                            className="text-red-400 hover:text-red-300 transition-colors"
                            disabled={createTicketMutation.isPending}
                          >
                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                            </svg>
                          </button>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Priority Selection */}
              <div>
                <label className="block text-sm font-medium mb-2">Приоритет</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: 'low', label: 'Низкий', color: 'text-gray-400' },
                    { value: 'medium', label: 'Средний', color: 'text-yellow-400' },
                    { value: 'high', label: 'Высокий', color: 'text-red-400' },
                  ].map((priority) => (
                    <label key={priority.value} className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="priority"
                        value={priority.value}
                        defaultChecked={priority.value === 'medium'}
                        className="text-purple-primary focus:ring-purple-primary"
                        disabled={createTicketMutation.isPending}
                      />
                      <span className={`text-sm ${priority.color}`}>
                        {priority.label}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex space-x-3 pt-4">
                <GlassButton
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={handleClose}
                  disabled={createTicketMutation.isPending}
                >
                  Отмена
                </GlassButton>
                <GlassButton
                  type="submit"
                  variant="gradient"
                  className="flex-1"
                  disabled={createTicketMutation.isPending || !title.trim() || !description.trim()}
                >
                  {createTicketMutation.isPending ? (
                    <div className="flex items-center space-x-2">
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                      <span>Создаю...</span>
                    </div>
                  ) : (
                    'Создать'
                  )}
                </GlassButton>
              </div>
            </form>
          </GlassCard>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
