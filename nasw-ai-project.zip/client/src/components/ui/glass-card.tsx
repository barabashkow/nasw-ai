import React from 'react';
import { cn } from '@/lib/utils';

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'purple' | 'blue' | 'green';
}

export function GlassCard({ 
  className, 
  variant = 'default', 
  children, 
  ...props 
}: GlassCardProps) {
  const variants = {
    default: 'bg-white/10 border-white/20',
    purple: 'bg-purple-500/20 border-purple-400/30',
    blue: 'bg-blue-500/20 border-blue-400/30',
    green: 'bg-green-500/20 border-green-400/30',
  };

  return (
    <div
      className={cn(
        'backdrop-blur-xl border rounded-2xl shadow-xl',
        'hover:bg-white/15 transition-all duration-300',
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}