import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageCircle, 
  Send, 
  Paperclip, 
  Mic, 
  Camera,
  Clock,
  CheckCircle,
  AlertCircle,
  User,
  Bot,
  Plus
} from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import type { Language } from '../lib/i18n';
import { GlassCard } from '@/components/ui/glass-card';
import { GlassButton } from '@/components/ui/glass-button';

interface TicketSystemProps {
  language: Language;
  userId: string;
}

interface TicketMessage {
  id: string;
  content: string;
  type: 'text' | 'voice' | 'image' | 'video';
  sender: 'user' | 'support';
  timestamp: Date;
  status?: 'sending' | 'sent' | 'read';
}

interface Ticket {
  id: string;
  subject: string;
  status: 'open' | 'in_progress' | 'resolved';
  priority: 'low' | 'medium' | 'high';
  createdAt: Date;
  messages: TicketMessage[];
}

export function TicketSystem({ language, userId }: TicketSystemProps) {
  const { t } = useTranslation(language);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [currentTicket, setCurrentTicket] = useState<Ticket | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [isCreatingTicket, setIsCreatingTicket] = useState(false);
  const [newTicketSubject, setNewTicketSubject] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  // Simulate loading existing tickets
  useEffect(() => {
    // In real implementation, this would fetch from API
    const mockTickets: Ticket[] = [
      // Example: existing ticket
    ];
    setTickets(mockTickets);
  }, []);

  const createNewTicket = async () => {
    if (!newTicketSubject.trim()) return;

    const newTicket: Ticket = {
      id: Date.now().toString(),
      subject: newTicketSubject,
      status: 'open',
      priority: 'medium',
      createdAt: new Date(),
      messages: []
    };

    setTickets(prev => [...prev, newTicket]);
    setCurrentTicket(newTicket);
    setIsCreatingTicket(false);
    setNewTicketSubject('');
  };

  const sendMessage = async (content: string, type: 'text' | 'voice' | 'image' | 'video' = 'text') => {
    if (!currentTicket || !content.trim()) return;

    const message: TicketMessage = {
      id: Date.now().toString(),
      content,
      type,
      sender: 'user',
      timestamp: new Date(),
      status: 'sending'
    };

    const updatedTicket = {
      ...currentTicket,
      messages: [...currentTicket.messages, message]
    };

    setCurrentTicket(updatedTicket);
    setTickets(prev => prev.map(t => t.id === currentTicket.id ? updatedTicket : t));
    setNewMessage('');

    // Simulate message being sent
    setTimeout(() => {
      const sentMessage = { ...message, status: 'sent' as const };
      const finalTicket = {
        ...updatedTicket,
        messages: updatedTicket.messages.map(m => m.id === message.id ? sentMessage : m)
      };
      setCurrentTicket(finalTicket);
      setTickets(prev => prev.map(t => t.id === currentTicket.id ? finalTicket : t));

      // Simulate auto-reply from support
      setTimeout(() => {
        const supportReply: TicketMessage = {
          id: (Date.now() + 1).toString(),
          content: 'Спасибо за обращение! Наш специалист скоро ответит на ваш вопрос.',
          type: 'text',
          sender: 'support',
          timestamp: new Date(),
          status: 'sent'
        };

        const replyTicket = {
          ...finalTicket,
          messages: [...finalTicket.messages, supportReply],
          status: 'in_progress' as const
        };

        setCurrentTicket(replyTicket);
        setTickets(prev => prev.map(t => t.id === currentTicket.id ? replyTicket : t));
      }, 2000);
    }, 1000);
  };

  const getStatusIcon = (status: Ticket['status']) => {
    switch (status) {
      case 'open': return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'in_progress': return <AlertCircle className="w-4 h-4 text-blue-400" />;
      case 'resolved': return <CheckCircle className="w-4 h-4 text-green-400" />;
    }
  };

  const getStatusText = (status: Ticket['status']) => {
    switch (status) {
      case 'open': return 'Открыт';
      case 'in_progress': return 'В работе';
      case 'resolved': return 'Решён';
    }
  };

  if (currentTicket) {
    return (
      <div className="flex flex-col h-full">
        {/* Ticket Header */}
        <GlassCard className="p-4 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-white font-semibold">{currentTicket.subject}</h2>
              <div className="flex items-center space-x-2 mt-1">
                {getStatusIcon(currentTicket.status)}
                <span className="text-white/60 text-sm">{getStatusText(currentTicket.status)}</span>
              </div>
            </div>
            <GlassButton
              size="sm"
              variant="secondary"
              onClick={() => setCurrentTicket(null)}
            >
              Назад
            </GlassButton>
          </div>
        </GlassCard>

        {/* Messages */}
        <div className="flex-1 space-y-4 mb-4 overflow-y-auto">
          <AnimatePresence>
            {currentTicket.messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[80%] ${message.sender === 'user' ? 'order-1' : 'order-2'}`}>
                  <GlassCard 
                    className={`p-3 ${
                      message.sender === 'user' 
                        ? 'bg-purple-500/20 border-purple-400/30' 
                        : 'bg-blue-500/20 border-blue-400/30'
                    }`}
                  >
                    <div className="flex items-start space-x-2">
                      {message.sender === 'support' ? (
                        <Bot className="w-5 h-5 text-blue-400 mt-0.5" />
                      ) : (
                        <User className="w-5 h-5 text-purple-400 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <p className="text-white text-sm">{message.content}</p>
                        <div className="flex items-center justify-between mt-2">
                          <p className="text-white/40 text-xs">
                            {message.timestamp.toLocaleTimeString()}
                          </p>
                          {message.sender === 'user' && (
                            <div className="flex items-center space-x-1">
                              {message.status === 'sending' && (
                                <div className="w-3 h-3 border border-white/30 border-t-white rounded-full animate-spin" />
                              )}
                              {message.status === 'sent' && (
                                <CheckCircle className="w-3 h-3 text-green-400" />
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </GlassCard>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Message Input */}
        <GlassCard className="p-4">
          <div className="flex items-center space-x-2">
            <div className="flex-1 relative">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Введите сообщение..."
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/50 focus:border-purple-400 focus:outline-none"
                onKeyPress={(e) => e.key === 'Enter' && sendMessage(newMessage)}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <GlassButton
                size="sm"
                variant="secondary"
                onClick={() => {/* Handle file attachment */}}
              >
                <Paperclip className="w-4 h-4" />
              </GlassButton>
              
              <GlassButton
                size="sm"
                variant="secondary"
                onClick={() => setIsRecording(!isRecording)}
                className={isRecording ? 'bg-red-500/20 border-red-400/30' : ''}
              >
                <Mic className={`w-4 h-4 ${isRecording ? 'text-red-400' : ''}`} />
              </GlassButton>
              
              <GlassButton
                size="sm"
                onClick={() => sendMessage(newMessage)}
                disabled={!newMessage.trim()}
              >
                <Send className="w-4 h-4" />
              </GlassButton>
            </div>
          </div>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* No Tickets State */}
      {tickets.length === 0 && !isCreatingTicket && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <GlassCard className="p-8">
            <MessageCircle className="w-16 h-16 text-purple-400 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-white mb-2">
              У вас нет открытых тикетов
            </h2>
            <p className="text-white/60 mb-6">
              Создайте тикет для получения помощи от нашей команды поддержки
            </p>
            <GlassButton onClick={() => setIsCreatingTicket(true)}>
              Создать тикет
            </GlassButton>
          </GlassCard>
        </motion.div>
      )}

      {/* Create Ticket Form */}
      {isCreatingTicket && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Создать тикет</h2>
            <input
              type="text"
              value={newTicketSubject}
              onChange={(e) => setNewTicketSubject(e.target.value)}
              placeholder="Тема обращения..."
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/50 focus:border-purple-400 focus:outline-none mb-4"
            />
            <div className="flex space-x-3">
              <GlassButton onClick={createNewTicket} disabled={!newTicketSubject.trim()}>
                Создать
              </GlassButton>
              <GlassButton
                variant="secondary"
                onClick={() => {
                  setIsCreatingTicket(false);
                  setNewTicketSubject('');
                }}
              >
                Отмена
              </GlassButton>
            </div>
          </GlassCard>
        </motion.div>
      )}

      {/* Existing Tickets */}
      {tickets.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-white">Мои тикеты</h2>
            <GlassButton
              size="sm"
              onClick={() => setIsCreatingTicket(true)}
            >
              <Plus className="w-4 h-4 mr-1" />
              Новый
            </GlassButton>
          </div>
          
          {tickets.map((ticket) => (
            <motion.div
              key={ticket.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02 }}
            >
              <GlassCard
                className="p-4 cursor-pointer hover:bg-white/15"
                onClick={() => setCurrentTicket(ticket)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-white font-medium">{ticket.subject}</h3>
                    <div className="flex items-center space-x-4 mt-2">
                      <div className="flex items-center space-x-1">
                        {getStatusIcon(ticket.status)}
                        <span className="text-white/60 text-sm">{getStatusText(ticket.status)}</span>
                      </div>
                      <span className="text-white/40 text-sm">
                        {ticket.createdAt.toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  {ticket.messages.length > 0 && (
                    <div className="text-purple-400 text-sm">
                      {ticket.messages.length} сообщений
                    </div>
                  )}
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}