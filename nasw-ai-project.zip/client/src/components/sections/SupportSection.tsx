import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { GlassCard } from '../ui/glass-card';
import { GlassButton } from '../ui/glass-button';
import { useAppStore } from '../../store/app-store';
import { api, queryKeys } from '../../lib/api';
import { TicketModal } from '../modals/TicketModal';
import { useTelegram } from '../../hooks/use-telegram';

const statusColors = {
  open: 'text-green-400',
  in_progress: 'text-yellow-400',
  closed: 'text-gray-400',
};

const statusLabels = {
  open: 'Открыт',
  in_progress: 'В работе',
  closed: 'Закрыт',
};

const priorityColors = {
  low: 'text-gray-400',
  medium: 'text-yellow-400',
  high: 'text-red-400',
};

const priorityLabels = {
  low: 'Низкий',
  medium: 'Средний',
  high: 'Высокий',
};

const faqs = [
  {
    question: "Как работает генерация контента?",
    answer: "Мы используем современные нейросети для создания текста, изображений, видео и аудио на основе ваших описаний."
  },
  {
    question: "Как пополнить баланс?",
    answer: "Перейдите в раздел 'Баланс' и выберите подходящую сумму. Оплата происходит через защищенные платежные системы."
  },
  {
    question: "Что делать если результат не устраивает?",
    answer: "Создайте тикет в поддержку с описанием проблемы. Мы рассмотрим возможность возврата средств или повторной генерации."
  },
  {
    question: "Сколько времени занимает генерация?",
    answer: "Обычно от 30 секунд до 5 минут в зависимости от типа контента и сложности запроса."
  }
];

export function SupportSection() {
  const { user } = useAppStore();
  const { hapticFeedback } = useTelegram();
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const { data: ticketsData, isLoading } = useQuery({
    queryKey: queryKeys.tickets(user?.telegramId || ''),
    queryFn: () => api.getTickets(user?.telegramId || ''),
    enabled: !!user?.telegramId,
  });

  const tickets = ticketsData?.tickets || [];
  const activeTickets = tickets.filter(ticket => ticket.status !== 'closed');

  const handleCreateTicket = () => {
    hapticFeedback('medium');
    setIsTicketModalOpen(true);
  };

  const handleFaqClick = (index: number) => {
    hapticFeedback('light');
    setExpandedFaq(expandedFaq === index ? null : index);
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Active Tickets */}
      <GlassCard className="p-6">
        <h3 className="text-xl font-bold mb-4">Поддержка</h3>
        
        <div className="space-y-4">
          <div className="glass-card bg-glass-white p-4 rounded-xl">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold">Активные тикеты</h4>
              <span className="text-sm text-gray-400">
                {activeTickets.length} открыто
              </span>
            </div>
            
            {isLoading ? (
              <div className="space-y-2">
                {[...Array(2)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-dark-accent rounded mb-2"></div>
                    <div className="h-3 bg-dark-accent rounded w-2/3"></div>
                  </div>
                ))}
              </div>
            ) : activeTickets.length > 0 ? (
              <div className="space-y-3">
                {activeTickets.map((ticket) => (
                  <motion.div
                    key={ticket.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-button bg-glass-white p-3 rounded-lg"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">#{ticket.id}</span>
                      <div className="flex items-center space-x-2">
                        <span className={`text-xs ${statusColors[ticket.status]}`}>
                          {statusLabels[ticket.status]}
                        </span>
                        <span className={`text-xs ${priorityColors[ticket.priority]}`}>
                          {priorityLabels[ticket.priority]}
                        </span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-300 mb-2">{ticket.title}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(ticket.createdAt).toLocaleString()}
                    </p>
                  </motion.div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-400 mb-3">У вас нет открытых тикетов</p>
            )}
            
            <GlassButton
              variant="gradient"
              className="w-full mt-4"
              onClick={handleCreateTicket}
            >
              Создать тикет
            </GlassButton>
          </div>
        </div>
      </GlassCard>

      {/* FAQ */}
      <GlassCard className="p-6">
        <h4 className="text-lg font-semibold mb-4">Часто задаваемые вопросы</h4>
        <div className="space-y-2">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              className="glass-button bg-glass-white rounded-lg overflow-hidden"
            >
              <button
                onClick={() => handleFaqClick(index)}
                className="w-full text-left p-4 hover:bg-glass-white/50 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{faq.question}</span>
                  <motion.svg
                    animate={{ rotate: expandedFaq === index ? 180 : 0 }}
                    transition={{ duration: 0.2 }}
                    className="w-4 h-4 text-gray-400"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/>
                  </motion.svg>
                </div>
              </button>
              
              <AnimatePresence>
                {expandedFaq === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="px-4 pb-4"
                  >
                    <p className="text-sm text-gray-300 pt-2 border-t border-gray-600">
                      {faq.answer}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </GlassCard>

      {/* Contact Info */}
      <GlassCard className="p-6">
        <h4 className="text-lg font-semibold mb-4">Контакты</h4>
        <div className="space-y-3">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-primary to-neon-cyan rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
              </svg>
            </div>
            <div>
              <p className="text-sm font-medium">Telegram канал</p>
              <p className="text-xs text-gray-400">@Mister_nasway</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-neon-pink to-neon-cyan rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
              </svg>
            </div>
            <div>
              <p className="text-sm font-medium">Email</p>
              <p className="text-xs text-gray-400">support@nasway.ai</p>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Ticket Modal */}
      <TicketModal
        isOpen={isTicketModalOpen}
        onClose={() => setIsTicketModalOpen(false)}
      />
    </motion.section>
  );
}
