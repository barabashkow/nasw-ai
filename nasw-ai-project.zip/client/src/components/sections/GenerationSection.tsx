import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useMutation } from '@tanstack/react-query';
import { GlassCard } from '../ui/glass-card';
import { GlassButton } from '../ui/glass-button';
import { useAppStore } from '../../store/app-store';
import { useTelegram } from '../../hooks/use-telegram';
import { api, invalidateGeneratedContent, invalidateBalance } from '../../lib/api';
import { GENERATION_COSTS } from '../../types';
import { useToast } from '@/hooks/use-toast';

const contentTypes = [
  { id: 'text', label: 'Текст', icon: '📝', cost: GENERATION_COSTS.text },
  { id: 'image', label: 'Изображение', icon: '🖼️', cost: GENERATION_COSTS.image },
  { id: 'video', label: 'Видео', icon: '🎥', cost: GENERATION_COSTS.video },
  { id: 'voice', label: 'Голос', icon: '🎙️', cost: GENERATION_COSTS.voice },
];

const styles = [
  { id: 'realistic', label: 'Реалистичный' },
  { id: 'artistic', label: 'Художественный' },
];

export function GenerationSection() {
  const { user, addGeneratedContent, setIsGenerating, setGenerationProgress } = useAppStore();
  const { hapticFeedback, showAlert } = useTelegram();
  const { toast } = useToast();

  const [selectedType, setSelectedType] = useState('text');
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('realistic');
  const [generationProgress, setLocalProgress] = useState(0);

  const generateMutation = useMutation({
    mutationFn: () => api.generateContent(user?.telegramId || '', {
      type: selectedType as any,
      prompt,
      style: selectedStyle,
    }),
    onMutate: () => {
      setIsGenerating(true);
      setLocalProgress(0);
      hapticFeedback('medium');
      
      // Simulate progress
      const interval = setInterval(() => {
        setLocalProgress(prev => {
          const newProgress = prev + Math.random() * 10;
          if (newProgress >= 90) {
            clearInterval(interval);
            return 90;
          }
          return newProgress;
        });
      }, 200);

      return { interval };
    },
    onSuccess: (data, variables, context) => {
      setLocalProgress(100);
      setIsGenerating(false);
      addGeneratedContent(data.generation);
      invalidateGeneratedContent(user?.telegramId || '');
      invalidateBalance(user?.telegramId || '');
      hapticFeedback('success');
      
      // Reset form
      setPrompt('');
      setLocalProgress(0);
      
      toast({
        title: "Контент создан!",
        description: "Результат доступен в галерее",
      });
    },
    onError: (error, variables, context) => {
      if (context?.interval) {
        clearInterval(context.interval);
      }
      setIsGenerating(false);
      setLocalProgress(0);
      hapticFeedback('error');
      showAlert(`Ошибка генерации: ${error.message}`);
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      showAlert('Введите описание для генерации');
      return;
    }

    const selectedTypeData = contentTypes.find(t => t.id === selectedType);
    if (!selectedTypeData) return;

    if (!user || user.balance < selectedTypeData.cost) {
      showAlert('Недостаточно средств на балансе');
      return;
    }

    generateMutation.mutate();
  };

  const selectedTypeData = contentTypes.find(t => t.id === selectedType);

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Generation Form */}
      <GlassCard className="p-6">
        <h3 className="text-xl font-bold mb-4">Генерация контента</h3>
        
        <div className="space-y-4">
          {/* Content Type Selection */}
          <div>
            <label className="block text-sm font-medium mb-2">Тип контента</label>
            <div className="grid grid-cols-2 gap-2">
              {contentTypes.map((type) => (
                <motion.button
                  key={type.id}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setSelectedType(type.id);
                    hapticFeedback('light');
                  }}
                  className={`glass-button p-3 rounded-lg text-center transition-all duration-300 ${
                    selectedType === type.id
                      ? 'bg-purple-primary/20 border-purple-primary text-purple-light'
                      : 'bg-glass-white border-white/20'
                  }`}
                >
                  <div className="text-xl mb-1">{type.icon}</div>
                  <div className="text-sm font-medium">{type.label}</div>
                  <div className="text-xs text-gray-400">₽{type.cost}</div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Prompt Input */}
          <div>
            <label className="block text-sm font-medium mb-2">Описание</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full bg-dark-accent text-white p-3 rounded-lg border border-gray-600 h-32 resize-none focus:outline-none focus:ring-2 focus:ring-purple-primary"
              placeholder="Опишите детально, что вы хотите создать..."
            />
          </div>

          {/* Style Selection */}
          <div>
            <label className="block text-sm font-medium mb-2">Стиль</label>
            <div className="grid grid-cols-2 gap-2">
              {styles.map((style) => (
                <label key={style.id} className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="style"
                    value={style.id}
                    checked={selectedStyle === style.id}
                    onChange={(e) => setSelectedStyle(e.target.value)}
                    className="text-purple-primary focus:ring-purple-primary"
                  />
                  <span className="text-sm">{style.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <GlassButton
            variant="gradient"
            className="w-full p-4 text-lg font-semibold"
            onClick={handleGenerate}
            disabled={generateMutation.isPending || !prompt.trim()}
          >
            {generateMutation.isPending ? (
              <div className="flex items-center space-x-2">
                <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                <span>Создаю...</span>
              </div>
            ) : (
              <>
                Создать контент за ₽{selectedTypeData?.cost || 0}
              </>
            )}
          </GlassButton>
        </div>
      </GlassCard>

      {/* Generation Progress */}
      <AnimatePresence>
        {generateMutation.isPending && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="glass-card p-6"
          >
            <h4 className="text-lg font-semibold mb-4">Генерация в процессе...</h4>
            <div className="w-full bg-dark-accent rounded-full h-2 mb-4">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${generationProgress}%` }}
                transition={{ duration: 0.3 }}
                className="progress-bar h-2 rounded-full"
              />
            </div>
            <p className="text-sm text-gray-400 mb-4">
              {generationProgress < 30 && "Анализ промпта..."}
              {generationProgress >= 30 && generationProgress < 70 && "Создание контента..."}
              {generationProgress >= 70 && "Финальная обработка..."}
            </p>
            <div className="bg-dark-accent rounded-lg p-4">
              <div className="loading-shimmer h-4 bg-gray-600 rounded mb-2"></div>
              <div className="loading-shimmer h-4 bg-gray-600 rounded w-3/4"></div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tips */}
      <GlassCard className="p-6">
        <h4 className="text-lg font-semibold mb-4">💡 Советы для лучших результатов</h4>
        <div className="space-y-2 text-sm text-gray-400">
          <p>• Будьте максимально детальны в описании</p>
          <p>• Укажите стиль, настроение и композицию</p>
          <p>• Используйте конкретные термины и примеры</p>
          <p>• Для видео опишите действия и движения</p>
        </div>
      </GlassCard>
    </motion.section>
  );
}
