import React from 'react';
import { motion } from 'framer-motion';
import { useQuery, useMutation } from '@tanstack/react-query';
import { GlassCard } from '../ui/glass-card';
import { GlassButton } from '../ui/glass-button';
import { useAppStore } from '../../store/app-store';
import { useTelegram } from '../../hooks/use-telegram';
import { api, queryKeys, invalidateBalance } from '../../lib/api';
import { TOPUP_AMOUNTS } from '../../types';
import { useToast } from '@/hooks/use-toast';

export function BalanceSection() {
  const { user, updateUserBalance } = useAppStore();
  const { hapticFeedback, showAlert } = useTelegram();
  const { toast } = useToast();

  const { data: balanceData, isLoading: isLoadingBalance } = useQuery({
    queryKey: queryKeys.balance(user?.telegramId || ''),
    queryFn: () => api.getBalance(user?.telegramId || ''),
    enabled: !!user?.telegramId,
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const topupMutation = useMutation({
    mutationFn: ({ amount }: { amount: number }) => 
      api.topupBalance(user?.telegramId || '', amount),
    onSuccess: (data) => {
      updateUserBalance(data.user.balance);
      invalidateBalance(user?.telegramId || '');
      hapticFeedback('success');
      
      if (data.paymentUrl) {
        window.open(data.paymentUrl, '_blank');
      }
      
      toast({
        title: "Пополнение инициировано",
        description: "Завершите платеж в открывшемся окне",
      });
    },
    onError: (error) => {
      hapticFeedback('error');
      showAlert(`Ошибка при пополнении: ${error.message}`);
    },
  });

  const handleTopup = (amount: number) => {
    hapticFeedback('medium');
    topupMutation.mutate({ amount });
  };

  const currentBalance = balanceData?.balance ?? user?.balance ?? 0;

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Balance Display */}
      <GlassCard className="p-6" variant="elevated">
        <h3 className="text-xl font-bold mb-4">Баланс</h3>
        <div className="text-center mb-6">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-4xl font-bold gradient-text mb-2"
          >
            {isLoadingBalance ? (
              <div className="animate-pulse">₽---.--</div>
            ) : (
              `₽${currentBalance.toFixed(2)}`
            )}
          </motion.div>
          <p className="text-gray-400">Доступно для генерации</p>
        </div>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="glass-button bg-glass-white p-3 rounded-lg text-center">
            <div className="text-lg font-semibold text-neon-cyan">12</div>
            <div className="text-xs text-gray-400">Генераций</div>
          </div>
          <div className="glass-button bg-glass-white p-3 rounded-lg text-center">
            <div className="text-lg font-semibold text-neon-pink">₽340</div>
            <div className="text-xs text-gray-400">Потрачено</div>
          </div>
        </div>
      </GlassCard>

      {/* Top-up Options */}
      <GlassCard className="p-6">
        <h4 className="text-lg font-semibold mb-4">Пополнить баланс</h4>
        <div className="space-y-3">
          {TOPUP_AMOUNTS.map((amount) => (
            <motion.div
              key={amount}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <GlassButton
                variant="gradient"
                className="w-full p-4 justify-between"
                onClick={() => handleTopup(amount)}
                disabled={topupMutation.isPending}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-medium">Пополнить на ₽{amount}</span>
                  <div className="flex items-center space-x-2">
                    {amount >= 1000 && (
                      <span className="text-xs bg-neon-cyan/20 text-neon-cyan px-2 py-1 rounded-full">
                        +{Math.floor(amount * 0.1)}% бонус
                      </span>
                    )}
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                  </div>
                </div>
              </GlassButton>
            </motion.div>
          ))}
        </div>
        
        {topupMutation.isPending && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-4 p-3 bg-dark-accent rounded-lg"
          >
            <div className="flex items-center space-x-2">
              <div className="animate-spin w-4 h-4 border-2 border-purple-primary border-t-transparent rounded-full"></div>
              <span className="text-sm text-gray-400">Обработка платежа...</span>
            </div>
          </motion.div>
        )}
      </GlassCard>

      {/* Payment Methods */}
      <GlassCard className="p-6">
        <h4 className="text-lg font-semibold mb-4">Способы оплаты</h4>
        <div className="grid grid-cols-2 gap-3">
          <div className="glass-button bg-glass-white p-3 rounded-lg text-center">
            <div className="text-2xl mb-1">💳</div>
            <div className="text-sm font-medium">Банковская карта</div>
          </div>
          <div className="glass-button bg-glass-white p-3 rounded-lg text-center">
            <div className="text-2xl mb-1">📱</div>
            <div className="text-sm font-medium">Telegram Stars</div>
          </div>
        </div>
      </GlassCard>
    </motion.section>
  );
}
