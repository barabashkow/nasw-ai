import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { GlassCard } from '../ui/glass-card';
import { GlassButton } from '../ui/glass-button';
import { useAppStore } from '../../store/app-store';
import { api, queryKeys } from '../../lib/api';
import { GeneratedContent } from '../../types';
import { useTelegram } from '../../hooks/use-telegram';

const typeIcons = {
  text: '📝',
  image: '🖼️',
  video: '🎥',
  voice: '🎙️',
};

const statusColors = {
  pending: 'text-yellow-400',
  processing: 'text-blue-400',
  completed: 'text-green-400',
  failed: 'text-red-400',
};

export function GallerySection() {
  const { user } = useAppStore();
  const { hapticFeedback } = useTelegram();
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [selectedContent, setSelectedContent] = useState<GeneratedContent | null>(null);

  const { data: contentData, isLoading } = useQuery({
    queryKey: queryKeys.generatedContent(user?.telegramId || ''),
    queryFn: () => api.getGeneratedContent(user?.telegramId || ''),
    enabled: !!user?.telegramId,
  });

  const content = contentData?.content || [];
  const filteredContent = selectedFilter === 'all' 
    ? content 
    : content.filter(item => item.type === selectedFilter);

  const handleContentClick = (item: GeneratedContent) => {
    hapticFeedback('light');
    setSelectedContent(item);
  };

  const renderContentPreview = (item: GeneratedContent) => {
    switch (item.type) {
      case 'image':
        return item.result?.url ? (
          <img 
            src={item.result.url} 
            alt={item.prompt}
            className="w-full h-32 object-cover rounded-lg"
          />
        ) : (
          <div className="w-full h-32 bg-dark-accent rounded-lg flex items-center justify-center">
            <span className="text-4xl">🖼️</span>
          </div>
        );
      
      case 'video':
        return item.result?.videoUrl ? (
          <div className="relative w-full h-32 bg-dark-accent rounded-lg overflow-hidden">
            <video 
              src={item.result.videoUrl}
              className="w-full h-full object-cover"
              poster={item.result.thumbnailUrl}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-12 h-12 bg-black/50 rounded-full flex items-center justify-center">
                <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z"/>
                </svg>
              </div>
            </div>
          </div>
        ) : (
          <div className="w-full h-32 bg-dark-accent rounded-lg flex items-center justify-center">
            <span className="text-4xl">🎥</span>
          </div>
        );
      
      case 'voice':
        return (
          <div className="w-full h-32 bg-dark-accent rounded-lg flex items-center justify-center">
            <div className="text-center">
              <span className="text-4xl block mb-2">🎙️</span>
              <span className="text-sm text-gray-400">Аудио файл</span>
            </div>
          </div>
        );
      
      default:
        return (
          <div className="w-full h-32 bg-dark-accent rounded-lg flex items-center justify-center">
            <span className="text-4xl">{typeIcons[item.type] || '📝'}</span>
          </div>
        );
    }
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Header */}
      <GlassCard className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold">Галерея</h3>
          <div className="text-sm text-gray-400">
            {content.length} создано
          </div>
        </div>
        
        {/* Filters */}
        <div className="flex space-x-2">
          {['all', 'text', 'image', 'video', 'voice'].map((filter) => (
            <GlassButton
              key={filter}
              size="sm"
              variant={selectedFilter === filter ? 'gradient' : 'default'}
              onClick={() => {
                setSelectedFilter(filter);
                hapticFeedback('light');
              }}
            >
              {filter === 'all' ? 'Все' : typeIcons[filter] || filter}
            </GlassButton>
          ))}
        </div>
      </GlassCard>

      {/* Content Grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="glass-card p-4 animate-pulse">
              <div className="w-full h-32 bg-dark-accent rounded-lg mb-3"></div>
              <div className="h-4 bg-dark-accent rounded mb-2"></div>
              <div className="h-3 bg-dark-accent rounded w-2/3"></div>
            </div>
          ))}
        </div>
      ) : filteredContent.length > 0 ? (
        <div className="grid grid-cols-2 gap-4">
          {filteredContent.map((item) => (
            <motion.div
              key={item.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="glass-card cursor-pointer overflow-hidden"
              onClick={() => handleContentClick(item)}
            >
              {renderContentPreview(item)}
              <div className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">
                    {typeIcons[item.type]} {item.type}
                  </span>
                  <span className={`text-xs ${statusColors[item.status]}`}>
                    {item.status}
                  </span>
                </div>
                <p className="text-sm text-gray-300 mb-2 line-clamp-2">
                  {item.prompt}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">
                    {new Date(item.createdAt).toLocaleDateString()}
                  </span>
                  <span className="text-xs text-neon-cyan">
                    ₽{item.cost}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <GlassCard className="p-6 text-center">
          <div className="text-6xl mb-4">🎨</div>
          <h4 className="text-lg font-semibold mb-2">Пока пусто</h4>
          <p className="text-gray-400 mb-4">
            Создайте ваш первый контент в разделе "Генерация"
          </p>
          <GlassButton
            variant="gradient"
            onClick={() => {
              // Navigate to generation section
              hapticFeedback('medium');
            }}
          >
            Начать создание
          </GlassButton>
        </GlassCard>
      )}

      {/* Content Detail Modal */}
      <AnimatePresence>
        {selectedContent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedContent(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="glass-card max-w-lg w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold">
                    {typeIcons[selectedContent.type]} {selectedContent.type}
                  </h3>
                  <button
                    onClick={() => setSelectedContent(null)}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                    </svg>
                  </button>
                </div>
                
                {/* Content Preview */}
                <div className="mb-4">
                  {renderContentPreview(selectedContent)}
                </div>
                
                {/* Details */}
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Промпт:</h4>
                    <p className="text-sm text-gray-300 bg-dark-accent p-3 rounded-lg">
                      {selectedContent.prompt}
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold mb-1">Статус:</h4>
                      <span className={`text-sm ${statusColors[selectedContent.status]}`}>
                        {selectedContent.status}
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Стоимость:</h4>
                      <span className="text-sm text-neon-cyan">₽{selectedContent.cost}</span>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-1">Создано:</h4>
                    <span className="text-sm text-gray-400">
                      {new Date(selectedContent.createdAt).toLocaleString()}
                    </span>
                  </div>
                </div>
                
                {/* Actions */}
                <div className="mt-6 flex space-x-3">
                  <GlassButton
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      // Share functionality
                      hapticFeedback('light');
                    }}
                  >
                    Поделиться
                  </GlassButton>
                  <GlassButton
                    variant="gradient"
                    className="flex-1"
                    onClick={() => {
                      // Download functionality
                      hapticFeedback('light');
                    }}
                  >
                    Скачать
                  </GlassButton>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.section>
  );
}
