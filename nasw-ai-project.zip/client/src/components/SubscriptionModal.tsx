import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Loader2, CheckCircle, ExternalLink, X } from 'lucide-react';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerified: () => void;
}

export default function SubscriptionModal({ isOpen, onClose, onVerified }: SubscriptionModalProps) {
  const [isChecking, setIsChecking] = useState(false);

  const { data: subscriptionStatus, refetch } = useQuery({
    queryKey: ['/api/check-subscription'],
    enabled: false
  });

  const handleCheckSubscription = async () => {
    setIsChecking(true);
    
    try {
      const result = await refetch();
      
      setTimeout(() => {
        setIsChecking(false);
        // В режиме разработки всегда считаем подписанным
        if (import.meta.env.DEV || result.data?.subscribed) {
          onVerified();
          onClose();
        } else {
          alert('Пожалуйста, сначала подпишитесь на канал');
        }
      }, 1500);
    } catch (error) {
      setIsChecking(false);
      // В случае ошибки в разработке пропускаем проверку
      if (import.meta.env.DEV) {
        onVerified();
        onClose();
      } else {
        alert('Ошибка проверки подписки. Попробуйте еще раз.');
      }
    }
  };

  const handleOpenChannel = () => {
    window.open('https://t.me/nasw_ai', '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative max-w-md w-full">
        <div className="glass-card p-8 rounded-3xl text-center">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-white/60 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          
          <h1 className="text-2xl font-bold text-white mb-4">
            Подписка обязательна
          </h1>
          <p className="text-white/60 mb-6">
            Для доступа к генерации нужно подписаться на наш канал в Telegram
          </p>
          
          <div className="space-y-4">
            <button
              onClick={handleOpenChannel}
              className="w-full glass-button p-4 rounded-xl flex items-center justify-center gap-2 text-white font-semibold bg-blue-500/20 hover:bg-blue-500/30"
            >
              <ExternalLink className="w-5 h-5" />
              Подписаться на канал
            </button>
            
            <button
              onClick={handleCheckSubscription}
              disabled={isChecking}
              className="w-full glass-button p-4 rounded-xl flex items-center justify-center gap-2 text-white font-semibold disabled:opacity-50"
            >
              {isChecking ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Проверяю...
                </>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5" />
                  Я подписался
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}