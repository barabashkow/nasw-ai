import React from 'react';
import { motion } from 'framer-motion';
import { LANGUAGES } from '../types';
import { useAppStore } from '../store/app-store';
import { GlassCard } from './ui/glass-card';

interface HeaderProps {
  language: string;
  onLanguageChange: (language: string) => void;
}

export function Header({ language, onLanguageChange }: HeaderProps) {
  const { user } = useAppStore();

  return (
    <GlassCard className="fixed top-0 left-0 right-0 z-40 p-4">
      <div className="flex items-center justify-between">
        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="flex items-center space-x-3"
        >
          <div className="w-10 h-10 bg-gradient-to-r from-purple-primary to-neon-cyan rounded-full flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
          </div>
          <div>
            <h1 className="text-lg font-semibold">Nasway AI</h1>
            <p className="text-xs text-gray-400">
              {user?.username ? `@${user.username}` : user?.firstName || 'Пользователь'}
            </p>
          </div>
        </motion.div>
        
        <motion.div
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex items-center space-x-2"
        >
          {/* Language selector */}
          <select
            value={language}
            onChange={(e) => onLanguageChange(e.target.value)}
            className="bg-dark-accent text-white px-3 py-1 rounded-lg border border-gray-600 text-sm focus:outline-none focus:ring-2 focus:ring-purple-primary"
          >
            {LANGUAGES.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.flag} {lang.code.toUpperCase()}
              </option>
            ))}
          </select>
          
          {/* Balance display */}
          <div className="glass-button bg-glass-white px-3 py-1 rounded-lg">
            <span className="text-sm font-medium">
              ₽{user?.balance || 0}
            </span>
          </div>
        </motion.div>
      </div>
    </GlassCard>
  );
}
