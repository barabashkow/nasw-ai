import { useState, useEffect } from 'react';

interface LoadingScreenProps {
  onComplete: () => void;
}

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [visibleLetters, setVisibleLetters] = useState(0);
  const [showDots, setShowDots] = useState(true);
  const title = "NASW AI";

  useEffect(() => {
    const timer = setInterval(() => {
      setVisibleLetters(prev => {
        if (prev >= title.length) {
          clearInterval(timer);
          setTimeout(onComplete, 1500);
          return prev;
        }
        return prev + 1;
      });
    }, 200);

    return () => clearInterval(timer);
  }, [onComplete, title.length]);

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Темный фон с фиолетовым liquid glass блюром */}
      <div className="absolute inset-0 bg-black" />
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl" />
        <div className="absolute top-1/3 left-1/3 w-64 h-64 bg-violet-600/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/3 right-1/3 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>
      
      {/* NASW AI текст с анимацией появления по буквам */}
      <div className="relative z-10 text-center">
        <h1 className="text-7xl font-black mb-12">
          {title.split('').map((letter, index) => (
            <span
              key={index}
              className={`inline-block transition-all duration-500 ${
                index < visibleLetters 
                  ? 'opacity-100 transform translate-y-0' 
                  : 'opacity-0 transform translate-y-4'
              }`}
              style={{ 
                transitionDelay: `${index * 50}ms`,
                color: 'white',
                textShadow: '0 0 40px rgba(168, 85, 247, 0.6)',
              }}
            >
              {letter === ' ' ? '\u00A0' : letter}
            </span>
          ))}
        </h1>
        
        {/* 3 бегущие точки */}
        <div className="flex justify-center items-center space-x-2">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"
              style={{
                animationDelay: `${i * 200}ms`,
                animationDuration: '1.4s'
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}