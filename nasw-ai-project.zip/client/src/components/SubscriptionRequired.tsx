import { motion } from 'framer-motion';
import { ExternalLink, MessageCircle, Users, Gift } from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import type { Language } from '../lib/i18n';
import { GlassCard } from '@/components/ui/glass-card';
import { GlassButton } from '@/components/ui/glass-button';
import { useTelegram } from '../hooks/use-telegram';

interface SubscriptionRequiredProps {
  language: Language;
  channelUrl: string;
  onRetry: () => void;
}

export function SubscriptionRequired({ language, channelUrl, onRetry }: SubscriptionRequiredProps) {
  const { t } = useTranslation(language);
  const { hapticFeedback } = useTelegram();

  const handleSubscribeClick = () => {
    hapticFeedback('light');
    window.open(channelUrl, '_blank');
  };

  const handleRetryClick = () => {
    hapticFeedback('success');
    onRetry();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0b0b14] via-[#1a1a1f] to-[#2a2a3f] flex items-center justify-center p-4">
      <div className="max-w-sm mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <GlassCard className="p-8 text-center" variant="purple">
            {/* Icon */}
            <motion.div
              className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-r from-purple-600 to-violet-600 flex items-center justify-center"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.3, type: "spring" }}
            >
              <Users className="w-10 h-10 text-white" />
            </motion.div>

            {/* Title */}
            <motion.h1
              className="text-2xl font-bold text-white mb-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              Подписка обязательна
            </motion.h1>

            {/* Description */}
            <motion.p
              className="text-white/80 mb-6 leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              Для использования NASW AI необходимо подписаться на наш официальный канал. 
              Это гарантирует получение обновлений и эксклюзивного контента.
            </motion.p>

            {/* Benefits */}
            <motion.div
              className="space-y-3 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <div className="flex items-center space-x-3 text-left">
                <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Gift className="w-4 h-4 text-green-400" />
                </div>
                <span className="text-white/80 text-sm">3 бесплатные генерации в подарок</span>
              </div>
              
              <div className="flex items-center space-x-3 text-left">
                <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                  <MessageCircle className="w-4 h-4 text-blue-400" />
                </div>
                <span className="text-white/80 text-sm">Эксклюзивные обновления и новости</span>
              </div>
              
              <div className="flex items-center space-x-3 text-left">
                <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Users className="w-4 h-4 text-purple-400" />
                </div>
                <span className="text-white/80 text-sm">Приоритетная поддержка</span>
              </div>
            </motion.div>

            {/* Subscribe Button */}
            <motion.div
              className="space-y-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
            >
              <GlassButton
                onClick={handleSubscribeClick}
                variant="primary"
                className="w-full py-4 text-lg font-semibold"
              >
                <ExternalLink className="w-5 h-5 mr-2" />
                Подписаться на канал
              </GlassButton>

              <GlassButton
                onClick={handleRetryClick}
                variant="secondary"
                className="w-full py-3"
              >
                Я уже подписался
              </GlassButton>
            </motion.div>

            {/* Note */}
            <motion.p
              className="text-white/50 text-xs mt-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
            >
              После подписки нажмите "Я уже подписался" для проверки
            </motion.p>
          </GlassCard>
        </motion.div>
      </div>
    </div>
  );
}