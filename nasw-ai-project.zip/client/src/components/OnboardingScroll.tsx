import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Zap, Clock, Image, Headphones, ChevronRight, X } from 'lucide-react';
import { useTranslation, Language } from '@/lib/i18n';
import { GlassButton } from '@/components/ui/glass-button';

interface OnboardingScrollProps {
  onComplete: () => void;
  language: Language;
}

interface OnboardingSlide {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle: string;
  description: string;
  gradient: string;
}

export function OnboardingScroll({ onComplete, language }: OnboardingScrollProps) {
  const { t } = useTranslation(language);
  const [currentSlide, setCurrentSlide] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const slides: OnboardingSlide[] = language === 'ru' ? [
    {
      id: 'veo3',
      icon: Zap,
      title: 'Видео генерация',
      subtitle: 'Создавайте видео с AI',
      description: 'Превращайте текст в потрясающие видео с помощью передовых нейросетей',
      gradient: 'from-purple-600 via-violet-600 to-purple-700'
    },
    {
      id: 'gallery',
      icon: Clock,
      title: 'Галерея работ',
      subtitle: 'Сохраняйте творения',
      description: 'Все ваши генерации в одном месте с удобным поиском и фильтрами',
      gradient: 'from-pink-600 via-rose-600 to-pink-700'
    },
    {
      id: 'photo8k',
      icon: Image,
      title: 'Фото в HD качестве',
      subtitle: 'Мгновенные изображения',
      description: 'Создавайте фотореалистичные изображения высокого разрешения',
      gradient: 'from-blue-600 via-cyan-600 to-blue-700'
    },
    {
      id: 'support',
      icon: Headphones,
      title: 'Поддержка 24/7',
      subtitle: 'Всегда на связи',
      description: 'Техническая поддержка ответит на все ваши вопросы',
      gradient: 'from-green-600 via-emerald-600 to-green-700'
    }
  ] : language === 'en' ? [
    {
      id: 'veo3',
      icon: Zap,
      title: 'Video Generation',
      subtitle: 'Create videos with AI',
      description: 'Transform text into stunning videos using advanced neural networks',
      gradient: 'from-purple-600 via-violet-600 to-purple-700'
    },
    {
      id: 'gallery',
      icon: Clock,
      title: 'Work Gallery',
      subtitle: 'Save your creations',
      description: 'All your generations in one place with convenient search and filters',
      gradient: 'from-pink-600 via-rose-600 to-pink-700'
    },
    {
      id: 'photo8k',
      icon: Image,
      title: 'HD Quality Photos',
      subtitle: 'Instant images',
      description: 'Create photorealistic high-resolution images',
      gradient: 'from-blue-600 via-cyan-600 to-blue-700'
    },
    {
      id: 'support',
      icon: Headphones,
      title: '24/7 Support',
      subtitle: 'Always connected',
      description: 'Technical support will answer all your questions',
      gradient: 'from-green-600 via-emerald-600 to-green-700'
    }
  ] : [
    {
      id: 'veo3',
      icon: Zap,
      title: 'Бейне генерация',
      subtitle: 'AI арқылы бейне жасау',
      description: 'Мәтінді таң қаларлық бейнелерге айналдырыңыз',
      gradient: 'from-purple-600 via-violet-600 to-purple-700'
    },
    {
      id: 'gallery',
      icon: Clock,
      title: 'Жұмыстар галереясы',
      subtitle: 'Туындыларыңызды сақтаңыз',
      description: 'Барлық генерацияларыңыз бір жерде',
      gradient: 'from-pink-600 via-rose-600 to-pink-700'
    },
    {
      id: 'photo8k',
      icon: Image,
      title: 'HD сапалы фото',
      subtitle: 'Лезде суреттер',
      description: 'Жоғары ажыратымдылықтағы фотореалистік суреттер жасаңыз',
      gradient: 'from-blue-600 via-cyan-600 to-blue-700'
    },
    {
      id: 'support',
      icon: Headphones,
      title: '24/7 қолдау',
      subtitle: 'Әрқашан байланыста',
      description: 'Техникалық қолдау барлық сұрақтарыңызға жауап береді',
      gradient: 'from-green-600 via-emerald-600 to-green-700'
    }
  ];

  const handleSlideChange = (index: number) => {
    setCurrentSlide(index);
    if (scrollRef.current) {
      const scrollWidth = scrollRef.current.scrollWidth;
      const clientWidth = scrollRef.current.clientWidth;
      const scrollPosition = (scrollWidth - clientWidth) * (index / (slides.length - 1));
      scrollRef.current.scrollTo({ left: scrollPosition, behavior: 'smooth' });
    }
  };

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      handleSlideChange(currentSlide + 1);
    }
  };

  const handleScroll = () => {
    if (scrollRef.current) {
      const scrollLeft = scrollRef.current.scrollLeft;
      const scrollWidth = scrollRef.current.scrollWidth;
      const clientWidth = scrollRef.current.clientWidth;
      const maxScroll = scrollWidth - clientWidth;
      const progress = scrollLeft / maxScroll;
      const newSlide = Math.round(progress * (slides.length - 1));
      if (newSlide !== currentSlide) {
        setCurrentSlide(newSlide);
      }
    }
  };

  return (
    <div className="h-screen bg-gradient-to-br from-[#000000] via-[#2A004A] to-[#5B2B82] flex flex-col relative overflow-hidden">
      {/* Skip Button */}
      <motion.button
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onComplete}
        className="absolute top-4 right-4 z-10 glass-button px-4 py-2"
      >
        <span className="text-white/80 text-sm font-medium">
          {language === 'ru' ? 'Пропустить' : language === 'en' ? 'Skip' : 'Өткізу'}
        </span>
      </motion.button>

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center pt-8 pb-4 px-4"
      >
        <motion.div
          className="w-20 h-20 mx-auto mb-4 glass-card flex items-center justify-center"
          animate={{
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <Sparkles className="w-10 h-10 text-purple-400" />
        </motion.div>
        
        <h1 className="text-4xl font-bold gradient-text mb-2">NASW AI</h1>
        <p className="text-white/60 text-sm">
          {language === 'ru' ? 'Нейросетевая платформа нового поколения' 
            : language === 'en' ? 'Next generation neural network platform'
            : 'Жаңа буын нейрондық платформа'}
        </p>
      </motion.div>

      {/* Horizontal Scroll Container */}
      <div className="flex-1 flex flex-col">
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex-1 flex overflow-x-auto snap-x snap-mandatory scrollbar-hide px-4 gap-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {slides.map((slide, index) => (
            <motion.div
              key={slide.id}
              className="min-w-full snap-center flex items-center justify-center px-4"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="max-w-sm w-full">
                <div className={`relative p-8 glass-card`}>

                  
                  {/* Content */}
                  <div className="relative z-10 text-center text-white">
                    <motion.div
                      className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-r ${slide.gradient} flex items-center justify-center shadow-lg`}
                      animate={{
                        scale: [1, 1.05, 1],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    >
                      <slide.icon className="w-8 h-8 text-white" />
                    </motion.div>
                    
                    <h2 className="text-2xl font-bold mb-2">{slide.title}</h2>
                    <h3 className="text-lg font-semibold mb-4 text-white/80">{slide.subtitle}</h3>
                    <p className="text-white/60 leading-relaxed text-base">{slide.description}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Dots Indicator */}
        <div className="flex justify-center items-center py-4 px-4">
          <div className="flex space-x-2">
            {slides.map((_, index) => (
              <motion.button
                key={index}
                onClick={() => handleSlideChange(index)}
                className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                  currentSlide === index
                    ? 'bg-purple-400 scale-110'
                    : 'bg-white/30 hover:bg-white/50'
                }`}
                whileTap={{ scale: 0.9 }}
              />
            ))}
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="px-6 pb-6">
          {currentSlide < slides.length - 1 ? (
            <GlassButton
              onClick={handleNext}
              variant="secondary"
              className="w-full py-3 text-base font-semibold"
            >
              Далее
              <ChevronRight className="w-4 h-4 ml-2" />
            </GlassButton>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <GlassButton
                onClick={onComplete}
                variant="primary"
                className="w-full py-3 text-base font-semibold"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Генерировать!
              </GlassButton>
              
              <p className="text-center text-white/60 text-xs mt-3">
                Готовы создавать потрясающий контент?
              </p>
            </motion.div>
          )}
        </div>
      </div>

      <style jsx>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
}