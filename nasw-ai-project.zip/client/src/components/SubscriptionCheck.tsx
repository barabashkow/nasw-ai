import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Loader2, CheckCircle, ExternalLink } from 'lucide-react';

interface SubscriptionCheckProps {
  onVerified: () => void;
}

export default function SubscriptionCheck({ onVerified }: SubscriptionCheckProps) {
  const [isChecking, setIsChecking] = useState(false);

  const { data: subscriptionStatus, refetch } = useQuery({
    queryKey: ['/api/check-subscription'],
    enabled: false
  });

  const handleCheckSubscription = async () => {
    setIsChecking(true);
    
    try {
      const result = await refetch();
      
      setTimeout(() => {
        setIsChecking(false);
        // В режиме разработки всегда считаем подписанным
        if (import.meta.env.DEV || result.data?.subscribed) {
          onVerified();
        } else {
          // Показываем сообщение об ошибке
          alert('Пожалуйста, сначала подпишитесь на канал');
        }
      }, 1500);
    } catch (error) {
      setIsChecking(false);
      // В случае ошибки в разработке пропускаем проверку
      if (import.meta.env.DEV) {
        onVerified();
      } else {
        alert('Ошибка проверки подписки. Попробуйте еще раз.');
      }
    }
  };

  const handleOpenChannel = () => {
    window.open('https://t.me/nasw_ai', '_blank');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="glass-card p-8 rounded-3xl text-center">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          
          <h1 className="text-2xl font-bold text-white mb-4">
            Подписка обязательна
          </h1>
          <p className="text-white/60 mb-6">
            Для доступа к функциям нужно подписаться на наш канал в Telegram
          </p>
          
          <div className="space-y-4">
            <button
              onClick={handleOpenChannel}
              className="w-full glass-button p-4 rounded-xl flex items-center justify-center gap-2 text-white font-semibold bg-blue-500/20 hover:bg-blue-500/30"
            >
              <ExternalLink className="w-5 h-5" />
              Подписаться на канал
            </button>
            
            <button
              onClick={handleCheckSubscription}
              disabled={isChecking}
              className="w-full glass-button p-4 rounded-xl flex items-center justify-center gap-2 text-white font-semibold disabled:opacity-50"
            >
              {isChecking ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Проверяем...
                </>
              ) : (
                'Я подписался'
              )}
            </button>
          </div>
          
          <p className="text-white/40 text-xs mt-4">
            После подписки нажмите "Я подписался"
          </p>
        </div>
      </div>
    </div>
  );
}