import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Zap, Image, History, Headphones } from 'lucide-react';

interface StartScreenProps {
  onComplete: () => void;
}

const introSlides = [
  {
    icon: Zap,
    title: "Veo 3 от Google",
    subtitle: "Следующее поколение видео-нейросетей",
    description: "Создавайте потрясающие видео с помощью передовой технологии искусственного интеллекта от Google",
    gradient: "from-blue-500 to-purple-600"
  },
  {
    icon: Image,
    title: "Точное фото в 8К",
    subtitle: "Мгновенная генерация картинок",
    description: "Превратите свои идеи в высококачественные изображения за считанные секунды",
    gradient: "from-purple-500 to-pink-600"
  },
  {
    icon: History,
    title: "Галерея и история",
    subtitle: "Все твои сгенерированные запросы",
    description: "Сохраняйте и управляйте всеми своими творениями в одном месте",
    gradient: "from-pink-500 to-red-600"
  },
  {
    icon: Headphones,
    title: "Реальная поддержка",
    subtitle: "Тикеты, голос, фото",
    description: "Получайте мгновенные ответы от нашей команды поддержки 24/7",
    gradient: "from-green-500 to-blue-600"
  }
];

export function StartScreen({ onComplete }: StartScreenProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showSlides, setShowSlides] = useState(false);

  useEffect(() => {
    // Показать слайды после анимации логотипа
    const timer = setTimeout(() => {
      setShowSlides(true);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const nextSlide = () => {
    if (currentSlide < introSlides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  return (
    <div style={{ 
      position: 'fixed', 
      top: 0, 
      left: 0, 
      right: 0, 
      bottom: 0, 
      background: 'linear-gradient(135deg, #0c0c0f 0%, #1a1a1f 50%, #2a2a3f 100%)',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }}>
      {/* Animated Background */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-1/4 left-1/4 w-64 h-64 bg-nasw-purple/20 rounded-full"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-nasw-accent/20 rounded-full"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
        />
      </div>

      <AnimatePresence mode="wait">
        {!showSlides ? (
          <div style={{ 
            textAlign: 'center', 
            color: 'white',
            padding: '40px'
          }}>
            <div style={{ 
              fontSize: '4rem', 
              marginBottom: '20px',
              color: '#9333ea'
            }}>
              ✨
            </div>
            <h1 style={{ 
              fontSize: '3rem', 
              fontWeight: 'bold', 
              marginBottom: '10px',
              background: 'linear-gradient(45deg, #9333ea, #a855f7)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              NASW AI
            </h1>
            <p style={{ 
              fontSize: '1.2rem', 
              color: 'rgba(255, 255, 255, 0.6)',
              marginBottom: '30px'
            }}>
              Нейросети нового поколения
            </p>
            <button 
              onClick={onComplete}
              style={{
                background: 'linear-gradient(135deg, #9333ea, #a855f7)',
                border: 'none',
                borderRadius: '16px',
                padding: '16px 32px',
                color: 'white',
                fontSize: '1.1rem',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 8px 25px rgba(147, 51, 234, 0.4)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              Сгенерировать!
            </button>
          </div>
        ) : (
          <motion.div
            key="slides"
            className="h-full flex flex-col"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            {/* Slide Content */}
            <div className="flex-1 flex items-center justify-center px-6">
              <motion.div
                key={currentSlide}
                className="text-center max-w-sm"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
              >
                <div className={`w-24 h-24 mx-auto mb-8 rounded-3xl bg-gradient-to-br ${introSlides[currentSlide].gradient} flex items-center justify-center liquid-glass`}>
                  {(() => {
                    const IconComponent = introSlides[currentSlide].icon;
                    return <IconComponent className="w-12 h-12 text-white" />;
                  })()}
                </div>
                
                <h2 className="text-3xl font-bold text-white mb-2">
                  {introSlides[currentSlide].title}
                </h2>
                
                <p className="text-lg text-nasw-purple-light mb-4">
                  {introSlides[currentSlide].subtitle}
                </p>
                
                <p className="text-white/60 leading-relaxed">
                  {introSlides[currentSlide].description}
                </p>
              </motion.div>
            </div>

            {/* Navigation Dots */}
            <div className="flex justify-center space-x-2 mb-8">
              {introSlides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentSlide 
                      ? 'bg-nasw-purple w-8' 
                      : 'bg-white/30'
                  }`}
                />
              ))}
            </div>

            {/* Action Button */}
            <div className="px-6 pb-safe-bottom">
              <motion.button
                onClick={onComplete}
                className="w-full liquid-button text-lg py-4"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Сгенерировать!
              </motion.button>
            </div>

            {/* Swipe Handlers */}
            <div 
              className="absolute inset-0 flex"
              onTouchStart={(e) => {
                const touch = e.touches[0];
                const startX = touch.clientX;
                
                const handleTouchEnd = (endEvent: TouchEvent) => {
                  const endX = endEvent.changedTouches[0].clientX;
                  const diff = startX - endX;
                  
                  if (Math.abs(diff) > 50) {
                    if (diff > 0) {
                      nextSlide();
                    } else {
                      prevSlide();
                    }
                  }
                  
                  document.removeEventListener('touchend', handleTouchEnd);
                };
                
                document.addEventListener('touchend', handleTouchEnd);
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}