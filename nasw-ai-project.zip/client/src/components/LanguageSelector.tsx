import { useStore } from '../store/useStore';

interface LanguageSelectorProps {
  onLanguageSelected: () => void;
}

export default function LanguageSelector({ onLanguageSelected }: LanguageSelectorProps) {
  const { setLanguage } = useStore();

  const languages = [
    { code: 'ru', name: 'Русский', flag: '🇷🇺' },
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'kz', name: 'Қазақша', flag: '🇰🇿' }
  ];

  const handleLanguageSelect = (langCode: 'ru' | 'en' | 'kz') => {
    setLanguage(langCode);
    onLanguageSelected();
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="glass-card p-8 rounded-3xl text-center">
          <h1 className="text-3xl font-bold gradient-text mb-2">
            Выберите язык
          </h1>
          <p className="text-white/60 mb-8">
            Choose your language
          </p>
          
          <div className="space-y-4">
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => handleLanguageSelect(lang.code as any)}
                className="w-full glass-button p-4 rounded-xl flex items-center gap-4 text-left hover:bg-purple-500/20 transition-all"
              >
                <span className="text-3xl">{lang.flag}</span>
                <span className="text-xl font-medium text-white">{lang.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}