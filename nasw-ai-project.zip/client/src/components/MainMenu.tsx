import { Image, CreditCard, BookOpen, HelpCircle, User, Globe, Gamepad2 } from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import { useStore } from '../store/useStore';

interface MainMenuProps {
  onNavigate: (page: string) => void;
}

export default function MainMenu({ onNavigate }: MainMenuProps) {
  const { language } = useStore();
  const t = useTranslation(language);

  const menuItems = [
    {
      id: 'generation',
      icon: Image,
      title: 'Генерация',
      subtitle: 'Создать контент',
      color: 'from-purple-500 to-blue-500'
    },
    {
      id: 'payment',
      icon: CreditCard,
      title: 'Платежи',
      subtitle: 'Пополнить баланс',
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 'gallery',
      icon: BookOpen,
      title: 'Галерея',
      subtitle: 'Мои работы',
      color: 'from-pink-500 to-rose-500'
    },
    {
      id: 'support',
      icon: HelpCircle,
      title: 'Поддержка',
      subtitle: 'Помощь и FAQ',
      color: 'from-orange-500 to-amber-500'
    },
    {
      id: 'profile',
      icon: User,
      title: 'Профиль',
      subtitle: 'Настройки',
      color: 'from-cyan-500 to-blue-500'
    },
    {
      id: 'language',
      icon: Globe,
      title: 'Язык',
      subtitle: 'Language',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      id: 'free-generation',
      icon: Gamepad2,
      title: 'Бесплатная генерация',
      subtitle: 'Игра в кубик',
      color: 'from-red-500 to-pink-500'
    }
  ];

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="text-center mb-8 pt-4">
          <h1 className="text-4xl font-bold gradient-text mb-2">NASW AI</h1>
          <p className="text-white/60">Нейросетевая платформа</p>
        </div>

        {/* Balance Card */}
        <div className="glass-card p-6 rounded-2xl mb-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/60 text-sm">Баланс</p>
              <p className="text-2xl font-bold text-white">150 кредитов</p>
            </div>
            <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-2 gap-4">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="glass-button p-6 rounded-2xl text-left group hover:scale-105 transition-all duration-200"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${item.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <item.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white font-semibold text-sm mb-1">
                {item.title}
              </h3>
              <p className="text-white/60 text-xs">
                {item.subtitle}
              </p>
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-white/40 text-xs">
          <p>NASW AI v1.0.0</p>
          <p>Powered by neural networks</p>
        </div>
      </div>
    </div>
  );
}