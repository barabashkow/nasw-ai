import { Zap, Wallet, Image, MessageCircle, User } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from '../lib/i18n';
import type { Language } from '../lib/i18n';

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  language: Language;
}

const tabs = [
  { id: 'profile', icon: User, translationKey: 'profile' },
  { id: 'generation', icon: Zap, translationKey: 'generation' },
  { id: 'payment', icon: Wallet, translationKey: 'payment' },
  { id: 'gallery', icon: Image, translationKey: 'gallery' },
  { id: 'support', icon: MessageCircle, translationKey: 'support' },
];

export function BottomNavigation({ activeTab, onTabChange, language }: BottomNavigationProps) {
  const t = useTranslation(language);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-3">
      <div className="max-w-sm mx-auto">
        <div className="bg-black/60 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl px-2 py-2">
          <div className="flex justify-between items-center relative">
            {tabs.map((tab) => (
              <motion.button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className="relative flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all duration-300 flex-1 min-w-0"
                whileTap={{ scale: 0.95 }}
                whileHover={{ scale: 1.05 }}
              >
                {/* Active Indicator */}
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-violet-500/20 rounded-xl border border-purple-500/30"
                    initial={false}
                    transition={{
                      type: "spring",
                      stiffness: 500,
                      damping: 30
                    }}
                  />
                )}
                
                <div className="relative z-10">
                  <tab.icon 
                    className={`w-5 h-5 transition-all duration-300 ${
                      activeTab === tab.id 
                        ? 'text-purple-400 drop-shadow-lg' 
                        : 'text-white/60'
                    }`} 
                  />
                </div>
                
                <span 
                  className={`text-xs font-medium relative z-10 transition-all duration-300 truncate ${
                    activeTab === tab.id 
                      ? 'text-white' 
                      : 'text-white/60'
                  }`}
                >
                  {t[tab.translationKey as keyof typeof t]}
                </span>
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}