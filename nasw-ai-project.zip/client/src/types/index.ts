export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
  photo_url?: string;
}

export interface TelegramWebApp {
  initData: string;
  initDataUnsafe: {
    user?: TelegramUser;
    auth_date: number;
    hash: string;
  };
  version: string;
  platform: string;
  colorScheme: 'light' | 'dark';
  themeParams: {
    bg_color: string;
    text_color: string;
    hint_color: string;
    link_color: string;
    button_color: string;
    button_text_color: string;
  };
  isExpanded: boolean;
  viewportHeight: number;
  viewportStableHeight: number;
  isClosingConfirmationEnabled: boolean;
  headerColor: string;
  backgroundColor: string;
  ready: () => void;
  expand: () => void;
  close: () => void;
  MainButton: {
    text: string;
    color: string;
    textColor: string;
    isVisible: boolean;
    isActive: boolean;
    isProgressVisible: boolean;
    setText: (text: string) => void;
    onClick: (fn: () => void) => void;
    offClick: (fn: () => void) => void;
    show: () => void;
    hide: () => void;
    enable: () => void;
    disable: () => void;
    showProgress: (leaveActive?: boolean) => void;
    hideProgress: () => void;
    setParams: (params: any) => void;
  };
  BackButton: {
    isVisible: boolean;
    onClick: (fn: () => void) => void;
    offClick: (fn: () => void) => void;
    show: () => void;
    hide: () => void;
  };
  HapticFeedback: {
    impactOccurred: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
    notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
    selectionChanged: () => void;
  };
  showAlert: (message: string, callback?: () => void) => void;
  showConfirm: (message: string, callback?: (confirmed: boolean) => void) => void;
  showPopup: (params: any, callback?: (button_id: string) => void) => void;
  showScanQrPopup: (params: any, callback?: (text: string) => void) => void;
  closeScanQrPopup: () => void;
  sendData: (data: string) => void;
  onEvent: (eventType: string, eventHandler: () => void) => void;
  offEvent: (eventType: string, eventHandler: () => void) => void;
}

export interface User {
  id: number;
  telegramId: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  languageCode: string;
  balance: number;
  isSubscribed: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface GeneratedContent {
  id: number;
  userId: number;
  type: 'text' | 'image' | 'video' | 'voice';
  prompt: string;
  style?: string;
  result?: any;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  cost?: number;
  createdAt: string;
  updatedAt: string;
}

export interface Ticket {
  id: number;
  userId: number;
  title: string;
  description: string;
  status: 'open' | 'in_progress' | 'closed';
  priority: 'low' | 'medium' | 'high';
  attachments?: any[];
  createdAt: string;
  updatedAt: string;
}

export interface TicketMessage {
  id: number;
  ticketId: number;
  senderId: number;
  message: string;
  isFromAdmin: boolean;
  attachments?: any[];
  createdAt: string;
}

export interface BalanceTransaction {
  id: number;
  userId: number;
  type: 'topup' | 'spend' | 'refund';
  amount: number;
  description?: string;
  transactionId?: string;
  createdAt: string;
}

export interface AppState {
  user: User | null;
  currentSection: 'balance' | 'generation' | 'gallery' | 'support';
  isLoading: boolean;
  generatedContent: GeneratedContent[];
  tickets: Ticket[];
  isGenerating: boolean;
  generationProgress: number;
}

export interface GenerationRequest {
  type: 'text' | 'image' | 'video' | 'voice';
  prompt: string;
  style?: string;
}

export interface TopupRequest {
  amount: number;
}

export interface TicketRequest {
  title: string;
  description: string;
  attachments?: File[];
}

export interface Language {
  code: string;
  name: string;
  flag: string;
}

export const LANGUAGES: Language[] = [
  { code: 'ru', name: 'Русский', flag: '🇷🇺' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'kz', name: 'Қазақша', flag: '🇰🇿' },
];

export const GENERATION_COSTS = {
  text: 10,
  image: 20,
  video: 50,
  voice: 15,
};

export const TOPUP_AMOUNTS = [100, 500, 1000, 2000, 5000];
