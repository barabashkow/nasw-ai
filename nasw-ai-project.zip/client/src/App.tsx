import { useState, useEffect } from "react";
import { QueryClient, QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "./components/ui/toaster";
import { useStore } from "./store/useStore";

// Import new components
import LoadingScreen from "./components/LoadingScreen";
import LanguageSelector from "./components/LanguageSelector";

import Home from "./pages/Home";
import { OnboardingScroll } from "./components/OnboardingScroll";

// Import pages
import GenerationPage from "./pages/GenerationPage";
import GalleryPage from "./pages/GalleryPage";
import PaymentPage from "./pages/PaymentPage";
import ProfilePage from "./pages/ProfilePage";
import SupportPage from "./pages/SupportPage";
import FreeGenerationPage from "./pages/FreeGenerationPage";

const queryClient = new QueryClient();

type AppState = 'loading' | 'language' | 'preview' | 'main' | 'page';

function AppContent() {
  const [appState, setAppState] = useState<AppState>('loading');
  const [currentPage, setCurrentPage] = useState('');
  const { language } = useStore();

  // Если язык уже выбран, переходим к главному меню
  useEffect(() => {
    if (language && appState === 'language') {
      setAppState('main');
    }
  }, [language, appState]);

  const handleLoadingComplete = () => {
    if (!language) {
      setAppState('language');
    } else {
      setAppState('main');
    }
  };

  const handleLanguageSelected = () => {
    setAppState('preview');
  };

  const handlePreviewComplete = () => {
    setAppState('main');
  };

  const handleNavigation = (page: string) => {
    if (page === 'language') {
      setAppState('language');
      return;
    }
    setCurrentPage(page);
    setAppState('page');
  };

  const handleBackToMain = () => {
    setAppState('main');
    setCurrentPage('');
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'generation':
        return <GenerationPage onBack={handleBackToMain} />;
      case 'payment':
        return <PaymentPage onBack={handleBackToMain} />;
      case 'gallery':
        return <GalleryPage onBack={handleBackToMain} />;
      case 'support':
        return <SupportPage onBack={handleBackToMain} />;
      case 'profile':
        return <ProfilePage onBack={handleBackToMain} />;
      case 'free-generation':
        return <FreeGenerationPage onBack={handleBackToMain} />;
      default:
        return <Home onNavigate={handleNavigation} />;
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {appState === 'loading' && (
        <LoadingScreen onComplete={handleLoadingComplete} />
      )}
      
      {appState === 'language' && (
        <LanguageSelector onLanguageSelected={handleLanguageSelected} />
      )}
      
      {appState === 'preview' && (
        <OnboardingScroll onComplete={handlePreviewComplete} language={language} />
      )}
      
      {appState === 'main' && !currentPage && (
        <Home onNavigate={handleNavigation} />
      )}
      
      {appState === 'page' && currentPage && (
        renderCurrentPage()
      )}
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
      <Toaster />
    </QueryClientProvider>
  );
}
