import { useState } from 'react';
import SubscriptionModal from '../components/SubscriptionModal';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useTranslation } from '../lib/i18n';
import { useStore } from '../store/useStore';
import { useToast } from '../hooks/use-toast';
import { ArrowLeft, Dice1, Dice2, Dice3, Dice4, Dice5, Dice6, Trophy, Clock, Gift } from 'lucide-react';

interface FreeGenerationPageProps {
  onBack: () => void;
}

export default function FreeGenerationPage({ onBack }: FreeGenerationPageProps) {
  const { language } = useStore();
  const t = useTranslation(language);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [gameResult, setGameResult] = useState<any>(null);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);

  // Get game status
  const { data: gameStatus, isLoading } = useQuery({
    queryKey: ['/api/dice-game-status']
  });

  // Roll dice mutation
  const rollDiceMutation = useMutation({
    mutationFn: (guessedNumber: number) => 
      apiRequest('POST', '/api/roll-dice', { guessedNumber }),
    onSuccess: (data) => {
      setGameResult(data);
      queryClient.invalidateQueries({ queryKey: ['/api/dice-game-status'] });
      
      if (data.won) {
        toast({
          title: "Поздравляем! 🎉",
          description: "Вы выиграли бесплатную генерацию!",
        });
      } else {
        toast({
          title: "Почти попали!",
          description: `Выпало ${data.rolledNumber}, а вы угадывали ${data.guessedNumber}`,
          variant: "destructive"
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось бросить кубик",
        variant: "destructive"
      });
    }
  });

  const handleNumberSelect = (number: number) => {
    setSelectedNumber(number);
  };

  const handleRollDice = () => {
    if (!selectedNumber || gameStatus?.canPlay === false) return;
    
    // Проверяем подписку перед игрой
    if (!isSubscribed) {
      setShowSubscriptionModal(true);
      return;
    }
    
    rollDiceMutation.mutate(selectedNumber);
  };

  const handleSubscriptionVerified = () => {
    setIsSubscribed(true);
    // Автоматически запускаем игру после подписки
    if (selectedNumber && gameStatus?.canPlay !== false) {
      rollDiceMutation.mutate(selectedNumber);
    }
  };

  const diceIcons = [Dice1, Dice2, Dice3, Dice4, Dice5, Dice6];

  const formatTimeRemaining = (nextAttemptAt: string) => {
    const now = new Date();
    const nextAttempt = new Date(nextAttemptAt);
    const diff = nextAttempt.getTime() - now.getTime();
    
    if (diff <= 0) return "Можно играть!";
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}ч ${minutes}м`;
  };

  return (
    <div className="min-h-screen p-4 bg-black"
      style={{
        background: 'radial-gradient(ellipse at top left, rgba(60, 40, 80, 0.3) 0%, transparent 50%), radial-gradient(ellipse at top right, rgba(80, 60, 110, 0.25) 0%, transparent 50%), radial-gradient(ellipse at bottom, rgba(100, 80, 140, 0.15) 0%, transparent 50%), linear-gradient(180deg, #000000 0%, #1a0d2e 50%, #000000 100%)',
        minHeight: '100vh'
      }}>
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold gradient-text text-center">
            Бесплатная генерация
          </h1>
        </div>

        <div className="space-y-6">
          {/* Game Info */}
          <div className="glass-card p-6 rounded-2xl text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-yellow-500 to-orange-500 flex items-center justify-center">
              <Gift className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">
              Игра в кубик
            </h2>
            <p className="text-white/60 text-sm mb-4">
              Угадайте число от 1 до 6 и получите бесплатную генерацию изображения!
            </p>
            
            {isLoading ? (
              <div className="loading-spinner mx-auto" />
            ) : (
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="glass-card p-3 rounded-xl">
                  <div className="text-lg font-bold text-yellow-400">{gameStatus?.totalAttempts || 0}</div>
                  <div className="text-xs text-gray-300">Попыток</div>
                </div>
                <div className="glass-card p-3 rounded-xl">
                  <div className="text-lg font-bold text-green-400">{gameStatus?.wins || 0}</div>
                  <div className="text-xs text-gray-300">Побед</div>
                </div>
              </div>
            )}
          </div>

          {/* Game Status */}
          {gameStatus && (
            <div className="glass-card p-6 rounded-2xl">
              {gameStatus.canPlay ? (
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-green-500/20 flex items-center justify-center">
                    <Trophy className="w-6 h-6 text-green-400" />
                  </div>
                  <p className="text-white font-semibold">Можно играть!</p>
                  <p className="text-gray-300 text-sm">Выберите число и попробуйте удачу</p>
                </div>
              ) : (
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-red-500/20 flex items-center justify-center">
                    <Clock className="w-6 h-6 text-red-400" />
                  </div>
                  <p className="text-white font-semibold">Следующая попытка через:</p>
                  <p className="text-red-400 text-lg font-mono">
                    {formatTimeRemaining(gameStatus.nextAttemptAt)}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Number Selection */}
          {gameStatus?.canPlay && !gameResult && (
            <div className="glass-card p-6 rounded-2xl">
              <h3 className="text-lg font-semibold text-white mb-4 text-center">
                Выберите число от 1 до 6
              </h3>
              <div className="grid grid-cols-3 gap-3">
                {[1, 2, 3, 4, 5, 6].map((number) => {
                  const DiceIcon = diceIcons[number - 1];
                  return (
                    <button
                      key={number}
                      onClick={() => handleNumberSelect(number)}
                      className={`glass-button p-4 rounded-xl text-center ${
                        selectedNumber === number ? 'bg-purple-500/30 border-purple-400' : ''
                      }`}
                    >
                      <DiceIcon className="w-8 h-8 mx-auto mb-2 text-white" />
                      <div className="text-white font-bold">{number}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Roll Button */}
          {gameStatus?.canPlay && selectedNumber && !gameResult && (
            <button
              onClick={handleRollDice}
              disabled={rollDiceMutation.isPending}
              className="w-full glass-button p-4 rounded-xl text-white font-semibold text-lg"
            >
              {rollDiceMutation.isPending ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="loading-spinner w-5 h-5" />
                  Бросаем кубик...
                </div>
              ) : (
                `Бросить кубик (выбрано: ${selectedNumber})`
              )}
            </button>
          )}

          {/* Game Result */}
          {gameResult && (
            <div className="glass-card p-6 rounded-2xl text-center">
              <div className={`w-20 h-20 mx-auto mb-4 rounded-full ${
                gameResult.won ? 'bg-green-500/20' : 'bg-red-500/20'
              } flex items-center justify-center`}>
                {React.createElement(diceIcons[gameResult.rolledNumber - 1], {
                  className: `w-10 h-10 ${gameResult.won ? 'text-green-400' : 'text-red-400'}`
                })}
              </div>
              
              <h3 className={`text-xl font-bold mb-2 ${
                gameResult.won ? 'text-green-400' : 'text-red-400'
              }`}>
                {gameResult.won ? 'Поздравляем!' : 'Не угадали!'}
              </h3>
              
              <p className="text-white mb-4">
                Выпало: <span className="font-bold">{gameResult.rolledNumber}</span>
                <br />
                Ваше число: <span className="font-bold">{gameResult.guessedNumber}</span>
              </p>

              {gameResult.won ? (
                <div className="glass-card p-4 rounded-xl bg-green-500/10">
                  <p className="text-green-400 font-semibold">
                    🎉 Вы выиграли бесплатную генерацию изображения!
                  </p>
                  <p className="text-gray-300 text-sm mt-2">
                    Перейдите в раздел "Генерация" чтобы воспользоваться призом
                  </p>
                </div>
              ) : (
                <p className="text-gray-300 text-sm">
                  Попробуйте снова завтра!
                </p>
              )}

              <button
                onClick={() => {
                  setGameResult(null);
                  setSelectedNumber(null);
                }}
                className="w-full glass-button p-3 rounded-xl text-white mt-4"
              >
                Попробовать еще раз
              </button>
            </div>
          )}

          {/* Rules */}
          <div className="glass-card p-4 rounded-xl">
            <h4 className="text-white font-semibold mb-2">Правила игры</h4>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• Выберите число от 1 до 6</li>
              <li>• Если угадаете - получите бесплатную генерацию</li>
              <li>• Играть можно один раз в 24 часа</li>
              <li>• Приз не суммируется с другими</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Subscription Modal */}
      <SubscriptionModal
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
        onVerified={handleSubscriptionVerified}
      />
    </div>
  );
}