import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useTranslation } from '../lib/i18n';
import { useStore } from '../store/useStore';
import { useToast } from '../hooks/use-toast';
import { ArrowLeft, MessageCircle, Send, Paperclip, Mic, HelpCircle } from 'lucide-react';

interface SupportPageProps {
  onBack: () => void;
}

export default function SupportPage({ onBack }: SupportPageProps) {
  const { language } = useStore();
  const t = useTranslation(language);
  const { toast } = useToast();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('general');

  const createTicketMutation = useMutation({
    mutationFn: (data: { title: string; description: string; category: string }) => 
      apiRequest('POST', '/api/tickets', data),
    onSuccess: () => {
      toast({
        title: "Обращение отправлено",
        description: "Мы ответим в течение 24 часов",
      });
      setTitle('');
      setDescription('');
      setSelectedCategory('general');
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось отправить обращение",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = () => {
    if (!title.trim() || !description.trim()) {
      toast({
        title: "Заполните все поля",
        description: "Укажите тему и описание проблемы",
        variant: "destructive"
      });
      return;
    }
    
    createTicketMutation.mutate({
      title: title.trim(),
      description: description.trim(),
      category: selectedCategory
    });
  };

  const categories = [
    { id: 'general', name: 'Общие вопросы', icon: HelpCircle },
    { id: 'payment', name: 'Оплата', icon: MessageCircle },
    { id: 'technical', name: 'Технические проблемы', icon: MessageCircle },
    { id: 'content', name: 'Проблемы с контентом', icon: MessageCircle }
  ];

  return (
    <div className="min-h-screen p-4 bg-black"
      style={{
        background: 'radial-gradient(ellipse at top left, rgba(60, 40, 80, 0.3) 0%, transparent 50%), radial-gradient(ellipse at top right, rgba(80, 60, 110, 0.25) 0%, transparent 50%), radial-gradient(ellipse at bottom, rgba(100, 80, 140, 0.15) 0%, transparent 50%), linear-gradient(180deg, #000000 0%, #1a0d2e 50%, #000000 100%)',
        minHeight: '100vh'
      }}>
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold gradient-text text-center">
            {t.support}
          </h1>
        </div>

        <div className="space-y-6">
          {/* Quick Help */}
          <div className="glass-card p-6 rounded-2xl">
            <h2 className="text-lg font-semibold text-white mb-4">
              Частые вопросы
            </h2>
            <div className="space-y-3">
              <div className="glass-card p-3 rounded-xl">
                <h4 className="text-white font-medium mb-1">Как получить кредиты?</h4>
                <p className="text-gray-300 text-sm">
                  Пополните баланс в разделе "Платежи" или выиграйте в игре
                </p>
              </div>
              <div className="glass-card p-3 rounded-xl">
                <h4 className="text-white font-medium mb-1">Сколько стоит генерация?</h4>
                <p className="text-gray-300 text-sm">
                  Изображение - 15 кредитов, видео - 100 кредитов
                </p>
              </div>
              <div className="glass-card p-3 rounded-xl">
                <h4 className="text-white font-medium mb-1">Как работает игра в кубик?</h4>
                <p className="text-gray-300 text-sm">
                  Угадайте число от 1 до 6. При выигрыше получите бесплатную генерацию
                </p>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="glass-card p-6 rounded-2xl">
            <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Написать в поддержку
            </h2>
            
            {/* Category Selection */}
            <div className="mb-4">
              <label className="block text-white font-medium mb-2">Категория</label>
              <div className="grid grid-cols-2 gap-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`glass-button p-3 rounded-xl text-sm text-center ${
                      selectedCategory === category.id ? 'bg-purple-500/30 border-purple-400' : ''
                    }`}
                  >
                    <category.icon className="w-4 h-4 mx-auto mb-1" />
                    <div className="text-white">{category.name}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Title Input */}
            <div className="mb-4">
              <label className="block text-white font-medium mb-2">Тема обращения</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Кратко опишите проблему"
                className="w-full bg-black/20 border border-purple-500/30 rounded-xl p-3 text-white placeholder-gray-400 focus:border-purple-400 focus:outline-none"
                maxLength={100}
              />
              <div className="text-right text-xs text-gray-400 mt-1">{title.length}/100</div>
            </div>

            {/* Description Input */}
            <div className="mb-4">
              <label className="block text-white font-medium mb-2">Подробное описание</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Опишите проблему подробно, укажите шаги для воспроизведения"
                className="w-full h-32 bg-black/20 border border-purple-500/30 rounded-xl p-3 text-white placeholder-gray-400 resize-none focus:border-purple-400 focus:outline-none"
                maxLength={500}
              />
              <div className="text-right text-xs text-gray-400 mt-1">{description.length}/500</div>
            </div>

            {/* Attachments */}
            <div className="mb-6">
              <label className="block text-white font-medium mb-2">Прикрепить файлы</label>
              <div className="flex gap-2">
                <button className="glass-button p-3 rounded-xl flex items-center gap-2">
                  <Paperclip className="w-4 h-4 text-purple-400" />
                  <span className="text-white text-sm">Файл</span>
                </button>
                <button className="glass-button p-3 rounded-xl flex items-center gap-2">
                  <Mic className="w-4 h-4 text-purple-400" />
                  <span className="text-white text-sm">Голосовое</span>
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              onClick={handleSubmit}
              disabled={createTicketMutation.isPending || !title.trim() || !description.trim()}
              className="w-full glass-button p-4 rounded-xl text-white font-semibold text-lg disabled:opacity-50"
            >
              {createTicketMutation.isPending ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="loading-spinner w-5 h-5" />
                  Отправляем...
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2">
                  <Send className="w-5 h-5" />
                  Отправить обращение
                </div>
              )}
            </button>
          </div>

          {/* Contact Info */}
          <div className="glass-card p-4 rounded-xl text-center">
            <h4 className="text-white font-semibold mb-2">Связь с разработчиками</h4>
            <p className="text-gray-300 text-sm mb-2">
              Время ответа: обычно в течение 24 часов
            </p>
            <p className="text-gray-400 text-xs">
              При критических проблемах пишите в Telegram: @support
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}