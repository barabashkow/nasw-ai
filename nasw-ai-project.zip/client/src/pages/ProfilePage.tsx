import { useState, useEffect } from 'react';
import { ArrowLeft, Dice6, Globe, Settings, Copy, Share2, ChevronDown, Clock, Bell, Receipt } from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import { useStore } from '../store/useStore';
import { motion, AnimatePresence } from 'framer-motion';

interface ProfilePageProps {
  onBack: () => void;
}

export default function ProfilePage({ onBack }: ProfilePageProps) {
  const { language, setLanguage, user, lastDiceRoll, setLastDiceRoll } = useStore();
  const t = useTranslation(language);
  const [showDiceGame, setShowDiceGame] = useState(false);
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [diceResult, setDiceResult] = useState<number | null>(null);
  const [isRolling, setIsRolling] = useState(false);
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const [showSettingsDropdown, setShowSettingsDropdown] = useState(false);
  const [timeUntilNextRoll, setTimeUntilNextRoll] = useState<string>('');

  // Mock user data with Telegram integration
  const telegramUser = {
    id: 123456789,
    firstName: user?.firstName || 'User',
    photoUrl: user?.photoUrl || null,
    tokens: user?.tokens || 0,
    referralCount: user?.referralCount || 0,
    referralEarnings: user?.referralEarnings || 0
  };

  // Calculate time until next dice roll
  useEffect(() => {
    const interval = setInterval(() => {
      if (lastDiceRoll) {
        const now = Date.now();
        const timePassed = now - lastDiceRoll;
        const timeLeft = 24 * 60 * 60 * 1000 - timePassed; // 24 hours

        if (timeLeft > 0) {
          const hours = Math.floor(timeLeft / (60 * 60 * 1000));
          const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
          const seconds = Math.floor((timeLeft % (60 * 1000)) / 1000);
          setTimeUntilNextRoll(`${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
        } else {
          setTimeUntilNextRoll('');
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [lastDiceRoll]);

  const handleDiceClick = () => {
    const now = Date.now();
    if (lastDiceRoll && now - lastDiceRoll < 24 * 60 * 60 * 1000) {
      return; // Still in cooldown
    }
    setShowDiceGame(true);
  };

  const rollDice = () => {
    if (selectedNumber === null) return;

    setIsRolling(true);
    // Simulate dice roll
    setTimeout(() => {
      const result = Math.floor(Math.random() * 6) + 1;
      setDiceResult(result);
      setIsRolling(false);
      setLastDiceRoll(Date.now());

      if (result === selectedNumber) {
        // Win! Add free generation token
        // API call would go here
      }
    }, 2000);
  };

  const getReferralLink = () => {
    return `https://t.me/NASW_AI_Bot?start=ref${telegramUser.id}`;
  };

  const copyReferralLink = () => {
    navigator.clipboard.writeText(getReferralLink());
  };

  const shareReferralLink = () => {
    if (navigator.share) {
      navigator.share({
        title: 'NASW AI',
        text: language === 'ru' ? 'Присоединяйтесь к NASW AI!' : language === 'en' ? 'Join NASW AI!' : 'NASW AI-ға қосылыңыз!',
        url: getReferralLink()
      });
    }
  };

  const languageOptions = [
    { code: 'ru', name: 'Русский' },
    { code: 'en', name: 'English' },
    { code: 'kz', name: 'Қазақша' }
  ];

  const getLanguageLabel = () => {
    return languageOptions.find(opt => opt.code === language)?.name || 'Русский';
  };

  const settingsOptions = [
    { id: 'notifications', icon: Bell, label: language === 'ru' ? 'Уведомления' : language === 'en' ? 'Notifications' : 'Хабарландырулар' },
    { id: 'payments', icon: Receipt, label: language === 'ru' ? 'История платежей' : language === 'en' ? 'Payment History' : 'Төлем тарихы' }
  ];

  return (
    <div className="min-h-screen p-4 bg-black"
      style={{
        background: 'radial-gradient(ellipse at top left, rgba(60, 40, 80, 0.3) 0%, transparent 50%), radial-gradient(ellipse at top right, rgba(80, 60, 110, 0.25) 0%, transparent 50%), radial-gradient(ellipse at bottom, rgba(100, 80, 140, 0.15) 0%, transparent 50%), linear-gradient(180deg, #000000 0%, #1a0d2e 50%, #000000 100%)',
        minHeight: '100vh'
      }}>
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white text-center">
            {language === 'ru' ? 'Профиль' : language === 'en' ? 'Profile' : 'Профиль'}
          </h1>
        </div>

        <div className="space-y-4">
          {/* User Info */}
          <div className="glass-card p-6 rounded-2xl">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 to-violet-500 flex items-center justify-center overflow-hidden">
                  {telegramUser.photoUrl ? (
                    <img src={telegramUser.photoUrl} alt={telegramUser.firstName} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-2xl font-bold text-white">
                      {telegramUser.firstName.charAt(0).toUpperCase()}
                    </span>
                  )}
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-white">{telegramUser.firstName}</h2>
                  <div className="flex items-center gap-2">
                    <p className="text-gray-400 text-sm">ID: {telegramUser.id}</p>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(telegramUser.id.toString());
                      }}
                      className="text-purple-400 hover:text-purple-300 transition-colors"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-white">{telegramUser.tokens}</div>
                <div className="text-sm text-gray-400">
                  {language === 'ru' ? 'токенов' : language === 'en' ? 'tokens' : 'токен'}
                </div>
              </div>
            </div>
          </div>

          {/* Free Generation Button */}
          <button
            onClick={handleDiceClick}
            disabled={!!timeUntilNextRoll}
            className="w-full glass-card p-4 rounded-xl flex items-center justify-between group hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:hover:scale-100"
          >
            <div className="flex items-center gap-3">
              <Dice6 className="w-6 h-6 text-purple-400" />
              <span className="text-white font-medium">
                {language === 'ru' ? 'Бесплатная генерация' : language === 'en' ? 'Free Generation' : 'Тегін генерация'}
              </span>
            </div>
            {timeUntilNextRoll && (
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Clock className="w-4 h-4" />
                <span>{timeUntilNextRoll}</span>
              </div>
            )}
          </button>

          {/* Language Selector */}
          <div className="relative">
            <button
              onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
              className="w-full glass-card p-4 rounded-xl flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <Globe className="w-6 h-6 text-purple-400" />
                <span className="text-white font-medium">
                  {language === 'ru' ? 'Язык интерфейса' : language === 'en' ? 'Interface Language' : 'Интерфейс тілі'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-300">{getLanguageLabel()}</span>
                <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showLanguageDropdown ? 'rotate-180' : ''}`} />
              </div>
            </button>

            <AnimatePresence>
              {showLanguageDropdown && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-full mt-2 w-full glass-card rounded-xl overflow-hidden z-10"
                >
                  {languageOptions.map((option) => (
                    <button
                      key={option.code}
                      onClick={() => {
                        setLanguage(option.code as any);
                        setShowLanguageDropdown(false);
                      }}
                      className={`w-full p-3 text-left hover:bg-white/10 transition-colors ${
                        language === option.code ? 'bg-purple-500/20' : ''
                      }`}
                    >
                      <span className="text-white">{option.name}</span>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Settings */}
          <div className="relative">
            <button
              onClick={() => setShowSettingsDropdown(!showSettingsDropdown)}
              className="w-full glass-card p-4 rounded-xl flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <Settings className="w-6 h-6 text-purple-400" />
                <span className="text-white font-medium">
                  {language === 'ru' ? 'Настройки' : language === 'en' ? 'Settings' : 'Параметрлер'}
                </span>
              </div>
              <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showSettingsDropdown ? 'rotate-180' : ''}`} />
            </button>

            <AnimatePresence>
              {showSettingsDropdown && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-full mt-2 w-full glass-card rounded-xl overflow-hidden z-10"
                >
                  {settingsOptions.map((option) => (
                    <button
                      key={option.id}
                      onClick={() => {
                        // Handle settings option click
                        setShowSettingsDropdown(false);
                      }}
                      className="w-full p-3 text-left hover:bg-white/10 transition-colors flex items-center gap-3"
                    >
                      <option.icon className="w-5 h-5 text-purple-400" />
                      <span className="text-white">{option.label}</span>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Referral System */}
          <div className="glass-card p-6 rounded-2xl space-y-4">
            <h3 className="text-lg font-semibold text-white mb-2">
              {language === 'ru' ? 'Реферальная система' : language === 'en' ? 'Referral System' : 'Реферал жүйесі'}
            </h3>
            <p className="text-sm text-gray-400">
              {language === 'ru' ? 'Получайте 15% комиссии от платежей рефералов' : language === 'en' ? 'Get 15% commission from referral payments' : 'Рефералдар төлемдерінен 15% комиссия алыңыз'}
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="glass-card p-3 rounded-xl text-center">
                <div className="text-2xl font-bold text-white">{telegramUser.referralCount}</div>
                <div className="text-sm text-gray-400">
                  {language === 'ru' ? 'Рефералов' : language === 'en' ? 'Referrals' : 'Рефералдар'}
                </div>
              </div>
              <div className="glass-card p-3 rounded-xl text-center">
                <div className="text-2xl font-bold text-white">{telegramUser.referralEarnings}</div>
                <div className="text-sm text-gray-400">
                  {language === 'ru' ? 'Заработано' : language === 'en' ? 'Earned' : 'Табыс'}
                </div>
              </div>
            </div>

            <button
              onClick={shareReferralLink}
              className="w-full glass-button p-3 rounded-xl flex items-center justify-center gap-2 hover:scale-105 transition-all"
            >
              <Share2 className="w-5 h-5" />
              <span className="font-medium">
                {language === 'ru' ? 'Пригласить' : language === 'en' ? 'Invite' : 'Шақыру'}
              </span>
            </button>

            <div className="flex items-center gap-2 p-3 bg-black/20 rounded-xl">
              <input
                readOnly
                value={getReferralLink()}
                className="flex-1 bg-transparent text-sm text-gray-300 outline-none"
              />
              <button
                onClick={copyReferralLink}
                className="glass-button p-2 rounded-lg"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Dice Game Modal */}
      <AnimatePresence>
        {showDiceGame && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => !isRolling && setShowDiceGame(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="glass-card p-6 rounded-2xl max-w-sm w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-xl font-bold text-white mb-4 text-center">
                {language === 'ru' ? 'Выберите число от 1 до 6' : language === 'en' ? 'Choose a number from 1 to 6' : '1-ден 6-ға дейін сан таңдаңыз'}
              </h3>

              {!diceResult ? (
                <>
                  <div className="grid grid-cols-3 gap-3 mb-6">
                    {[1, 2, 3, 4, 5, 6].map((num) => (
                      <button
                        key={num}
                        onClick={() => setSelectedNumber(num)}
                        className={`glass-button p-4 rounded-xl text-2xl font-bold transition-all ${
                          selectedNumber === num ? 'bg-purple-500/30 border-purple-400' : ''
                        }`}
                      >
                        {num}
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={rollDice}
                    disabled={selectedNumber === null || isRolling}
                    className="w-full glass-button p-4 rounded-xl font-medium disabled:opacity-50"
                  >
                    {isRolling ? (
                      <div className="flex items-center justify-center gap-2">
                        <Dice6 className="w-6 h-6 animate-spin" />
                        <span>{language === 'ru' ? 'Бросаем кубик...' : language === 'en' ? 'Rolling dice...' : 'Сүйек лақтыру...'}</span>
                      </div>
                    ) : (
                      <span>{language === 'ru' ? 'Бросить кубик' : language === 'en' ? 'Roll Dice' : 'Сүйек лақтыру'}</span>
                    )}
                  </button>
                </>
              ) : (
                <div className="text-center">
                  <div className="text-6xl mb-4">🎲</div>
                  <div className="text-3xl font-bold text-white mb-2">{diceResult}</div>
                  <div className="text-lg text-gray-300 mb-6">
                    {diceResult === selectedNumber ? (
                      <span className="text-green-400">
                        {language === 'ru' ? 'Вы выиграли! +1 бесплатное видео' : language === 'en' ? 'You won! +1 free video' : 'Сіз жеңдіңіз! +1 тегін бейне'}
                      </span>
                    ) : (
                      <span className="text-red-400">
                        {language === 'ru' ? 'Не угадали. Попробуйте через 24 часа' : language === 'en' ? 'Wrong guess. Try again in 24 hours' : 'Дұрыс емес. 24 сағаттан кейін қайталаңыз'}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => {
                      setShowDiceGame(false);
                      setDiceResult(null);
                      setSelectedNumber(null);
                    }}
                    className="glass-button px-6 py-3 rounded-xl font-medium"
                  >
                    {language === 'ru' ? 'Закрыть' : language === 'en' ? 'Close' : 'Жабу'}
                  </button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}