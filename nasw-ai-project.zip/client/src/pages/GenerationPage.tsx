import { useState } from 'react';
import { ArrowLeft, Image, Video, Music, Mic, Loader2, Download, Share2 } from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import { useStore } from '../store/useStore';
import { motion, AnimatePresence } from 'framer-motion';
import { apiRequest } from '../lib/queryClient';
import { useToast } from '../hooks/use-toast';

interface GenerationPageProps {
  onBack: () => void;
}

type GenerationType = 'photo' | 'video' | 'music' | 'voice';

interface GenerationTab {
  id: GenerationType;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle: string;
  gradient: string;
  available: boolean;
}

export default function GenerationPage({ onBack }: GenerationPageProps) {
  const { language, user } = useStore();
  const t = useTranslation(language);
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<GenerationType>('photo');
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<{
    type: GenerationType;
    url: string;
    prompt: string;
  } | null>(null);

  const tabs: GenerationTab[] = [
    {
      id: 'photo',
      icon: Image,
      title: language === 'ru' ? 'Фото' : language === 'en' ? 'Photo' : 'Фото',
      subtitle: language === 'ru' ? 'HD изображения' : language === 'en' ? 'HD Images' : 'HD суреттер',
      gradient: 'from-blue-500 to-cyan-500',
      available: true
    },
    {
      id: 'video',
      icon: Video,
      title: language === 'ru' ? 'Видео' : language === 'en' ? 'Video' : 'Бейне',
      subtitle: language === 'ru' ? 'Скоро доступно' : language === 'en' ? 'Coming Soon' : 'Жақында',
      gradient: 'from-red-500 to-pink-500',
      available: false
    },
    {
      id: 'music',
      icon: Music,
      title: language === 'ru' ? 'Музыка' : language === 'en' ? 'Music' : 'Музыка',
      subtitle: language === 'ru' ? 'В разработке' : language === 'en' ? 'In Development' : 'Әзірленуде',
      gradient: 'from-green-500 to-emerald-500',
      available: false
    },
    {
      id: 'voice',
      icon: Mic,
      title: language === 'ru' ? 'Голос' : language === 'en' ? 'Voice' : 'Дауыс',
      subtitle: language === 'ru' ? 'В разработке' : language === 'en' ? 'In Development' : 'Әзірленуде',
      gradient: 'from-purple-500 to-violet-500',
      available: false
    }
  ];

  const activeTabData = tabs.find(tab => tab.id === activeTab)!;

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: language === 'ru' ? 'Ошибка' : language === 'en' ? 'Error' : 'Қате',
        description: language === 'ru' ? 'Введите описание' : language === 'en' ? 'Enter description' : 'Сипаттаманы енгізіңіз',
        variant: 'destructive'
      });
      return;
    }

    // Check if user has tokens
    if (!user?.tokens || user.tokens < 1) {
      toast({
        title: language === 'ru' ? 'Недостаточно токенов' : language === 'en' ? 'Not enough tokens' : 'Токендер жеткіліксіз',
        description: language === 'ru' ? 'Пополните баланс' : language === 'en' ? 'Top up balance' : 'Балансты толтырыңыз',
        variant: 'destructive'
      });
      return;
    }

    setIsGenerating(true);
    try {
      const response = await apiRequest('POST', '/api/generate', {
        type: activeTab,
        prompt: prompt
      });

      if (response.ok) {
        const data = await response.json();
        setGeneratedContent({
          type: activeTab,
          url: data.url,
          prompt: prompt
        });
        setPrompt('');
      } else {
        throw new Error('Generation failed');
      }
    } catch (error) {
      toast({
        title: language === 'ru' ? 'Ошибка генерации' : language === 'en' ? 'Generation error' : 'Генерация қатесі',
        description: language === 'ru' ? 'Попробуйте еще раз' : language === 'en' ? 'Try again' : 'Қайтадан көріңіз',
        variant: 'destructive'
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    if (generatedContent) {
      // Download the image
      const a = document.createElement('a');
      a.href = generatedContent.url;
      a.download = `nasw-ai-${Date.now()}.png`;
      a.click();
    }
  };

  const handleShare = () => {
    if (generatedContent && navigator.share) {
      navigator.share({
        title: 'NASW AI',
        text: generatedContent.prompt,
        url: generatedContent.url
      });
    }
  };

  return (
    <div className="min-h-screen p-4 bg-black"
      style={{
        background: 'radial-gradient(ellipse at top left, rgba(60, 40, 80, 0.3) 0%, transparent 50%), radial-gradient(ellipse at top right, rgba(80, 60, 110, 0.25) 0%, transparent 50%), radial-gradient(ellipse at bottom, rgba(100, 80, 140, 0.15) 0%, transparent 50%), linear-gradient(180deg, #000000 0%, #1a0d2e 50%, #000000 100%)',
        minHeight: '100vh'
      }}>
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white text-center">
            {language === 'ru' ? 'Генерация' : language === 'en' ? 'Generation' : 'Генерация'}
          </h1>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => tab.available && setActiveTab(tab.id)}
              disabled={!tab.available}
              className={`relative group overflow-hidden rounded-2xl transition-all duration-300 ${
                activeTab === tab.id
                  ? 'scale-105'
                  : 'scale-100 hover:scale-105'
              } ${!tab.available ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className={`absolute inset-0 bg-gradient-to-r ${tab.gradient} opacity-20`} />
              <div className={`relative glass-card p-4 border-2 transition-all ${
                activeTab === tab.id
                  ? 'border-purple-400 bg-purple-500/10'
                  : 'border-transparent'
              }`}>
                <tab.icon className={`w-8 h-8 mb-2 mx-auto ${
                  activeTab === tab.id ? 'text-purple-400' : 'text-white/70'
                }`} />
                <h3 className="font-semibold text-white">{tab.title}</h3>
                <p className="text-xs text-gray-400 mt-1">{tab.subtitle}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <AnimatePresence mode="wait">
          {!generatedContent ? (
            <motion.div
              key="input"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              {activeTabData.available ? (
                <>
                  <div className="glass-card p-6 rounded-2xl">
                    <label className="block text-white font-medium mb-3">
                      {language === 'ru' ? 'Опишите изображение' : language === 'en' ? 'Describe the image' : 'Суретті сипаттаңыз'}
                    </label>
                    <textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      placeholder={
                        language === 'ru' 
                          ? 'Например: космический корабль в стиле киберпанк...' 
                          : language === 'en'
                          ? 'For example: cyberpunk style spaceship...'
                          : 'Мысалы: киберпанк стиліндегі ғарыш кемесі...'
                      }
                      className="w-full min-h-[120px] bg-black/20 border border-white/10 rounded-xl p-4 text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 transition-colors resize-none"
                      disabled={isGenerating}
                    />
                    <div className="flex items-center justify-between mt-3">
                      <span className="text-sm text-gray-400">
                        {language === 'ru' ? 'Стоимость: 1 токен' : language === 'en' ? 'Cost: 1 token' : 'Құны: 1 токен'}
                      </span>
                      <span className="text-sm text-gray-400">
                        {prompt.length}/500
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={handleGenerate}
                    disabled={isGenerating || !prompt.trim()}
                    className={`glass-button mx-auto mt-4 font-medium flex items-center justify-center gap-2 ${
                      isGenerating ? 'opacity-50' : 'hover:scale-102'
                    } transition-all duration-300`}
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>
                          {language === 'ru' ? 'Генерация...' : language === 'en' ? 'Generating...' : 'Генерация...'}
                        </span>
                      </>
                    ) : (
                      <span>
                        {language === 'ru' ? 'Сгенерировать' : language === 'en' ? 'Generate' : 'Генерациялау'}
                      </span>
                    )}
                  </button>
                </>
              ) : (
                <div className="glass-card p-8 rounded-2xl text-center">
                  <activeTabData.icon className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-xl font-semibold text-white mb-2">
                    {language === 'ru' ? 'Скоро будет доступно' : language === 'en' ? 'Coming Soon' : 'Жақында қол жетімді болады'}
                  </h3>
                  <p className="text-gray-400">
                    {language === 'ru' 
                      ? 'Эта функция находится в разработке и скоро будет доступна'
                      : language === 'en'
                      ? 'This feature is under development and will be available soon'
                      : 'Бұл функция әзірленуде және жақында қол жетімді болады'}
                  </p>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="space-y-4"
            >
              <div className="glass-card p-6 rounded-2xl">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">
                    ✨ {language === 'ru' ? 'Готово!' : language === 'en' ? 'Done!' : 'Дайын!'}
                  </h3>
                  <button
                    onClick={() => setGeneratedContent(null)}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    {language === 'ru' ? 'Новая генерация' : language === 'en' ? 'New Generation' : 'Жаңа генерация'}
                  </button>
                </div>

                {generatedContent.type === 'photo' && (
                  <div className="relative rounded-xl overflow-hidden mb-4">
                    <img
                      src={generatedContent.url}
                      alt={generatedContent.prompt}
                      className="w-full h-auto"
                    />
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    onClick={handleSave}
                    className="flex-1 glass-button p-3 rounded-xl flex items-center justify-center gap-2"
                  >
                    <Download className="w-5 h-5" />
                    <span>{language === 'ru' ? 'Сохранить' : language === 'en' ? 'Save' : 'Сақтау'}</span>
                  </button>
                  <button
                    onClick={handleShare}
                    className="flex-1 glass-button p-3 rounded-xl flex items-center justify-center gap-2"
                  >
                    <Share2 className="w-5 h-5" />
                    <span>{language === 'ru' ? 'Поделиться' : language === 'en' ? 'Share' : 'Бөлісу'}</span>
                  </button>
                </div>
              </div>

              <div className="glass-card p-4 rounded-xl">
                <p className="text-sm text-gray-400">
                  <span className="font-medium">{language === 'ru' ? 'Запрос:' : language === 'en' ? 'Prompt:' : 'Сұрау:'}</span> {generatedContent.prompt}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}