import { useState } from 'react';
import { ArrowLeft, CreditCard, Bitcoin, Coins, Loader2, Check, TrendingUp } from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import { useStore } from '../store/useStore';
import { motion, AnimatePresence } from 'framer-motion';
import { apiRequest } from '../lib/queryClient';
import { useToast } from '../hooks/use-toast';

interface PaymentPageProps {
  onBack: () => void;
}

type PaymentMethod = 'cryptobot' | 'cryptomus';

interface TokenPackage {
  id: string;
  tokens: number;
  price: number;
  currency: string;
  bonus: number;
  popular?: boolean;
}

export default function PaymentPage({ onBack }: PaymentPageProps) {
  const { language, user } = useStore();
  const t = useTranslation(language);
  const { toast } = useToast();
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [selectedPackage, setSelectedPackage] = useState<TokenPackage | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const paymentMethods = [
    {
      id: 'cryptobot' as PaymentMethod,
      name: 'CryptoBot',
      description: language === 'ru' ? 'Быстрые платежи в Telegram' : language === 'en' ? 'Fast payments in Telegram' : 'Telegram-да жылдам төлемдер',
      icon: Bitcoin,
      gradient: 'from-orange-500 to-yellow-500'
    },
    {
      id: 'cryptomus' as PaymentMethod,
      name: language === 'ru' ? 'Крипта' : language === 'en' ? 'Crypto' : 'Крипто',
      description: language === 'ru' ? 'Все виды криптовалют' : language === 'en' ? 'All cryptocurrencies' : 'Барлық криптовалюталар',
      icon: Coins,
      gradient: 'from-blue-500 to-purple-500'
    }
  ];

  const tokenPackages: TokenPackage[] = [
    {
      id: 'starter',
      tokens: 10,
      price: language === 'ru' ? 100 : language === 'en' ? 1.5 : 800,
      currency: language === 'ru' ? '₽' : language === 'en' ? '$' : '₸',
      bonus: 0
    },
    {
      id: 'basic',
      tokens: 50,
      price: language === 'ru' ? 500 : language === 'en' ? 7.5 : 4000,
      currency: language === 'ru' ? '₽' : language === 'en' ? '$' : '₸',
      bonus: 5,
      popular: true
    },
    {
      id: 'premium',
      tokens: 100,
      price: language === 'ru' ? 1000 : language === 'en' ? 15 : 8000,
      currency: language === 'ru' ? '₽' : language === 'en' ? '$' : '₸',
      bonus: 20
    },
    {
      id: 'ultimate',
      tokens: 500,
      price: language === 'ru' ? 5000 : language === 'en' ? 75 : 40000,
      currency: language === 'ru' ? '₽' : language === 'en' ? '$' : '₸',
      bonus: 100
    }
  ];

  const handlePayment = async () => {
    console.log('Payment button clicked');
    console.log('Selected method:', selectedMethod);
    console.log('Selected package:', selectedPackage);
    console.log('User:', user);
    
    if (!selectedMethod || !selectedPackage || !user?.telegramId) {
      toast({
        title: language === 'ru' ? 'Внимание' : language === 'en' ? 'Attention' : 'Назар',
        description: language === 'ru' ? 'Выберите пакет и способ оплаты' : language === 'en' ? 'Select package and payment method' : 'Пакет пен төлем әдісін таңдаңыз',
        variant: 'destructive'
      });
      return;
    }

    setIsProcessing(true);
    try {
      const response = await apiRequest('POST', '/api/payment/create', {
        method: selectedMethod,
        packageId: selectedPackage.id,
        amount: selectedPackage.price,
        tokens: selectedPackage.tokens + selectedPackage.bonus,
        telegramId: user.telegramId
      });

      if (response.ok) {
        const data = await response.json();
        if (data.paymentUrl) {
          window.open(data.paymentUrl, '_blank');
        }
        toast({
          title: language === 'ru' ? 'Платеж создан' : language === 'en' ? 'Payment created' : 'Төлем жасалды',
          description: language === 'ru' ? 'Следуйте инструкциям для оплаты' : language === 'en' ? 'Follow payment instructions' : 'Төлем нұсқауларын орындаңыз'
        });
      } else {
        throw new Error('Payment creation failed');
      }
    } catch (error) {
      console.error('Payment error:', error);
      toast({
        title: language === 'ru' ? 'Ошибка' : language === 'en' ? 'Error' : 'Қате',
        description: language === 'ru' ? 'Не удалось создать платеж' : language === 'en' ? 'Failed to create payment' : 'Төлем жасалмады',
        variant: 'destructive'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const getTotalTokens = (pkg: TokenPackage) => pkg.tokens + pkg.bonus;

  return (
    <div className="min-h-screen p-4 bg-black"
      style={{
        background: 'radial-gradient(ellipse at top left, rgba(60, 40, 80, 0.3) 0%, transparent 50%), radial-gradient(ellipse at top right, rgba(80, 60, 110, 0.25) 0%, transparent 50%), radial-gradient(ellipse at bottom, rgba(100, 80, 140, 0.15) 0%, transparent 50%), linear-gradient(180deg, #000000 0%, #1a0d2e 50%, #000000 100%)',
        minHeight: '100vh'
      }}>
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white text-center">
            {language === 'ru' ? 'Пополнение баланса' : language === 'en' ? 'Top Up Balance' : 'Балансты толтыру'}
          </h1>
        </div>

        {/* Current Balance */}
        <div className="glass-card p-4 rounded-xl mb-6">
          <div className="flex items-center justify-between">
            <span className="text-gray-400">
              {language === 'ru' ? 'Текущий баланс:' : language === 'en' ? 'Current balance:' : 'Ағымдағы баланс:'}
            </span>
            <span className="text-2xl font-bold text-white">
              {user?.tokens || 0} {language === 'ru' ? 'токенов' : language === 'en' ? 'tokens' : 'токен'}
            </span>
          </div>
        </div>

        {/* Token Packages */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            {language === 'ru' ? 'Выберите пакет' : language === 'en' ? 'Choose package' : 'Пакетті таңдаңыз'}
          </h2>
          <div className="space-y-3">
            {tokenPackages.map((pkg) => (
              <button
                key={pkg.id}
                onClick={() => setSelectedPackage(pkg)}
                className={`relative w-full glass-card p-4 rounded-xl transition-all ${
                  selectedPackage?.id === pkg.id
                    ? 'border-purple-400 bg-purple-500/10 scale-105'
                    : 'hover:scale-105'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-2 right-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs px-3 py-1 rounded-full">
                    {language === 'ru' ? 'Популярно' : language === 'en' ? 'Popular' : 'Танымал'}
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <div className="text-left">
                    <div className="text-white font-semibold flex items-center gap-2">
                      {pkg.tokens} {language === 'ru' ? 'токенов' : language === 'en' ? 'tokens' : 'токен'}
                      {pkg.bonus > 0 && (
                        <span className="text-green-400 text-sm">+{pkg.bonus}</span>
                      )}
                    </div>
                    {pkg.bonus > 0 && (
                      <div className="text-xs text-gray-400">
                        {language === 'ru' ? 'Всего:' : language === 'en' ? 'Total:' : 'Барлығы:'} {getTotalTokens(pkg)}
                      </div>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-white">
                      {pkg.currency}{pkg.price}
                    </div>
                    <div className="text-xs text-gray-400">
                      {pkg.currency}{(pkg.price / getTotalTokens(pkg)).toFixed(2)}/{language === 'ru' ? 'токен' : language === 'en' ? 'token' : 'токен'}
                    </div>
                  </div>
                </div>
                
                {selectedPackage?.id === pkg.id && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-4 left-4 w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center"
                  >
                    <Check className="w-4 h-4 text-white" />
                  </motion.div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Payment Methods */}
        {selectedPackage && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <h2 className="text-lg font-semibold text-white mb-4">
              {language === 'ru' ? 'Способ оплаты' : language === 'en' ? 'Payment method' : 'Төлем әдісі'}
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {paymentMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setSelectedMethod(method.id)}
                  className={`relative glass-card p-4 rounded-xl transition-all ${
                    selectedMethod === method.id
                      ? 'border-purple-400 bg-purple-500/10 scale-105'
                      : 'hover:scale-105'
                  }`}
                >
                  <div className={`w-12 h-12 mx-auto mb-2 rounded-xl bg-gradient-to-r ${method.gradient} flex items-center justify-center`}>
                    <method.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-white text-sm">{method.name}</h3>
                  <p className="text-xs text-gray-400 mt-1">{method.description}</p>
                  
                  {selectedMethod === method.id && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-2 right-2 w-5 h-5 bg-purple-500 rounded-full flex items-center justify-center"
                    >
                      <Check className="w-3 h-3 text-white" />
                    </motion.div>
                  )}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Pay Button */}
        {selectedPackage && selectedMethod && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6"
          >
            <button
              onClick={handlePayment}
              disabled={isProcessing}
              className="w-full glass-button p-4 rounded-xl font-medium flex items-center justify-center gap-2 hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ 
                background: 'linear-gradient(135deg, rgba(100, 80, 140, 0.5), rgba(80, 60, 110, 0.6))',
                border: '1px solid rgba(100, 80, 140, 0.5)'
              }}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>{language === 'ru' ? 'Обработка...' : language === 'en' ? 'Processing...' : 'Өңдеу...'}</span>
                </>
              ) : (
                <>
                  <CreditCard className="w-5 h-5" />
                  <span>
                    {language === 'ru' ? 'Оплатить' : language === 'en' ? 'Pay' : 'Төлеу'} {selectedPackage.currency}{selectedPackage.price}
                  </span>
                </>
              )}
            </button>
          </motion.div>
        )}

        {/* Info */}
        <div className="mt-8 glass-card p-4 rounded-xl">
          <div className="flex items-start gap-3">
            <TrendingUp className="w-5 h-5 text-purple-400 mt-0.5" />
            <div className="flex-1">
              <h4 className="text-white font-medium mb-1">
                {language === 'ru' ? 'О токенах' : language === 'en' ? 'About tokens' : 'Токендер туралы'}
              </h4>
              <p className="text-gray-400 text-sm">
                {language === 'ru' 
                  ? '1 токен = 1 генерация. Чем больше пакет, тем выгоднее цена за токен.'
                  : language === 'en'
                  ? '1 token = 1 generation. Larger packages offer better value per token.'
                  : '1 токен = 1 генерация. Пакет неғұрлым үлкен болса, токен бағасы соғұрлым тиімді.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}