import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Wallet, 
  CreditCard, 
  Zap, 
  Gift, 
  Star,
  ArrowUp,
  History,
  Trophy,
  TrendingUp,
  CheckCircle,
  Clock,
  Plus
} from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import type { Language } from '../lib/i18n';
import { GlassCard } from '@/components/ui/glass-card';
import { GlassButton } from '@/components/ui/glass-button';
import { PaymentMethodPage } from './PaymentMethodPage';

interface BalancePageProps {
  language: Language;
  balance: number;
  onTopUp: (amount: number) => Promise<void>;
  telegramId: string;
}

interface TopUpPackage {
  id: string;
  amount: number;
  bonus: number;
  price: { ru: number; en: number; kz: number };
  popular?: boolean;
  savings?: string;
}

interface Transaction {
  id: string;
  type: 'topup' | 'spend' | 'bonus';
  amount: number;
  description: string;
  timestamp: Date;
  status: 'completed' | 'pending' | 'failed';
}

export function BalancePage({ language, balance, onTopUp, telegramId }: BalancePageProps) {
  const { t } = useTranslation(language);
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);
  const [showTransactions, setShowTransactions] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPaymentMethods, setShowPaymentMethods] = useState(false);
  const [selectedPackageData, setSelectedPackageData] = useState<TopUpPackage | null>(null);

  const packages: TopUpPackage[] = [
    {
      id: 'starter',
      amount: 100,
      bonus: 0,
      price: { ru: 100, en: 1.5, kz: 700 }
    },
    {
      id: 'basic',
      amount: 200,
      bonus: 0,
      price: { ru: 200, en: 3.0, kz: 1400 }
    },
    {
      id: 'popular',
      amount: 500,
      bonus: 50,
      price: { ru: 500, en: 7.5, kz: 3500 },
      popular: true,
      savings: '10%'
    },
    {
      id: 'premium',
      amount: 1000,
      bonus: 150,
      price: { ru: 1000, en: 15.0, kz: 7000 },
      savings: '15%'
    },
    {
      id: 'ultimate',
      amount: 3000,
      bonus: 500,
      price: { ru: 3000, en: 45.0, kz: 21000 },
      savings: '17%'
    },
    {
      id: 'pro',
      amount: 5000,
      bonus: 1000,
      price: { ru: 5000, en: 75.0, kz: 35000 },
      savings: '20%'
    }
  ];

  // Mock transactions data
  const [transactions] = useState<Transaction[]>([
    {
      id: '1',
      type: 'topup',
      amount: 500,
      description: 'Пополнение баланса',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      status: 'completed'
    },
    {
      id: '2',
      type: 'spend',
      amount: -100,
      description: 'Генерация видео: "Закат над океаном"',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
      status: 'completed'
    },
    {
      id: '3',
      type: 'bonus',
      amount: 50,
      description: 'Бонус за реферала',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
      status: 'completed'
    }
  ]);

  const getCurrency = () => {
    switch (language) {
      case 'en': return '$';
      case 'kz': return '₸';
      default: return '₽';
    }
  };

  const getPrice = (pkg: TopUpPackage) => {
    switch (language) {
      case 'en': return pkg.price.en;
      case 'kz': return pkg.price.kz;
      default: return pkg.price.ru;
    }
  };

  const handleTopUpClick = (pkg: TopUpPackage) => {
    if (isProcessing) return;
    
    setSelectedPackageData(pkg);
    setShowPaymentMethods(true);
  };

  const handlePaymentSuccess = async () => {
    if (!selectedPackageData) return;
    
    try {
      await onTopUp(selectedPackageData.amount + selectedPackageData.bonus);
      setShowPaymentMethods(false);
      setSelectedPackageData(null);
    } catch (error) {
      console.error('Balance update failed:', error);
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  if (showPaymentMethods && selectedPackageData) {
    return (
      <PaymentMethodPage
        language={language}
        packageData={selectedPackageData}
        onBack={() => setShowPaymentMethods(false)}
        onPaymentSuccess={handlePaymentSuccess}
        telegramId={telegramId}
      />
    );
  }

  return (
    <div className="min-h-screen p-4 pb-24 bg-black"
      style={{
        background: 'radial-gradient(ellipse at top left, rgba(60, 40, 80, 0.3) 0%, transparent 50%), radial-gradient(ellipse at top right, rgba(80, 60, 110, 0.25) 0%, transparent 50%), radial-gradient(ellipse at bottom, rgba(100, 80, 140, 0.15) 0%, transparent 50%), linear-gradient(180deg, #000000 0%, #1a0d2e 50%, #000000 100%)',
        minHeight: '100vh'
      }}>
      <div className="max-w-sm mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 pt-4"
        >
          <h1 className="text-3xl font-bold text-white mb-2">Баланс</h1>
          <p className="text-white/60 text-sm">Управление счетом и пополнения</p>
        </motion.div>

        {/* Balance Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <GlassCard className="p-6 text-center" variant="purple">
            <div className="flex items-center justify-center mb-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-purple-600 to-violet-600 flex items-center justify-center">
                <Wallet className="w-8 h-8 text-white" />
              </div>
            </div>
            
            <div className="mb-4">
              <div className="text-4xl font-bold text-white mb-2">
                {balance.toLocaleString()}
              </div>
              <div className="text-white/60 text-sm">кредитов доступно</div>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/10">
              <div className="text-center">
                <div className="text-lg font-semibold text-green-400">+156</div>
                <div className="text-xs text-white/60">Пополнено</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-blue-400">-89</div>
                <div className="text-xs text-white/60">Потрачено</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-yellow-400">5</div>
                <div className="text-xs text-white/60">Бонусы</div>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Top-up Packages */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <h2 className="text-xl font-bold text-white mb-4 flex items-center">
            <Plus className="w-5 h-5 mr-2 text-purple-400" />
            Пополнить баланс
          </h2>

          <div className="grid grid-cols-2 gap-3">
            {packages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="relative"
              >
                <GlassCard 
                  className={`p-4 cursor-pointer transition-all duration-300 hover:scale-105 ${
                    pkg.popular ? 'border-yellow-400/30' : ''
                  }`}
                  onClick={() => handleTopUpClick(pkg)}
                >
                  {pkg.popular && (
                    <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                      <div className="bg-gradient-to-r from-yellow-600 to-orange-600 text-white text-xs px-3 py-1 rounded-full flex items-center">
                        <Star className="w-3 h-3 mr-1" />
                        Популярный
                      </div>
                    </div>
                  )}

                  {pkg.savings && (
                    <div className="absolute top-2 right-2">
                      <div className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                        {pkg.savings}
                      </div>
                    </div>
                  )}

                  <div className="text-center">
                    <div className="text-2xl font-bold text-white mb-1">
                      {(pkg.amount + pkg.bonus).toLocaleString()}
                    </div>
                    <div className="text-white/60 text-xs mb-3">кредитов</div>

                    {pkg.bonus > 0 && (
                      <div className="flex items-center justify-center text-green-400 text-xs mb-3">
                        <Gift className="w-3 h-3 mr-1" />
                        +{pkg.bonus} бонус
                      </div>
                    )}

                    <div className="text-lg font-semibold text-purple-400">
                      {getPrice(pkg)}{getCurrency()}
                    </div>

                    {selectedPackage === pkg.id && isProcessing && (
                      <div className="absolute inset-0 bg-purple-600/20 rounded-2xl flex items-center justify-center">
                        <div className="w-6 h-6 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
                      </div>
                    )}
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-6"
        >
          <div className="grid grid-cols-2 gap-3">
            <GlassButton
              onClick={() => setShowTransactions(!showTransactions)}
              variant="secondary"
              className="flex items-center justify-center space-x-2 py-3"
            >
              <History className="w-4 h-4" />
              <span>История</span>
            </GlassButton>
            <GlassButton
              variant="secondary"
              className="flex items-center justify-center space-x-2 py-3"
            >
              <Trophy className="w-4 h-4" />
              <span>Бонусы</span>
            </GlassButton>
          </div>
        </motion.div>

        {/* Transaction History */}
        <AnimatePresence>
          {showTransactions && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <GlassCard className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">Последние операции</h3>
                  <TrendingUp className="w-5 h-5 text-green-400" />
                </div>

                <div className="space-y-3">
                  {transactions.map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-3 bg-white/5 rounded-xl">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          transaction.type === 'topup' ? 'bg-green-500/20' :
                          transaction.type === 'spend' ? 'bg-red-500/20' : 'bg-yellow-500/20'
                        }`}>
                          {transaction.type === 'topup' ? (
                            <ArrowUp className="w-4 h-4 text-green-400" />
                          ) : transaction.type === 'spend' ? (
                            <Zap className="w-4 h-4 text-red-400" />
                          ) : (
                            <Gift className="w-4 h-4 text-yellow-400" />
                          )}
                        </div>
                        
                        <div>
                          <div className="text-white text-sm font-medium">
                            {transaction.description}
                          </div>
                          <div className="text-white/60 text-xs flex items-center">
                            <Clock className="w-3 h-3 mr-1" />
                            {formatDate(transaction.timestamp)}
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className={`font-semibold ${
                          transaction.amount > 0 ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {transaction.amount > 0 ? '+' : ''}{transaction.amount}
                        </div>
                        <div className="flex items-center text-xs text-white/60">
                          <CheckCircle className="w-3 h-3 mr-1 text-green-400" />
                          Завершено
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}