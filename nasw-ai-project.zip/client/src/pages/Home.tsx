import { useState } from 'react';
import { useStore } from '../store/useStore';
import { useTranslation } from '../lib/i18n';
import { BottomNavigation } from '../components/BottomNavigation';

// Import pages
import GenerationPage from './GenerationPage';
import PaymentPage from './PaymentPage';
import GalleryPage from './GalleryPage';
import SupportPage from './SupportPage';
import ProfilePage from './ProfilePage';

interface HomeProps {
  onNavigate: (page: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const { language } = useStore();
  const [activeTab, setActiveTab] = useState('profile');

  const handleTabChange = (tab: string) => {
    if (tab === 'language' || tab === 'free-generation') {
      onNavigate(tab);
    } else {
      setActiveTab(tab);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfilePage onBack={() => {}} />;
      case 'generation':
        return <GenerationPage onBack={() => setActiveTab('profile')} />;
      case 'payment':
        return <PaymentPage onBack={() => setActiveTab('profile')} />;
      case 'gallery':
        return <GalleryPage onBack={() => setActiveTab('profile')} />;
      case 'support':
        return <SupportPage onBack={() => setActiveTab('profile')} />;
      default:
        return <ProfilePage onBack={() => {}} />;
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Main Content with Liquid Glass Blur */}
      <div className="pb-24">
        {renderContent()}
      </div>
      
      {/* Bottom Navigation */}
      <BottomNavigation 
        activeTab={activeTab}
        onTabChange={handleTabChange}
        language={language}
      />
    </div>
  );
}