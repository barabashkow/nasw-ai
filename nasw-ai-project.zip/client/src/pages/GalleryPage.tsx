import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Search, Filter, Download, Share2, Trash2, Image, Video, Calendar } from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import { useStore } from '../store/useStore';

interface GalleryPageProps {
  onBack: () => void;
}

export default function GalleryPage({ onBack }: GalleryPageProps) {
  const { language } = useStore();
  const t = useTranslation(language);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'photo' | 'video'>('all');

  // Fetch generated content
  const { data: content = [], isLoading } = useQuery({
    queryKey: ['/api/generated-content']
  });

  const filteredContent = content.filter((item: any) => {
    const matchesSearch = item.prompt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === 'all' || item.type === filterType;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen p-4 bg-black"
      style={{
        background: 'radial-gradient(ellipse at top left, rgba(60, 40, 80, 0.3) 0%, transparent 50%), radial-gradient(ellipse at top right, rgba(80, 60, 110, 0.25) 0%, transparent 50%), radial-gradient(ellipse at bottom, rgba(100, 80, 140, 0.15) 0%, transparent 50%), linear-gradient(180deg, #000000 0%, #1a0d2e 50%, #000000 100%)',
        minHeight: '100vh'
      }}>
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold gradient-text text-center">
            {t.gallery}
          </h1>
        </div>

        {/* Search and Filter */}
        <div className="space-y-4 mb-6">
          <div className="glass-card p-4 rounded-xl">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Поиск по описанию..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-black/20 border border-purple-500/30 rounded-xl pl-10 pr-4 py-2 text-white placeholder-gray-400 focus:border-purple-400 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setFilterType('all')}
              className={`glass-button px-4 py-2 rounded-xl text-sm ${
                filterType === 'all' ? 'bg-purple-500/30 border-purple-400' : ''
              }`}
            >
              Все
            </button>
            <button
              onClick={() => setFilterType('photo')}
              className={`glass-button px-4 py-2 rounded-xl text-sm flex items-center gap-2 ${
                filterType === 'photo' ? 'bg-purple-500/30 border-purple-400' : ''
              }`}
            >
              <Image className="w-4 h-4" />
              Фото
            </button>
            <button
              onClick={() => setFilterType('video')}
              className={`glass-button px-4 py-2 rounded-xl text-sm flex items-center gap-2 ${
                filterType === 'video' ? 'bg-purple-500/30 border-purple-400' : ''
              }`}
            >
              <Video className="w-4 h-4" />
              Видео
            </button>
          </div>
        </div>

        {/* Content Grid */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="glass-card p-8 rounded-xl text-center">
              <div className="loading-spinner mx-auto mb-4" />
              <p className="text-gray-300">Загружаем контент...</p>
            </div>
          ) : filteredContent.length === 0 ? (
            <div className="glass-card p-8 rounded-xl text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
                <Image className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                Пока пусто
              </h3>
              <p className="text-gray-300 text-sm mb-4">
                Создайте свой первый контент в разделе генерации
              </p>
            </div>
          ) : (
            filteredContent.map((item: any) => (
              <div key={item.id} className="glass-card p-4 rounded-xl">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded-xl bg-black/20 flex items-center justify-center overflow-hidden">
                    {item.type === 'photo' ? (
                      item.resultUrl ? (
                        <img 
                          src={item.resultUrl} 
                          alt="Generated content"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Image className="w-6 h-6 text-purple-400" />
                      )
                    ) : (
                      <Video className="w-6 h-6 text-purple-400" />
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                        item.type === 'photo' ? 'bg-blue-500/20 text-blue-300' : 'bg-purple-500/20 text-purple-300'
                      }`}>
                        {item.type === 'photo' ? 'Изображение' : 'Видео'}
                      </span>
                      <span className={`px-2 py-1 rounded-lg text-xs ${
                        item.status === 'completed' ? 'bg-green-500/20 text-green-300' :
                        item.status === 'generating' ? 'bg-yellow-500/20 text-yellow-300' :
                        'bg-red-500/20 text-red-300'
                      }`}>
                        {item.status === 'completed' ? 'Готово' :
                         item.status === 'generating' ? 'Создается...' : 'Ошибка'}
                      </span>
                    </div>
                    
                    <p className="text-white text-sm mb-2 line-clamp-2">
                      {item.prompt}
                    </p>
                    
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <Calendar className="w-3 h-3" />
                      <span>
                        {new Date(item.createdAt).toLocaleDateString('ru-RU')}
                      </span>
                    </div>
                  </div>
                  
                  {item.status === 'completed' && (
                    <div className="flex gap-2">
                      <button className="glass-button p-2 rounded-lg">
                        <Download className="w-4 h-4 text-white" />
                      </button>
                      <button className="glass-button p-2 rounded-lg">
                        <Share2 className="w-4 h-4 text-white" />
                      </button>
                      <button className="glass-button p-2 rounded-lg">
                        <Trash2 className="w-4 h-4 text-red-400" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Statistics */}
        {!isLoading && filteredContent.length > 0 && (
          <div className="glass-card p-4 rounded-xl mt-6">
            <h3 className="text-white font-semibold mb-2">Статистика</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-lg font-bold text-white">{content.length}</div>
                <div className="text-xs text-gray-300">Всего</div>
              </div>
              <div>
                <div className="text-lg font-bold text-blue-300">
                  {content.filter((item: any) => item.type === 'photo').length}
                </div>
                <div className="text-xs text-gray-300">Изображений</div>
              </div>
              <div>
                <div className="text-lg font-bold text-purple-300">
                  {content.filter((item: any) => item.type === 'video').length}
                </div>
                <div className="text-xs text-gray-300">Видео</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}