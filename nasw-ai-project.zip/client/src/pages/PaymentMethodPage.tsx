import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CreditCard, 
  Smartphone, 
  Bitcoin, 
  ArrowLeft,
  Check,
  Shield,
  Zap,
  Globe
} from 'lucide-react';
import { useTranslation } from '../lib/i18n';
import type { Language } from '../lib/i18n';
import { GlassCard } from '@/components/ui/glass-card';
import { GlassButton } from '@/components/ui/glass-button';
import { apiRequest } from '@/lib/queryClient';

interface PaymentMethodPageProps {
  language: Language;
  packageData: {
    id: string;
    amount: number;
    bonus: number;
    price: { ru: number; en: number; kz: number };
  };
  onBack: () => void;
  onPaymentSuccess: () => void;
  telegramId: string;
}

interface PaymentMethod {
  id: string;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  features: string[];
  processing: string;
  available: boolean;
}

export function PaymentMethodPage({ 
  language, 
  packageData, 
  onBack, 
  onPaymentSuccess,
  telegramId 
}: PaymentMethodPageProps) {
  const { t } = useTranslation(language);
  const [selectedMethod, setSelectedMethod] = useState<string>('');
  const [selectedAsset, setSelectedAsset] = useState<string>('USDT');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentUrl, setPaymentUrl] = useState<string>('');

  const cryptoAssets = [
    { id: 'USDT', name: 'USDT (Tether)', icon: '₮' },
    { id: 'TON', name: 'TON Coin', icon: '💎' },
    { id: 'BTC', name: 'Bitcoin', icon: '₿' },
    { id: 'ETH', name: 'Ethereum', icon: 'Ξ' },
    { id: 'LTC', name: 'Litecoin', icon: 'Ł' },
    { id: 'BNB', name: 'BNB', icon: '🔸' }
  ];

  const paymentMethods: PaymentMethod[] = [
    {
      id: 'crypto',
      name: 'Криптовалюта',
      icon: Bitcoin,
      description: 'Быстрые и анонимные криптоплатежи через CryptoBot',
      features: ['Мгновенное зачисление', 'Низкие комиссии', 'Анонимность', 'Поддержка всех популярных монет'],
      processing: '1-5 минут',
      available: true
    }
  ];

  const getCurrency = () => {
    switch (language) {
      case 'en': return '$';
      case 'kz': return '₸';
      default: return '₽';
    }
  };

  const getPrice = () => {
    switch (language) {
      case 'en': return packageData.price.en;
      case 'kz': return packageData.price.kz;
      default: return packageData.price.ru;
    }
  };

  const handleCryptoPayment = async () => {
    setIsProcessing(true);
    try {
      const response = await apiRequest('POST', '/api/payment/create-crypto-invoice', {
        telegramId,
        packageId: packageData.id,
        asset: selectedAsset
      });

      const result = await response.json();
      
      if (result.success && result.paymentUrl) {
        setPaymentUrl(result.paymentUrl);
        // Open payment in Telegram WebApp
        if (window.Telegram?.WebApp) {
          window.Telegram.WebApp.openLink(result.paymentUrl);
        } else {
          window.open(result.paymentUrl, '_blank');
        }
        
        // Poll for payment status
        pollPaymentStatus(result.invoiceId);
      } else {
        throw new Error(result.error || 'Failed to create payment');
      }
    } catch (error) {
      console.error('Crypto payment error:', error);
      alert('Ошибка создания платежа. Попробуйте еще раз.');
    } finally {
      setIsProcessing(false);
    }
  };

  const checkPaymentStatus = async (invoiceId: string) => {
    try {
      const response = await apiRequest('GET', `/api/payment/crypto-status/${invoiceId}`);
      const result = await response.json();
      return result.paid;
    } catch (error) {
      console.error('Payment status check error:', error);
      return false;
    }
  };

  const pollPaymentStatus = (invoiceId: string) => {
    const pollInterval = setInterval(async () => {
      try {
        const isPaid = await checkPaymentStatus(invoiceId);
        if (isPaid) {
          clearInterval(pollInterval);
          onPaymentSuccess();
          return;
        }
      } catch (error) {
        console.error('Payment status check error:', error);
      }
    }, 3000);

    // Stop polling after 10 minutes
    setTimeout(() => {
      clearInterval(pollInterval);
      setIsProcessing(false);
    }, 600000);
  };

  const handlePayment = () => {
    if (selectedMethod === 'crypto') {
      handleCryptoPayment();
    }
  };

  return (
    <div className="min-h-screen p-4 pb-24 bg-black"
      style={{
        background: 'radial-gradient(ellipse at top left, rgba(60, 40, 80, 0.3) 0%, transparent 50%), radial-gradient(ellipse at top right, rgba(80, 60, 110, 0.25) 0%, transparent 50%), radial-gradient(ellipse at bottom, rgba(100, 80, 140, 0.15) 0%, transparent 50%), linear-gradient(180deg, #000000 0%, #1a0d2e 50%, #000000 100%)',
        minHeight: '100vh'
      }}>
      <div className="max-w-sm mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 pt-4"
        >
          <h1 className="text-2xl font-bold text-white">Способ оплаты</h1>
          <p className="text-white/60 text-sm">Выберите удобный способ</p>
        </motion.div>

        {/* Package Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <GlassCard className="p-4" variant="purple">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-white font-semibold">
                  {(packageData.amount + packageData.bonus).toLocaleString()} кредитов
                </div>
                {packageData.bonus > 0 && (
                  <div className="text-green-400 text-sm">
                    +{packageData.bonus} бонус
                  </div>
                )}
              </div>
              <div className="text-2xl font-bold text-purple-400">
                {getPrice()}{getCurrency()}
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Payment Methods */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <h2 className="text-lg font-semibold text-white mb-4">Способ оплаты</h2>
          
          <div className="space-y-3">
            {paymentMethods.map((method, index) => (
              <motion.div
                key={method.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <GlassCard 
                  className={`p-4 cursor-pointer transition-all duration-300 ${
                    selectedMethod === method.id ? 'border-purple-400/50 bg-purple-500/10' : ''
                  } ${!method.available ? 'opacity-50 cursor-not-allowed' : 'hover:bg-white/10'}`}
                  onClick={() => method.available && setSelectedMethod(method.id)}
                >
                  <div className="flex items-start space-x-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                      selectedMethod === method.id ? 'bg-purple-600' : 'bg-white/10'
                    }`}>
                      <method.icon className="w-6 h-6 text-white" />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-white font-semibold">{method.name}</h3>
                        {selectedMethod === method.id && (
                          <Check className="w-5 h-5 text-purple-400" />
                        )}
                        {!method.available && (
                          <span className="text-xs text-yellow-400 bg-yellow-400/20 px-2 py-1 rounded-full">
                            Скоро
                          </span>
                        )}
                      </div>
                      
                      <p className="text-white/60 text-sm mb-3">{method.description}</p>
                      
                      <div className="flex items-center space-x-4 text-xs text-white/50">
                        <div className="flex items-center space-x-1">
                          <Zap className="w-3 h-3" />
                          <span>{method.processing}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Shield className="w-3 h-3" />
                          <span>Безопасно</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Crypto Asset Selection */}
        <AnimatePresence>
          {selectedMethod === 'crypto' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-6 overflow-hidden"
            >
              <h3 className="text-lg font-semibold text-white mb-4">Выберите криптовалюту</h3>
              
              <div className="grid grid-cols-2 gap-3">
                {cryptoAssets.map((asset) => (
                  <GlassCard
                    key={asset.id}
                    className={`p-3 cursor-pointer transition-all duration-300 ${
                      selectedAsset === asset.id ? 'border-purple-400/50 bg-purple-500/10' : 'hover:bg-white/10'
                    }`}
                    onClick={() => setSelectedAsset(asset.id)}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-2">{asset.icon}</div>
                      <div className="text-white font-medium text-sm">{asset.id}</div>
                      <div className="text-white/60 text-xs">{asset.name}</div>
                      {selectedAsset === asset.id && (
                        <Check className="w-4 h-4 text-purple-400 mx-auto mt-2" />
                      )}
                    </div>
                  </GlassCard>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Payment Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <GlassButton
            onClick={handlePayment}
            variant="primary"
            className="w-full py-4 text-lg font-semibold"
            disabled={!selectedMethod || isProcessing}
          >
            {isProcessing ? (
              <div className="flex items-center justify-center space-x-2">
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Создаем платеж...</span>
              </div>
            ) : (
              <div className="flex items-center justify-center space-x-2">
                <span>Оплатить {getPrice()}{getCurrency()}</span>
                <ArrowLeft className="w-5 h-5 rotate-180" />
              </div>
            )}
          </GlassButton>
        </motion.div>

        {/* Security Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-6 text-center"
        >
          <div className="flex items-center justify-center space-x-4 text-white/50 text-xs">
            <div className="flex items-center space-x-1">
              <Shield className="w-3 h-3" />
              <span>SSL защита</span>
            </div>
            <div className="flex items-center space-x-1">
              <Globe className="w-3 h-3" />
              <span>Мировые стандарты</span>
            </div>
          </div>
          <p className="text-white/40 text-xs mt-2">
            Ваши данные защищены современным шифрованием
          </p>
        </motion.div>
      </div>
    </div>
  );
}