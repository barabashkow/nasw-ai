import type { TelegramWebApp, TelegramUser } from '../types';

declare global {
  interface Window {
    Telegram?: {
      WebApp: TelegramWebApp;
    };
  }
}

class TelegramWebAppService {
  private webApp: TelegramWebApp | null = null;

  constructor() {
    if (typeof window !== 'undefined' && window.Telegram?.WebApp) {
      this.webApp = window.Telegram.WebApp;
      this.init();
    }
  }

  private init() {
    if (!this.webApp) return;

    // Set up the WebApp
    this.webApp.ready();
    this.webApp.expand();
    
    // Configure theme
    this.webApp.headerColor = '#0F0F0F';
    this.webApp.backgroundColor = '#0F0F0F';
    
    // Enable closing confirmation
    this.webApp.isClosingConfirmationEnabled = true;
  }

  getWebApp(): TelegramWebApp | null {
    return this.webApp;
  }

  getUser(): TelegramUser | null {
    // In development mode, return a mock user if no Telegram WebApp is available
    if (import.meta.env.DEV && !this.webApp) {
      return {
        id: 12345,
        username: "dev_user",
        first_name: "Development",
        last_name: "User",
        language_code: "ru"
      };
    }
    return this.webApp?.initDataUnsafe?.user || null;
  }

  getInitData(): string {
    // In development mode, return empty string if no WebApp
    if (import.meta.env.DEV && !this.webApp) {
      return '';
    }
    return this.webApp?.initData || '';
  }

  getUserId(): string | null {
    const user = this.getUser();
    return user ? user.id.toString() : null;
  }

  isAvailable(): boolean {
    // In development mode, always return true to allow testing
    if (import.meta.env.DEV) {
      return true;
    }
    return !!this.webApp;
  }

  showAlert(message: string, callback?: () => void): void {
    if (this.webApp) {
      this.webApp.showAlert(message, callback);
    } else {
      alert(message);
      callback?.();
    }
  }

  showConfirm(message: string, callback?: (confirmed: boolean) => void): void {
    if (this.webApp) {
      this.webApp.showConfirm(message, callback);
    } else {
      const confirmed = confirm(message);
      callback?.(confirmed);
    }
  }

  hapticFeedback(type: 'light' | 'medium' | 'heavy' | 'success' | 'error' | 'warning' | 'selection'): void {
    if (!this.webApp) return;

    if (type === 'success' || type === 'error' || type === 'warning') {
      this.webApp.HapticFeedback.notificationOccurred(type);
    } else if (type === 'selection') {
      this.webApp.HapticFeedback.selectionChanged();
    } else {
      this.webApp.HapticFeedback.impactOccurred(type);
    }
  }

  setMainButton(text: string, onClick: () => void, options?: {
    color?: string;
    textColor?: string;
    isVisible?: boolean;
    isActive?: boolean;
  }): void {
    if (!this.webApp) return;

    const button = this.webApp.MainButton;
    
    button.setText(text);
    button.onClick(onClick);
    
    if (options?.color) button.color = options.color;
    if (options?.textColor) button.textColor = options.textColor;
    
    if (options?.isVisible !== false) button.show();
    if (options?.isActive !== false) button.enable();
  }

  hideMainButton(): void {
    if (this.webApp) {
      this.webApp.MainButton.hide();
    }
  }

  setBackButton(onClick: () => void, isVisible: boolean = true): void {
    if (!this.webApp) return;

    const button = this.webApp.BackButton;
    
    button.onClick(onClick);
    
    if (isVisible) {
      button.show();
    } else {
      button.hide();
    }
  }

  hideBackButton(): void {
    if (this.webApp) {
      this.webApp.BackButton.hide();
    }
  }

  sendData(data: any): void {
    if (this.webApp) {
      this.webApp.sendData(JSON.stringify(data));
    }
  }

  close(): void {
    if (this.webApp) {
      this.webApp.close();
    }
  }

  onEvent(eventType: string, handler: () => void): void {
    if (this.webApp) {
      this.webApp.onEvent(eventType, handler);
    }
  }

  offEvent(eventType: string, handler: () => void): void {
    if (this.webApp) {
      this.webApp.offEvent(eventType, handler);
    }
  }
}

export const telegramWebApp = new TelegramWebAppService();
