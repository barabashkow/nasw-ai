import { queryClient } from './queryClient';
import type { User, GeneratedContent, Ticket, TicketMessage, BalanceTransaction, GenerationRequest, TopupRequest, TicketRequest } from '../types';

const API_BASE = '/api';

export const api = {
  // Auth
  async authenticate(initData: string): Promise<{ user: User }> {
    const response = await fetch(`${API_BASE}/users/auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ initData }),
    });

    if (!response.ok) {
      throw new Error('Authentication failed');
    }

    return response.json();
  },

  // User
  async getUser(telegramId: string): Promise<{ user: User }> {
    const response = await fetch(`${API_BASE}/users/${telegramId}`);
    if (!response.ok) {
      throw new Error('Failed to fetch user');
    }
    return response.json();
  },

  // Balance
  async getBalance(telegramId: string): Promise<{ balance: number }> {
    const response = await fetch(`${API_BASE}/balance/${telegramId}`);
    if (!response.ok) {
      throw new Error('Failed to fetch balance');
    }
    return response.json();
  },

  async topupBalance(telegramId: string, amount: number): Promise<{ user: User; paymentUrl: string }> {
    const response = await fetch(`${API_BASE}/balance/topup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ telegramId, amount }),
    });

    if (!response.ok) {
      throw new Error('Failed to process topup');
    }

    return response.json();
  },

  // Generation
  async generateContent(telegramId: string, request: GenerationRequest): Promise<{ generation: GeneratedContent }> {
    const response = await fetch(`${API_BASE}/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ telegramId, ...request }),
    });

    if (!response.ok) {
      throw new Error('Failed to generate content');
    }

    return response.json();
  },

  async getGeneratedContent(telegramId: string): Promise<{ content: GeneratedContent[] }> {
    const response = await fetch(`${API_BASE}/generated/${telegramId}`);
    if (!response.ok) {
      throw new Error('Failed to fetch generated content');
    }
    return response.json();
  },

  // Tickets
  async createTicket(telegramId: string, request: TicketRequest): Promise<{ ticket: Ticket }> {
    const formData = new FormData();
    formData.append('telegramId', telegramId);
    formData.append('title', request.title);
    formData.append('description', request.description);
    
    if (request.attachments) {
      request.attachments.forEach((file, index) => {
        formData.append(`attachment_${index}`, file);
      });
    }

    const response = await fetch(`${API_BASE}/tickets`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Failed to create ticket');
    }

    return response.json();
  },

  async getTickets(telegramId: string): Promise<{ tickets: Ticket[] }> {
    const response = await fetch(`${API_BASE}/tickets/${telegramId}`);
    if (!response.ok) {
      throw new Error('Failed to fetch tickets');
    }
    return response.json();
  },

  async getTicketMessages(ticketId: number): Promise<{ messages: TicketMessage[] }> {
    const response = await fetch(`${API_BASE}/tickets/${ticketId}/messages`);
    if (!response.ok) {
      throw new Error('Failed to fetch ticket messages');
    }
    return response.json();
  },

  async addTicketMessage(telegramId: string, ticketId: number, message: string, attachments?: File[]): Promise<{ message: TicketMessage }> {
    const formData = new FormData();
    formData.append('telegramId', telegramId);
    formData.append('message', message);
    
    if (attachments) {
      attachments.forEach((file, index) => {
        formData.append(`attachment_${index}`, file);
      });
    }

    const response = await fetch(`${API_BASE}/tickets/${ticketId}/messages`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Failed to add ticket message');
    }

    return response.json();
  },
};

// Query key factories
export const queryKeys = {
  user: (telegramId: string) => ['/api/users', telegramId],
  balance: (telegramId: string) => ['/api/balance', telegramId],
  generatedContent: (telegramId: string) => ['/api/generated', telegramId],
  tickets: (telegramId: string) => ['/api/tickets', telegramId],
  ticketMessages: (ticketId: number) => ['/api/tickets', ticketId, 'messages'],
};

// Helper functions for invalidating cache
export const invalidateUser = (telegramId: string) => {
  queryClient.invalidateQueries({ queryKey: queryKeys.user(telegramId) });
};

export const invalidateBalance = (telegramId: string) => {
  queryClient.invalidateQueries({ queryKey: queryKeys.balance(telegramId) });
};

export const invalidateGeneratedContent = (telegramId: string) => {
  queryClient.invalidateQueries({ queryKey: queryKeys.generatedContent(telegramId) });
};

export const invalidateTickets = (telegramId: string) => {
  queryClient.invalidateQueries({ queryKey: queryKeys.tickets(telegramId) });
};

export const invalidateTicketMessages = (ticketId: number) => {
  queryClient.invalidateQueries({ queryKey: queryKeys.ticketMessages(ticketId) });
};
