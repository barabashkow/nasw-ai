export interface Translations {
  // Navigation
  loading: string;
  selectLanguage: string;
  subscription: string;
  mainMenu: string;
  
  // Main menu items
  generation: string;
  payment: string;
  gallery: string;
  support: string;
  profile: string;
  language: string;
  freeGeneration: string;
  
  // Common
  back: string;
  next: string;
  continue: string;
  cancel: string;
  save: string;
  delete: string;
  edit: string;
  create: string;
  
  // App specific
  welcome: string;
  credits: string;
  balance: string;
  
  // Status
  loading: string;
  error: string;
  success: string;
}

const translations: Record<'ru' | 'en' | 'kz', Translations> = {
  ru: {
    loading: 'Загрузка',
    selectLanguage: 'Выберите язык',
    subscription: 'Подписка',
    mainMenu: 'Главное меню',
    
    generation: 'Генерация',
    payment: 'Платежи',
    gallery: 'Галерея',
    support: 'Поддержка',
    profile: 'Профиль',
    language: 'Язык',
    freeGeneration: 'Бесплатная генерация',
    
    back: 'Назад',
    next: 'Далее',
    continue: 'Продолжить',
    cancel: 'Отмена',
    save: 'Сохранить',
    delete: 'Удалить',
    edit: 'Редактировать',
    create: 'Создать',
    
    welcome: 'Добро пожаловать',
    credits: 'кредитов',
    balance: 'Баланс',
    
    error: 'Ошибка',
    success: 'Успешно'
  },
  
  en: {
    loading: 'Loading',
    selectLanguage: 'Select Language',
    subscription: 'Subscription',
    mainMenu: 'Main Menu',
    
    generation: 'Generation',
    payment: 'Payment',
    gallery: 'Gallery',
    support: 'Support',
    profile: 'Profile',
    language: 'Language',
    freeGeneration: 'Free Generation',
    
    back: 'Back',
    next: 'Next',
    continue: 'Continue',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    create: 'Create',
    
    welcome: 'Welcome',
    credits: 'credits',
    balance: 'Balance',
    
    error: 'Error',
    success: 'Success'
  },
  
  kz: {
    loading: 'Жүктелуде',
    selectLanguage: 'Тілді таңдаңыз',
    subscription: 'Жазылым',
    mainMenu: 'Негізгі мәзір',
    
    generation: 'Генерация',
    payment: 'Төлем',
    gallery: 'Галерея',
    support: 'Қолдау',
    profile: 'Профиль',
    language: 'Тіл',
    freeGeneration: 'Тегін генерация',
    
    back: 'Артқа',
    next: 'Келесі',
    continue: 'Жалғастыру',
    cancel: 'Болдырмау',
    save: 'Сақтау',
    delete: 'Өшіру',
    edit: 'Өңдеу',
    create: 'Жасау',
    
    welcome: 'Қош келдіңіз',
    credits: 'кредит',
    balance: 'Баланс',
    
    error: 'Қате',
    success: 'Сәтті'
  }
};

export function useTranslation(language: 'ru' | 'en' | 'kz'): Translations {
  return translations[language] || translations.ru;
}