import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, GeneratedContent, Ticket, AppState } from '../types';

interface AppStore extends AppState {
  // Actions
  setUser: (user: User | null) => void;
  setCurrentSection: (section: AppState['currentSection']) => void;
  setIsLoading: (isLoading: boolean) => void;
  setGeneratedContent: (content: GeneratedContent[]) => void;
  addGeneratedContent: (content: GeneratedContent) => void;
  setTickets: (tickets: Ticket[]) => void;
  addTicket: (ticket: Ticket) => void;
  setIsGenerating: (isGenerating: boolean) => void;
  setGenerationProgress: (progress: number) => void;
  updateUserBalance: (balance: number) => void;
  reset: () => void;
}

const initialState: AppState = {
  user: null,
  currentSection: 'balance',
  isLoading: true,
  generatedContent: [],
  tickets: [],
  isGenerating: false,
  generationProgress: 0,
};

export const useAppStore = create<AppStore>()(
  persist(
    (set, get) => ({
      ...initialState,

      // Actions
      setUser: (user) => set({ user }),
      
      setCurrentSection: (section) => set({ currentSection: section }),
      
      setIsLoading: (isLoading) => set({ isLoading }),
      
      setGeneratedContent: (content) => set({ generatedContent: content }),
      
      addGeneratedContent: (content) => set((state) => ({
        generatedContent: [content, ...state.generatedContent],
      })),
      
      setTickets: (tickets) => set({ tickets }),
      
      addTicket: (ticket) => set((state) => ({
        tickets: [ticket, ...state.tickets],
      })),
      
      setIsGenerating: (isGenerating) => set({ isGenerating }),
      
      setGenerationProgress: (progress) => set({ generationProgress: progress }),
      
      updateUserBalance: (balance) => set((state) => ({
        user: state.user ? { ...state.user, balance } : null,
      })),
      
      reset: () => set(initialState),
    }),
    {
      name: 'nasway-app-store',
      partialize: (state) => ({
        user: state.user,
        currentSection: state.currentSection,
        generatedContent: state.generatedContent,
        tickets: state.tickets,
      }),
    }
  )
);
