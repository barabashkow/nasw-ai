import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id?: number;
  telegramId?: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  photoUrl?: string;
  tokens?: number;
  referralCount?: number;
  referralEarnings?: number;
}

interface AppStore {
  // User data
  user: User | null;
  setUser: (user: User | null) => void;
  
  // Language
  language: 'ru' | 'en' | 'kz';
  setLanguage: (language: 'ru' | 'en' | 'kz') => void;
  
  // App state
  isAuthenticated: boolean;
  setAuthenticated: (isAuthenticated: boolean) => void;
  
  // Navigation
  currentPage: string;
  setCurrentPage: (page: string) => void;
  
  // Loading states
  isLoading: boolean;
  setLoading: (isLoading: boolean) => void;
  
  // Free generation
  lastDiceRoll: number | null;
  setLastDiceRoll: (time: number | null) => void;
}

export const useStore = create<AppStore>()(
  persist(
    (set, get) => ({
      // User data
      user: null,
      setUser: (user) => set({ user }),
      
      // Language
      language: 'ru',
      setLanguage: (language) => set({ language }),
      
      // App state
      isAuthenticated: false,
      setAuthenticated: (isAuthenticated) => set({ isAuthenticated }),
      
      // Navigation
      currentPage: '',
      setCurrentPage: (currentPage) => set({ currentPage }),
      
      // Loading states
      isLoading: false,
      setLoading: (isLoading) => set({ isLoading }),
      
      // Free generation
      lastDiceRoll: null,
      setLastDiceRoll: (lastDiceRoll) => set({ lastDiceRoll }),
    }),
    {
      name: 'nasw-ai-storage',
      partialize: (state) => ({
        language: state.language,
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        lastDiceRoll: state.lastDiceRoll,
      }),
    }
  )
);