import { 
  users, 
  tickets, 
  ticketMessages, 
  generatedContent, 
  balanceTransactions,
  type User, 
  type InsertUser,
  type Ticket,
  type InsertTicket,
  type TicketMessage,
  type InsertTicketMessage,
  type GeneratedContent,
  type InsertGeneratedContent,
  type BalanceTransaction,
  type InsertBalanceTransaction
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User management
  getUserByTelegramId(telegramId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(telegramId: string, updates: Partial<User>): Promise<User>;
  updateUserBalance(telegramId: string, amount: number): Promise<User>;
  updateUserLanguage(telegramId: string, language: string): Promise<User>;
  
  // Ticket management
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  getTicketsByUserId(userId: number): Promise<Ticket[]>;
  getTicketById(id: number): Promise<Ticket | undefined>;
  updateTicketStatus(id: number, status: string): Promise<Ticket>;
  
  // Ticket messages
  createTicketMessage(message: InsertTicketMessage): Promise<TicketMessage>;
  getTicketMessages(ticketId: number): Promise<TicketMessage[]>;
  
  // Generated content
  createGeneratedContent(content: InsertGeneratedContent): Promise<GeneratedContent>;
  getGeneratedContentByUserId(userId: number): Promise<GeneratedContent[]>;
  updateGeneratedContent(id: number, updates: Partial<GeneratedContent>): Promise<GeneratedContent>;
  
  // Balance transactions
  createBalanceTransaction(transaction: InsertBalanceTransaction): Promise<BalanceTransaction>;
  getBalanceTransactionsByUserId(userId: number): Promise<BalanceTransaction[]>;
  getTransactionByUuid(uuid: string): Promise<BalanceTransaction | undefined>;
  updateTransactionStatus(id: number, status: string): Promise<BalanceTransaction>;
}

export class DatabaseStorage implements IStorage {
  async getUserByTelegramId(telegramId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.telegramId, telegramId));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(telegramId: string, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.telegramId, telegramId))
      .returning();
    return user;
  }

  async updateUserBalance(telegramId: string, amount: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ tokens: amount, updatedAt: new Date() })
      .where(eq(users.telegramId, telegramId))
      .returning();
    return user;
  }

  async updateUserLanguage(telegramId: string, language: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ languageCode: language, updatedAt: new Date() })
      .where(eq(users.telegramId, telegramId))
      .returning();
    return user;
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const [ticket] = await db.insert(tickets).values(insertTicket).returning();
    return ticket;
  }

  async getTicketsByUserId(userId: number): Promise<Ticket[]> {
    return await db.select().from(tickets).where(eq(tickets.userId, userId)).orderBy(desc(tickets.createdAt));
  }

  async getTicketById(id: number): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.id, id));
    return ticket || undefined;
  }

  async updateTicketStatus(id: number, status: string): Promise<Ticket> {
    const [ticket] = await db
      .update(tickets)
      .set({ status, updatedAt: new Date() })
      .where(eq(tickets.id, id))
      .returning();
    return ticket;
  }

  async createTicketMessage(insertMessage: InsertTicketMessage): Promise<TicketMessage> {
    const [message] = await db.insert(ticketMessages).values(insertMessage).returning();
    return message;
  }

  async getTicketMessages(ticketId: number): Promise<TicketMessage[]> {
    return await db.select().from(ticketMessages).where(eq(ticketMessages.ticketId, ticketId)).orderBy(desc(ticketMessages.createdAt));
  }

  async createGeneratedContent(insertContent: InsertGeneratedContent): Promise<GeneratedContent> {
    const [content] = await db.insert(generatedContent).values(insertContent).returning();
    return content;
  }

  async getGeneratedContentByUserId(userId: number): Promise<GeneratedContent[]> {
    return await db.select().from(generatedContent).where(eq(generatedContent.userId, userId)).orderBy(desc(generatedContent.createdAt));
  }

  async updateGeneratedContent(id: number, updates: Partial<GeneratedContent>): Promise<GeneratedContent> {
    const [content] = await db
      .update(generatedContent)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(generatedContent.id, id))
      .returning();
    return content;
  }

  async createBalanceTransaction(insertTransaction: InsertBalanceTransaction): Promise<BalanceTransaction> {
    const [transaction] = await db.insert(balanceTransactions).values(insertTransaction).returning();
    return transaction;
  }

  async getBalanceTransactionsByUserId(userId: number): Promise<BalanceTransaction[]> {
    return await db.select().from(balanceTransactions).where(eq(balanceTransactions.userId, userId)).orderBy(desc(balanceTransactions.createdAt));
  }

  async getTransactionByUuid(uuid: string): Promise<BalanceTransaction | undefined> {
    const [transaction] = await db.select().from(balanceTransactions).where(eq(balanceTransactions.paymentUuid, uuid));
    return transaction || undefined;
  }

  async updateTransactionStatus(id: number, status: string): Promise<BalanceTransaction> {
    const [transaction] = await db
      .update(balanceTransactions)
      .set({ status })
      .where(eq(balanceTransactions.id, id))
      .returning();
    return transaction;
  }
}

export const storage = new DatabaseStorage();
