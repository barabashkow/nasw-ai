import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { telegramService } from "./services/telegram";
import { openaiService } from "./services/openai";
import { n8nService } from "./services/n8n";
import { cryptoBotService } from "./services/cryptobot";
import { cryptomusOfficialService } from "./services/cryptomus_official";
import { cryptomusService } from "./services/cryptomus";
import { telegramBot } from "./bot_clean";
import { insertUserSchema, insertTicketSchema, insertTicketMessageSchema, insertGeneratedContentSchema } from "@shared/schema";
import { z } from "zod";

// CryptoBot payment processing only

export async function registerRoutes(app: Express): Promise<Server> {
  // Telegram bot webhook
  app.post("/webhook/telegram", async (req, res) => {
    try {
      console.log('Received telegram webhook:', JSON.stringify(req.body, null, 2));
      await telegramBot.handleUpdate(req.body);
      res.status(200).json({ ok: true });
    } catch (error) {
      console.error('Telegram webhook error:', error);
      res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  // User routes
  app.post("/api/users/auth", async (req, res) => {
    try {
      // In development mode, allow direct authentication without Telegram data
      if (process.env.NODE_ENV === 'development' && (!req.body.initData || req.body.initData === '')) {
        // Create development user
        const telegramData = {
          id: 12345,
          username: "dev_user",
          first_name: "Development",
          last_name: "User",
          language_code: "ru"
        };
        
        let user = await storage.getUserByTelegramId(telegramData.id.toString());
        if (!user) {
          try {
            const newUser = insertUserSchema.parse({
              telegramId: telegramData.id.toString(),
              username: telegramData.username,
              firstName: telegramData.first_name,
              lastName: telegramData.last_name,
              languageCode: telegramData.language_code || "ru",
            });
            user = await storage.createUser(newUser);
          } catch (err) {
            // If user creation fails due to duplicate key, try to fetch again
            user = await storage.getUserByTelegramId(telegramData.id.toString());
            if (!user) {
              throw err;
            }
          }
        }
        
        return res.json({ user });
      }
      
      const telegramData = telegramService.validateWebAppData(req.body);
      if (!telegramData) {
        return res.status(401).json({ error: "Invalid Telegram data" });
      }

      let user = await storage.getUserByTelegramId(telegramData.id.toString());
      if (!user) {
        try {
          // Create new user
          const newUser = insertUserSchema.parse({
            telegramId: telegramData.id.toString(),
            username: telegramData.username,
            firstName: telegramData.first_name,
            lastName: telegramData.last_name,
            languageCode: telegramData.language_code || "ru",
          });
          user = await storage.createUser(newUser);
        } catch (err) {
          // If user creation fails due to duplicate key, try to fetch again
          user = await storage.getUserByTelegramId(telegramData.id.toString());
          if (!user) {
            throw err;
          }
        }
      }

      res.json({ user });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Authentication failed' });
    }
  });

  app.get("/api/users/:telegramId", async (req, res) => {
    try {
      const user = await storage.getUserByTelegramId(req.params.telegramId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json({ user });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to fetch user' });
    }
  });

  // Subscription check endpoint
  app.get("/api/check-subscription", async (req, res) => {
    try {
      // Get user from Telegram WebApp data or development mode
      let userId;
      
      if (process.env.NODE_ENV === 'development') {
        // In development, assume user ID 12345
        userId = 12345;
      } else {
        // Parse user ID from Telegram WebApp initialization data
        const telegramData = req.headers['x-telegram-data'];
        if (!telegramData) {
          return res.status(401).json({ error: 'No Telegram data' });
        }
        
        const userData = JSON.parse(telegramData as string);
        userId = userData.user?.id;
      }
      
      if (!userId) {
        return res.status(400).json({ error: 'No user ID' });
      }

      // Check subscription using Telegram Bot API
      const channelId = '-1002549435159'; // @nasw_ai channel ID
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      
      if (!botToken) {
        console.log('TELEGRAM_BOT_TOKEN not set, returning subscribed=true for development');
        return res.json({ subscribed: true });
      }

      const response = await fetch(`https://api.telegram.org/bot${botToken}/getChatMember`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: channelId,
          user_id: userId
        })
      });

      const result = await response.json();
      
      if (result.ok) {
        const status = result.result.status;
        const isSubscribed = ['member', 'administrator', 'creator'].includes(status);
        res.json({ subscribed: isSubscribed });
      } else {
        console.log('Telegram API error:', result);
        // Fallback - assume subscribed for development
        res.json({ subscribed: true });
      }
    } catch (error) {
      console.error('Subscription check error:', error);
      // Fallback - assume subscribed to not block users
      res.json({ subscribed: true });
    }
  });

  // Payment routes
  app.post("/api/payment/create-crypto-invoice", async (req, res) => {
    try {
      const { telegramId, packageId, asset = 'USDT' } = req.body;
      
      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Define payment packages
      const packages: Record<string, { amount: number; bonus: number; price: { ru: number; en: number; kz: number } }> = {
        starter: { amount: 100, bonus: 0, price: { ru: 100, en: 1.5, kz: 700 } },
        basic: { amount: 200, bonus: 0, price: { ru: 200, en: 3.0, kz: 1400 } },
        popular: { amount: 500, bonus: 50, price: { ru: 500, en: 7.5, kz: 3500 } },
        premium: { amount: 1000, bonus: 150, price: { ru: 1000, en: 15.0, kz: 7000 } },
        ultimate: { amount: 3000, bonus: 500, price: { ru: 3000, en: 45.0, kz: 21000 } },
        pro: { amount: 5000, bonus: 1000, price: { ru: 5000, en: 75.0, kz: 35000 } }
      };

      const pkg = packages[packageId];
      if (!pkg) {
        return res.status(400).json({ error: "Invalid package" });
      }

      const cryptoAmount = cryptoBotService.getCryptoAmount(pkg.price.ru, asset);
      
      const invoiceResult = await cryptoBotService.createInvoice({
        asset,
        amount: cryptoAmount,
        description: `NASW AI: Пополнение баланса на ${pkg.amount + pkg.bonus} кредитов`,
        payload: JSON.stringify({ 
          telegramId, 
          packageId, 
          credits: pkg.amount + pkg.bonus,
          userId: user.id 
        }),
        expires_in: 3600 // 1 hour
      });

      if (invoiceResult.success && invoiceResult.data) {
        res.json({
          success: true,
          paymentUrl: invoiceResult.data.pay_url,
          invoiceId: invoiceResult.data.invoice_id,
          amount: cryptoAmount,
          asset,
          credits: pkg.amount + pkg.bonus
        });
      } else {
        res.status(400).json({ error: invoiceResult.error || "Failed to create crypto invoice" });
      }
    } catch (error) {
      console.error('Crypto payment error:', error);
      res.status(500).json({ error: "Payment processing failed" });
    }
  });

  // Get supported crypto currencies
  app.get("/api/payment/crypto-assets", async (req, res) => {
    try {
      const assets = cryptoBotService.getAvailableAssets();
      res.json({ assets });
    } catch (error) {
      res.status(500).json({ error: "Failed to get crypto assets" });
    }
  });

  // Webhook for CryptoBot payment confirmations
  app.post("/api/webhooks/cryptobot", async (req, res) => {
    try {
      const { invoice_id, status, payload } = req.body;
      
      if (status === 'paid' && payload) {
        const payloadData = JSON.parse(payload);
        const { telegramId, credits, userId } = payloadData;
        
        // Update user balance
        const user = await storage.getUserByTelegramId(telegramId);
        if (user) {
          const newBalance = (user.tokens || 0) + credits;
          await storage.updateUserBalance(telegramId, newBalance);
          
          // Update transaction status
          const transaction = await storage.getTransactionByUuid(invoice_id.toString());
          if (transaction) {
            await storage.updateTransactionStatus(transaction.id, 'completed');
          }
        }
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error('CryptoBot webhook error:', error);
      res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  // Webhook for Cryptomus payment confirmations
  app.post("/api/webhooks/cryptomus", async (req, res) => {
    try {
      const { uuid, order_id, status, additional_data } = req.body;
      
      if (status === 'paid' && additional_data) {
        const data = JSON.parse(additional_data);
        const { telegramId, tokens } = data;
        
        // Update user balance
        const user = await storage.getUserByTelegramId(telegramId);
        if (user) {
          const newBalance = (user.tokens || 0) + tokens;
          await storage.updateUserBalance(telegramId, newBalance);
          
          // Update transaction status
          const transaction = await storage.getTransactionByUuid(uuid);
          if (transaction) {
            await storage.updateTransactionStatus(transaction.id, 'completed');
          }
        }
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error('Cryptomus webhook error:', error);
      res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  // Check payment status 
  app.get("/api/payment/crypto-status/:invoiceId", async (req, res) => {
    try {
      const { invoiceId } = req.params;
      const result = await cryptoBotService.getInvoice(parseInt(invoiceId));
      
      if (result.success && result.data) {
        res.json({
          status: result.data.status,
          paid: result.data.status === 'paid'
        });
      } else {
        res.status(404).json({ error: "Invoice not found" });
      }
    } catch (error) {
      console.error('Payment status check error:', error);
      res.status(500).json({ error: "Failed to check payment status" });
    }
  });

  // Balance routes
  app.post("/api/balance/topup", async (req, res) => {
    try {
      const { telegramId, amount } = req.body;
      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Fallback to N8N webhook for other payment methods
      const paymentResult = await n8nService.processTopup(telegramId, amount);
      
      if (paymentResult.success) {
        // Update user balance
        const newBalance = (user.balance || 0) + amount;
        const updatedUser = await storage.updateUserBalance(telegramId, newBalance);
        
        // Create transaction record
        await storage.createBalanceTransaction({
          userId: user.id,
          type: "topup",
          amount,
          description: `Balance top-up via payment`,
          transactionId: paymentResult.transactionId,
        });

        res.json({ user: updatedUser, paymentUrl: paymentResult.paymentUrl });
      } else {
        res.status(400).json({ error: "Payment processing failed" });
      }
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Payment processing failed' });
    }
  });

  app.get("/api/balance/:telegramId", async (req, res) => {
    try {
      const result = await n8nService.checkBalance(req.params.telegramId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to check balance' });
    }
  });

  // Demo generation endpoint removed - using the proper one with token checking below

  app.get("/api/generated/:telegramId", async (req, res) => {
    try {
      const user = await storage.getUserByTelegramId(req.params.telegramId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const content = await storage.getGeneratedContentByUserId(user.id);
      res.json({ content });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to fetch generated content' });
    }
  });

  // Ticket routes
  app.post("/api/tickets", async (req, res) => {
    try {
      const { telegramId, title, description, attachments } = req.body;
      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const ticketData = insertTicketSchema.parse({
        userId: user.id,
        title,
        description,
        attachments: attachments || [],
      });

      const ticket = await storage.createTicket(ticketData);
      
      // Notify admin group via Telegram
      await telegramService.notifyAdmins(ticket, user);

      res.json({ ticket });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to create ticket' });
    }
  });

  app.get("/api/tickets/:telegramId", async (req, res) => {
    try {
      const user = await storage.getUserByTelegramId(req.params.telegramId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const tickets = await storage.getTicketsByUserId(user.id);
      res.json({ tickets });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to fetch tickets' });
    }
  });

  app.post("/api/tickets/:ticketId/messages", async (req, res) => {
    try {
      const { telegramId, message, attachments } = req.body;
      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const messageData = insertTicketMessageSchema.parse({
        ticketId: parseInt(req.params.ticketId),
        senderId: user.id,
        message,
        attachments: attachments || [],
        isFromAdmin: false,
      });

      const ticketMessage = await storage.createTicketMessage(messageData);
      res.json({ message: ticketMessage });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to create message' });
    }
  });

  app.get("/api/tickets/:ticketId/messages", async (req, res) => {
    try {
      const messages = await storage.getTicketMessages(parseInt(req.params.ticketId));
      res.json({ messages });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to fetch messages' });
    }
  });

  // Telegram Bot Webhook
  app.post("/api/telegram/webhook", async (req, res) => {
    try {
      await telegramBot.handleUpdate(req.body);
      res.status(200).json({ ok: true });
    } catch (error) {
      console.error('Telegram webhook error:', error);
      res.status(500).json({ error: error instanceof Error ? error.message : 'Webhook failed' });
    }
  });

  // WebApp payment routes for Cryptomus
  app.post("/api/payment/cryptomus/create", async (req, res) => {
    try {
      const { telegramId, packageId, currency = 'USDT' } = req.body;
      
      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const packages = cryptomusOfficialService.getPaymentPackages();
      const selectedPackage = packages.find(p => p.id === packageId);
      
      if (!selectedPackage) {
        return res.status(400).json({ error: "Invalid package" });
      }

      // Create unique order ID
      const orderId = `nasw_${user.id}_${Date.now()}`;
      
      // Convert ruble amount to crypto
      const cryptoAmount = await cryptomusOfficialService.convertRubleToCrypto(selectedPackage.price.ru, currency);
      
      // Create Cryptomus invoice
      const invoiceResult = await cryptomusOfficialService.createInvoice({
        amount: cryptoAmount,
        currency: currency.toUpperCase(),
        order_id: orderId,
        url_callback: `${process.env.REPLIT_DOMAINS?.split(',')[0] || 'https://telegram-video-bot-opteinnity.replit.app'}/webhook/cryptomus`,
        url_success: `https://t.me/nasw_AI_bot/myapp`,
        url_return: `https://t.me/nasw_AI_bot/myapp`,
        additional_data: JSON.stringify({
          userId: user.id,
          credits: selectedPackage.amount + selectedPackage.bonus,
          bonus: selectedPackage.bonus,
          telegramId
        }),
        lifetime: 3600 // 1 hour
      });

      if (invoiceResult.success && invoiceResult.data) {
        // Save transaction to database
        await storage.createBalanceTransaction({
          userId: user.id,
          type: 'topup',
          amount: selectedPackage.amount + selectedPackage.bonus,
          bonus: selectedPackage.bonus,
          status: 'pending',
          paymentUuid: invoiceResult.data.uuid,
          transactionId: orderId
        });

        res.json({
          success: true,
          payment_url: invoiceResult.data.url,
          uuid: invoiceResult.data.uuid,
          amount: cryptoAmount,
          currency: currency.toUpperCase(),
          credits: selectedPackage.amount + selectedPackage.bonus
        });
      } else {
        res.status(400).json({ error: invoiceResult.error || "Failed to create payment" });
      }
    } catch (error) {
      console.error('Cryptomus payment creation error:', error);
      res.status(500).json({ error: "Payment processing failed" });
    }
  });

  // Check payment status
  app.get("/api/payment/cryptomus/status/:uuid", async (req, res) => {
    try {
      const { uuid } = req.params;
      const result = await cryptomusOfficialService.getPaymentInfo(uuid);
      
      if (result.success && result.data) {
        res.json({
          status: result.data.payment_status,
          paid: result.data.payment_status === 'paid'
        });
      } else {
        res.status(404).json({ error: "Payment not found" });
      }
    } catch (error) {
      console.error('Payment status check error:', error);
      res.status(500).json({ error: "Failed to check payment status" });
    }
  });

  // Get payment packages
  app.get("/api/payment/packages", async (req, res) => {
    try {
      const packages = cryptomusOfficialService.getPaymentPackages();
      const currencies = cryptomusOfficialService.getSupportedCurrencies();
      
      res.json({ packages, currencies });
    } catch (error) {
      res.status(500).json({ error: "Failed to get payment packages" });
    }
  });

  // Webhook endpoint for Cryptomus payments
  app.post("/webhook/cryptomus", async (req, res) => {
    try {
      const signature = req.headers['sign'] as string;
      
      if (!cryptomusOfficialService.validateWebhook(req.body, signature)) {
        console.error('Invalid Cryptomus webhook signature');
        return res.sendStatus(401);
      }

      const { uuid, payment_status, order_id, payment_amount, payer_currency, additional_data } = req.body;
      console.log(`Cryptomus webhook: ${payment_status} for ${uuid} - ${payment_amount} ${payer_currency}`);
      
      if (payment_status === 'paid') {
        // Find transaction in database
        const transaction = await storage.getTransactionByUuid(uuid);
        
        if (transaction && transaction.status === 'pending') {
          // Update transaction status
          await storage.updateTransactionStatus(transaction.id, 'paid');
          
          // Add balance to user (amount + bonus)
          await storage.updateUserBalance(transaction.userId.toString(), transaction.amount);
          
          console.log(`Payment successful: ${uuid}, user: ${transaction.userId}, amount: ${payment_amount}`);
        }
      } else if (payment_status === 'fail' || payment_status === 'cancel') {
        // Update transaction status
        const transaction = await storage.getTransactionByUuid(uuid);
        if (transaction) {
          await storage.updateTransactionStatus(transaction.id, 'failed');
        }
      }

      res.sendStatus(200);
    } catch (error) {
      console.error("Cryptomus webhook error:", error);
      res.sendStatus(500);
    }
  });

  // Check Telegram channel subscription
  app.get('/api/check-subscription', async (req, res) => {
    try {
      // Mock subscription check - in production would use Telegram Bot API
      const isSubscribed = Math.random() > 0.3; // Temporary mock - mostly return true
      res.json({ subscribed: isSubscribed });
    } catch (error) {
      console.error('Subscription check error:', error);
      res.status(500).json({ error: 'Failed to check subscription' });
    }
  });

  // Generate content (photos/videos) - Updated with proper token checking
  app.post('/api/generate', async (req, res) => {
    console.log('Generate endpoint called with:', req.body);
    try {
      const { type, prompt, telegramId } = req.body;
      
      if (!type || !prompt || !telegramId) {
        return res.status(400).json({ error: 'Type, prompt and telegramId are required' });
      }

      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check if user has enough tokens
      const cost = getGenerationCost(type);
      if (!user.tokens || user.tokens < cost) {
        return res.status(402).json({ error: 'Insufficient tokens', required: cost, current: user.tokens || 0 });
      }

      // Only photo generation is implemented for now
      if (type !== 'photo') {
        return res.status(400).json({ error: 'Only photo generation is available' });
      }

      // Deduct tokens first (updateUserBalance expects the new balance value)
      const newTokenBalance = user.tokens - cost;
      console.log(`Deducting tokens: ${user.tokens} - ${cost} = ${newTokenBalance}`);
      
      await storage.updateUserBalance(telegramId, newTokenBalance);
      console.log(`Tokens deducted for user ${telegramId}`);

      // Generate photo using OpenAI DALL-E 3
      console.log('Starting OpenAI generation...');
      const result = await openaiService.generateContent("image", prompt);
      console.log('OpenAI generation result:', result);
      
      if (result.success && result.data) {
        // Save to generated content
        console.log('Saving generated content...');
        await storage.createGeneratedContent({
          userId: user.id,
          type,
          prompt,
          status: 'completed',
          cost,
          resultUrl: result.data.url
        });
        console.log('Content saved successfully');

        res.json({ 
          success: true,
          url: result.data.url,
          thumbnail: result.data.url, // DALL-E returns the full image as thumbnail
          cost
        });
      } else {
        // Refund tokens on failure
        console.log('Generation failed, refunding tokens...');
        await storage.updateUserBalance(telegramId, user.tokens);
        res.status(500).json({ error: result.error || 'Generation failed' });
      }
    } catch (error) {
      console.error('Content generation error:', error);
      res.status(500).json({ error: 'Failed to generate content' });
    }
  });

  // Get user's generated content (Gallery)
  app.get('/api/gallery/:telegramId', async (req, res) => {
    try {
      const { telegramId } = req.params;
      const user = await storage.getUserByTelegramId(telegramId);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const content = await storage.getGeneratedContentByUserId(user.id);
      res.json({ content });
    } catch (error) {
      console.error('Get gallery error:', error);
      res.status(500).json({ error: 'Failed to get gallery' });
    }
  });

  // Unified payment endpoint - 10 tokens = 100₽/1.5$/800₸
  app.post('/api/payment/create', async (req, res) => {
    try {
      const { method, packageId, telegramId } = req.body;
      
      if (!method || !packageId || !telegramId) {
        return res.status(400).json({ error: 'Missing required parameters' });
      }

      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Package definitions - 10 tokens = 100₽/1.5$/800₸
      const packages: Record<string, { tokens: number; bonus: number; priceRub: number }> = {
        starter: { tokens: 10, bonus: 0, priceRub: 100 },
        basic: { tokens: 50, bonus: 5, priceRub: 500 },
        premium: { tokens: 100, bonus: 20, priceRub: 1000 },
        ultimate: { tokens: 500, bonus: 100, priceRub: 5000 }
      };

      const pkg = packages[packageId];
      if (!pkg) {
        return res.status(400).json({ error: 'Invalid package' });
      }

      const totalTokens = pkg.tokens + pkg.bonus;
      const orderId = `${telegramId}_${packageId}_${Date.now()}`;

      if (method === 'cryptobot') {
        // Create CryptoBot invoice - redirect to bot
        const asset = 'USDT';
        const cryptoAmount = cryptoBotService.getCryptoAmount(pkg.priceRub, asset);
        
        const invoiceResult = await cryptoBotService.createInvoice({
          asset,
          amount: cryptoAmount,
          description: `NASW AI: ${totalTokens} tokens (${pkg.tokens} + ${pkg.bonus} bonus)`,
          payload: JSON.stringify({ 
            telegramId, 
            packageId, 
            credits: totalTokens,
            userId: user.id 
          }),
          expires_in: 3600
        });

        if (invoiceResult.success && invoiceResult.data) {
          res.json({
            success: true,
            paymentUrl: invoiceResult.data.bot_invoice_url || invoiceResult.data.pay_url,
            invoiceId: invoiceResult.data.invoice_id,
            amount: cryptoAmount,
            asset: asset,
            tokens: totalTokens
          });
        } else {
          res.status(400).json({ error: invoiceResult.error || 'Failed to create CryptoBot invoice' });
        }
      } else if (method === 'cryptomus') {
        // Create Cryptomus payment - redirect to website
        const paymentResult = await cryptomusService.createPayment({
          amount: pkg.priceRub.toString(),
          currency: 'RUB',
          order_id: orderId,
          to_currency: 'USDT',
          url_return: 'https://t.me/nasw_AI_bot/myapp',
          url_success: 'https://t.me/nasw_AI_bot/myapp',
          url_callback: `${process.env.REPLIT_DOMAIN || 'https://telegram-video-bot-opteinnity.replit.app'}/api/webhooks/cryptomus`,
          additional_data: JSON.stringify({ telegramId, packageId, tokens: totalTokens })
        });

        if (paymentResult.success && paymentResult.data) {
          // Save transaction
          await storage.createBalanceTransaction({
            userId: user.id,
            type: 'topup',
            amount: totalTokens,
            status: 'pending',
            paymentUuid: paymentResult.data.uuid,
            transactionId: orderId,
            currency: 'RUB',
            cryptoAmount: pkg.priceRub.toString(),
            cryptoCurrency: 'RUB',
            bonus: pkg.bonus,
            description: `Payment via Cryptomus: ${totalTokens} tokens`
          });

          res.json({
            success: true,
            paymentUrl: paymentResult.data.url,
            uuid: paymentResult.data.uuid,
            amount: paymentResult.data.payer_amount || paymentResult.data.amount,
            currency: paymentResult.data.payer_currency || 'USDT',
            tokens: totalTokens
          });
        } else {
          res.status(400).json({ error: paymentResult.error || 'Failed to create Cryptomus payment' });
        }
      } else {
        res.status(400).json({ error: 'Invalid payment method' });
      }
    } catch (error) {
      console.error('Payment creation error:', error);
      res.status(500).json({ error: 'Payment processing failed' });
    }
  });

  // Dice game endpoints with proper 24h cooldown
  app.get('/api/dice-game/status/:telegramId', async (req, res) => {
    try {
      const { telegramId } = req.params;
      const user = await storage.getUserByTelegramId(telegramId);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const now = Date.now();
      const lastDiceRoll = user.lastDiceRoll ? new Date(user.lastDiceRoll).getTime() : 0;
      const cooldownPeriod = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
      const nextAttempt = lastDiceRoll + cooldownPeriod;
      const canPlay = now >= nextAttempt;

      res.json({
        canPlay,
        nextAttemptAt: canPlay ? null : new Date(nextAttempt).toISOString(),
        lastAttempt: user.lastDiceRoll,
        timeLeft: canPlay ? 0 : nextAttempt - now
      });
    } catch (error) {
      console.error('Dice game status error:', error);
      res.status(500).json({ error: 'Failed to get game status' });
    }
  });

  app.post('/api/dice-game/roll', async (req, res) => {
    try {
      const { telegramId, guess } = req.body;
      
      if (!telegramId || !guess || guess < 1 || guess > 6) {
        return res.status(400).json({ error: 'Invalid request' });
      }

      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check cooldown
      const now = Date.now();
      const lastDiceRoll = user.lastDiceRoll ? new Date(user.lastDiceRoll).getTime() : 0;
      const cooldownPeriod = 24 * 60 * 60 * 1000;
      
      if (lastDiceRoll && now < lastDiceRoll + cooldownPeriod) {
        return res.status(429).json({ 
          error: 'Please wait 24 hours between attempts',
          nextAttemptAt: new Date(lastDiceRoll + cooldownPeriod).toISOString()
        });
      }

      // Roll the dice
      const result = Math.floor(Math.random() * 6) + 1;
      const won = result === guess;

      // Update last dice roll time
      await storage.updateUser(telegramId, { lastDiceRoll: new Date() });

      // If won, add 1 free token
      if (won) {
        await storage.updateUserBalance(telegramId, (user.tokens || 0) + 1);
      }

      res.json({
        won,
        guess,
        result,
        reward: won ? 1 : 0,
        nextAttemptAt: new Date(now + cooldownPeriod).toISOString()
      });
    } catch (error) {
      console.error('Dice roll error:', error);
      res.status(500).json({ error: 'Failed to roll dice' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function getGenerationCost(type: string): number {
  const costs: Record<string, number> = {
    photo: 1,
    video: 50,
    music: 30,
    voice: 15,
  };
  return costs[type] || 1;
}
