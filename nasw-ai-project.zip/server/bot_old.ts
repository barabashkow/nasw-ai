/**
 * Telegram Bot Handler
 * Обрабатывает команды и сообщения в боте
 */

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const WEBAPP_URL = 'https://telegram-video-bot-opteinnity.replit.app/';

interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    from: {
      id: number;
      is_bot: boolean;
      first_name: string;
      username?: string;
      language_code?: string;
    };
    chat: {
      id: number;
      first_name: string;
      username?: string;
      type: string;
    };
    date: number;
    text?: string;
    dice?: {
      emoji: string;
      value: number;
    };
  };
  callback_query?: {
    id: string;
    from: {
      id: number;
      first_name: string;
      username?: string;
    };
    message: {
      message_id: number;
      chat: {
        id: number;
      };
    };
    data: string;
  };
}

export class TelegramBot {
  private botToken: string;
  private webhookUrl: string;
  private userLanguages: Map<number, string> = new Map();
  private userDiceGames: Map<number, { guess: number; messageId: number }> = new Map();
  private userDiceCooldowns: Map<number, number> = new Map();
  private channelId = '-1002758240616';

  constructor() {
    this.botToken = TELEGRAM_BOT_TOKEN || '';
    this.webhookUrl = '';
  }

  async sendMessage(chatId: number, text: string, extra: any = {}) {
    const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
        ...extra
      }),
    });

    return response.json();
  }

  async handleUpdate(update: TelegramUpdate) {
    try {
      // Handle callback queries
      if (update.callback_query) {
        await this.handleCallbackQuery(update.callback_query);
        return;
      }

      // Handle dice messages
      if (update.message?.dice) {
        await this.handleDiceResult(update.message);
        return;
      }

      // Handle text messages
      if (!update.message?.text) {
        return;
      }

      const { message } = update;
      const chatId = message.chat.id;
      const text = message.text;
      const firstName = message.from.first_name;
      const userId = message.from.id;

      console.log(`Получено сообщение от ${firstName} (${chatId}): ${text}`);

      if (text.startsWith('/start')) {
        await this.handleStartCommand(chatId, firstName, userId);
      } else if (text.match(/^[1-6]$/)) {
        await this.handleDiceGuess(chatId, parseInt(text), userId);
      } else {
        await this.handleDefaultMessage(chatId, firstName);
      }
    } catch (error) {
      console.error('Error handling update:', error);
    }
  }

  private async handleStartCommand(chatId: number, firstName: string, userId: number) {
    await this.showLanguageSelection(chatId);
  }

  private async showLanguageSelection(chatId: number) {
    const text = `Выберите язык / Select language / Тілді таңдаңыз:`;

    await this.sendMessage(chatId, text, {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Русский', callback_data: 'lang_ru' },
            { text: 'English', callback_data: 'lang_en' },
            { text: 'Қазақша', callback_data: 'lang_kz' }
          ]
        ]
      }
    });
  }

  private async handleCallbackQuery(callbackQuery: any) {
    const chatId = callbackQuery.message.chat.id;
    const userId = callbackQuery.from.id;
    const data = callbackQuery.data;
    const firstName = callbackQuery.from.first_name;

    // Answer callback query
    await this.answerCallbackQuery(callbackQuery.id);

    if (data.startsWith('lang_')) {
      const language = data.split('_')[1];
      this.userLanguages.set(userId, language);
      
      // Delete language selection message
      await this.deleteMessage(chatId, callbackQuery.message.message_id);
      
      // Show main interface
      await this.showMainInterface(chatId, firstName, userId, language);
    } else if (data === 'select_language') {
      await this.showLanguageSelection(chatId);
    } else if (data === 'free_generation') {
      await this.handleFreeGeneration(chatId, userId);
    } else if (data === 'open_generator') {
      await this.openGenerator(chatId, userId);
    }
  }

  private async showMainInterface(chatId: number, firstName: string, userId: number, language: string) {
    const texts = {
      ru: `Добро пожаловать в NASW AI

NASW AI — это интеллектуальная платформа нового поколения для генерации мультимедийного контента с помощью искусственного интеллекта.

Доступные возможности:
— Генерация видео с помощью Veo 3 от Google
— Создание изображений по текстовому описанию
— Генерация собственой музыки
— Личный кабинет с галереей всех созданных работ
— Поддержка 24/7 и удобное пополнение баланса`,
      en: `Welcome to NASW AI

NASW AI is a next-generation intelligent platform for generating multimedia content using artificial intelligence.

Available features:
— Video generation using Veo 3 from Google
— Image creation from text descriptions
— Custom music generation
— Personal cabinet with gallery of all created works
— 24/7 support and convenient balance top-up`,
      kz: `NASW AI-ге қош келдіңіз

NASW AI — жасанды интеллект көмегімен мультимедиа мазмұнын генерациялау үшін жаңа буын интеллектуалды платформасы.

Қолжетімді мүмкіндіктер:
— Google-дің Veo 3 көмегімен бейне генерациясы
— Мәтіндік сипаттамадан кескін жасау
— Өзіндік музыка генерациясы
— Барлық жасалған жұмыстардың галереясы бар жеке кабинет
— 24/7 қолдау және ыңғайлы баланс толықтыру`
    };

    const buttons = {
      ru: [
        [{ text: 'Генерировать', callback_data: 'open_generator' }],
        [{ text: 'Язык', callback_data: 'select_language' }],
        [{ text: 'Бесплатная генерация', callback_data: 'free_generation' }]
      ],
      en: [
        [{ text: 'Generate', callback_data: 'open_generator' }],
        [{ text: 'Language', callback_data: 'select_language' }],
        [{ text: 'Free generation', callback_data: 'free_generation' }]
      ],
      kz: [
        [{ text: 'Генерациялау', callback_data: 'open_generator' }],
        [{ text: 'Тіл', callback_data: 'select_language' }],
        [{ text: 'Тегін генерация', callback_data: 'free_generation' }]
      ]
    };

    await this.sendMessage(chatId, texts[language as keyof typeof texts], {
      reply_markup: {
        inline_keyboard: buttons[language as keyof typeof buttons]
      }
    });
  }

  private async checkChannelSubscription(userId: number): Promise<boolean> {
    try {
      const url = `https://api.telegram.org/bot${this.botToken}/getChatMember`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: this.channelId,
          user_id: userId
        })
      });

      const result = await response.json();
      return result.ok && ['member', 'administrator', 'creator'].includes(result.result.status);
    } catch (error) {
      console.error('Subscription check error:', error);
      return false; // In development, return true for testing
    }
  }

  private async handleDefaultMessage(chatId: number, firstName: string) {
    const texts = {
      ru: `Используйте команду /start для начала работы с ботом.`,
      en: `Use /start command to begin working with the bot.`,
      kz: `Ботпен жұмысты бастау үшін /start командасын пайдаланыңыз.`
    };

    await this.sendMessage(chatId, texts.ru);
  }
}
🎨 <b>Добро пожаловать, ${firstName}!</b>

✨ NASW AI - ваш помощник для создания контента:

🖼 <b>Фото</b> - генерация изображений DALL-E
🎬 <b>Видео</b> - создание роликов Veo 3
💰 <b>Баланс</b> - пополнение и отслеживание
🎫 <b>Поддержка</b> - помощь 24/7

Выберите действие:
      `,
      en: `
🎨 <b>Welcome, ${firstName}!</b>

✨ NASW AI - your content creation assistant:

🖼 <b>Photos</b> - DALL-E image generation
🎬 <b>Videos</b> - Veo 3 video creation
💰 <b>Balance</b> - top-up and tracking
🎫 <b>Support</b> - 24/7 help

Choose an action:
      `,
      kz: `
🎨 <b>Қош келдіңіз, ${firstName}!</b>

✨ NASW AI - контент жасау көмекшісі:

🖼 <b>Фото</b> - DALL-E сурет генерациясы
🎬 <b>Видео</b> - Veo 3 видео жасау
💰 <b>Баланс</b> - толықтыру және бақылау
🎫 <b>Қолдау</b> - 24/7 көмек

Әрекетті таңдаңыз:
      `
    };

    const buttons = {
      ru: [
        [{ text: '🚀 Сгенерировать', callback_data: 'open_app' }],
        [{ text: '📖 Информация', callback_data: 'info' }, { text: '🎲 Бесплатная генерация', callback_data: 'free_generation' }]
      ],
      en: [
        [{ text: '🚀 Generate', callback_data: 'open_app' }],
        [{ text: '📖 Information', callback_data: 'info' }, { text: '🎲 Free generation', callback_data: 'free_generation' }]
      ],
      kz: [
        [{ text: '🚀 Генерациялау', callback_data: 'open_app' }],
        [{ text: '📖 Ақпарат', callback_data: 'info' }, { text: '🎲 Тегін генерация', callback_data: 'free_generation' }]
      ]
    };

    await this.sendMessage(chatId, texts[language as keyof typeof texts], {
      reply_markup: {
        inline_keyboard: buttons[language as keyof typeof buttons]
      }
    });
  }

  private async handleFreeGeneration(chatId: number, userId: number) {
    const language = this.userLanguages.get(userId) || 'ru';
    const now = Date.now();
    const cooldownEnd = this.userDiceCooldowns.get(userId) || 0;

    if (now < cooldownEnd) {
      const remainingHours = Math.ceil((cooldownEnd - now) / (1000 * 60 * 60));
      const cooldownTexts = {
        ru: `Вы уже играли. Повторить можно через: ${remainingHours} часов`,
        en: `You already played. Try again in: ${remainingHours} hours`,
        kz: `Сіз ойнағансыз. Қайталау мүмкіндігі: ${remainingHours} сағаттан кейін`
      };
      
      await this.answerCallbackQuery(userId.toString(), cooldownTexts[language as keyof typeof cooldownTexts]);
      return;
    }

    const texts = {
      ru: `Выберите число от 1 до 6. Если угадаете - получите 1 бесплатную генерацию!

Напишите число от 1 до 6:`,
      en: `Choose a number from 1 to 6. If you guess - get 1 free generation!

Type a number from 1 to 6:`,
      kz: `1-ден 6-ға дейін санды таңдаңыз. Егер болжасаңыз - 1 тегін генерация аласыз!

1-ден 6-ға дейін санды жазыңыз:`
    };

    await this.sendMessage(chatId, texts[language as keyof typeof texts]);
  }

  private async handleDiceGuess(chatId: number, guess: number, userId: number) {
    const language = this.userLanguages.get(userId) || 'ru';
    
    // Send dice
    const diceMessage = await this.sendDice(chatId);
    
    // Store the game
    this.userDiceGames.set(userId, { 
      guess, 
      messageId: diceMessage.result.message_id 
    });

    const texts = {
      ru: `Ваш выбор: ${guess}\nБросаю кубик...`,
      en: `Your choice: ${guess}\nRolling dice...`,
      kz: `Сіздің таңдауыңыз: ${guess}\nТекшені лақтыру...`
    };

    await this.sendMessage(chatId, texts[language as keyof typeof texts]);
  }

  private async handleDiceResult(message: any) {
    const userId = message.from.id;
    const chatId = message.chat.id;
    const diceValue = message.dice.value;
    const language = this.userLanguages.get(userId) || 'ru';
    
    const game = this.userDiceGames.get(userId);
    if (!game) return;

    this.userDiceGames.delete(userId);

    const isWin = game.guess === diceValue;
    
    if (isWin) {
      const winTexts = {
        ru: `Поздравляем!

Ваше число: ${game.guess}
Выпало: ${diceValue}

Вы выиграли 1 бесплатную генерацию!
Она будет добавлена на ваш баланс.`,
        en: `Congratulations!

Your number: ${game.guess}
Rolled: ${diceValue}

You won 1 free generation!
It will be added to your balance.`,
        kz: `Құттықтаймыз!

Сіздің саныңыз: ${game.guess}
Шықты: ${diceValue}

Сіз 1 тегін генерация ұттыңыз!
Ол сіздің балансыңызға қосылады.`
      };

      await this.sendMessage(chatId, winTexts[language as keyof typeof winTexts]);
      
      // TODO: Add 1 credit to user balance in database
      
    } else {
      // Set 24-hour cooldown
      const cooldownEnd = Date.now() + (24 * 60 * 60 * 1000);
      this.userDiceCooldowns.set(userId, cooldownEnd);

      const loseTexts = {
        ru: `Вы не выиграли. Следующая попытка через 24 часа

Ваше число: ${game.guess}
Выпало: ${diceValue}`,
        en: `You didn't win. Next attempt in 24 hours

Your number: ${game.guess}
Rolled: ${diceValue}`,
        kz: `Сіз ұтылмадыңыз. Келесі әрекет 24 сағаттан кейін

Сіздің саныңыз: ${game.guess}
Шықты: ${diceValue}`
      };

      await this.sendMessage(chatId, loseTexts[language as keyof typeof loseTexts]);
    }
  }







  private async openGenerator(chatId: number, userId: number) {
    const language = this.userLanguages.get(userId) || 'ru';
    
    const texts = {
      ru: 'Открывается генератор контента...',
      en: 'Opening content generator...',
      kz: 'Контент генераторы ашылуда...'
    };

    await this.sendMessage(chatId, texts[language as keyof typeof texts], {
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: 'Генерировать', 
            web_app: { url: WEBAPP_URL }
          }]
        ]
      }
    });
  }

  private async sendDice(chatId: number) {
    const url = `https://api.telegram.org/bot${this.botToken}/sendDice`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        emoji: '🎲'
      })
    });
    return response.json();
  }

  private async answerCallbackQuery(callbackQueryId: string, text?: string) {
    const url = `https://api.telegram.org/bot${this.botToken}/answerCallbackQuery`;
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        callback_query_id: callbackQueryId,
        text
      })
    });
  }

  private async deleteMessage(chatId: number, messageId: number) {
    const url = `https://api.telegram.org/bot${this.botToken}/deleteMessage`;
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId
      })
    });
  }

  private async handleDefaultMessage(chatId: number, firstName: string) {
    const text = `
👋 Привет, ${firstName}!

Используйте команду /start для начала работы с ботом.
    `.trim();

    await this.sendMessage(chatId, text);
  }
}

export const telegramBot = new TelegramBot();