import OpenAI from "openai";

class OpenAIService {
  private client: OpenAI;

  constructor() {
    this.client = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }

  async generateContent(type: string, prompt: string, style?: string): Promise<{ success: boolean; data?: any; error?: string }> {
    try {
      if (!process.env.OPENAI_API_KEY) {
        return { success: false, error: "OpenAI API key not configured" };
      }
      
      switch (type) {
        case "text":
          return await this.generateText(prompt, style);
        case "image":
          return await this.generateImage(prompt, style);
        case "voice":
          return await this.generateVoice(prompt);
        default:
          return { success: false, error: "Unsupported content type" };
      }
    } catch (error: any) {
      console.error('OpenAI generation error:', error);
      return { success: false, error: error.message || 'OpenAI generation failed' };
    }
  }

  private async generateText(prompt: string, style?: string): Promise<{ success: boolean; data?: any; error?: string }> {
    const systemPrompt = style === "artistic" 
      ? "You are a creative writer. Write in an artistic, poetic style."
      : "You are a helpful assistant. Write clear, informative content.";

    const response = await this.client.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: prompt }
      ],
      max_tokens: 1000,
    });

    return {
      success: true,
      data: {
        text: response.choices[0].message.content,
        model: "gpt-4o",
        usage: response.usage,
      }
    };
  }

  private async generateImage(prompt: string, style?: string): Promise<{ success: boolean; data?: any; error?: string }> {
    const enhancedPrompt = style === "artistic" 
      ? `Artistic style, creative interpretation: ${prompt}`
      : `Realistic style, photographic quality: ${prompt}`;

    const response = await this.client.images.generate({
      model: "dall-e-3",
      prompt: enhancedPrompt,
      n: 1,
      size: "1024x1024",
      quality: "standard",
    });

    return {
      success: true,
      data: {
        url: response.data[0].url,
        prompt: enhancedPrompt,
        model: "dall-e-3",
      }
    };
  }

  private async generateVoice(text: string): Promise<{ success: boolean; data?: any; error?: string }> {
    const mp3 = await this.client.audio.speech.create({
      model: "tts-1",
      voice: "alloy",
      input: text,
    });

    const buffer = Buffer.from(await mp3.arrayBuffer());
    
    return {
      success: true,
      data: {
        audio: buffer.toString('base64'),
        format: "mp3",
        model: "tts-1",
      }
    };
  }
}

export const openaiService = new OpenAIService();
