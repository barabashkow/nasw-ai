/**
 * Official Cryptomus Payment Service
 * Based on official documentation: https://doc.cryptomus.com/business/payments/
 */

import crypto from 'crypto';

interface CryptomusPayment {
  uuid: string;
  order_id: string;
  amount: string;
  payment_amount: string;
  payer_amount: string;
  discount_percent: number;
  discount: string;
  payer_currency: string;
  currency: string;
  merchant_amount: string;
  network: string;
  address: string;
  from: string;
  txid: string;
  payment_status: string;
  url: string;
  expired_at: string;
  is_final: boolean;
  additional_data: string;
  created_at: string;
  updated_at: string;
}

interface CreateInvoiceRequest {
  amount: string;
  currency: string;
  order_id: string;
  network?: string;
  url_return?: string;
  url_success?: string;
  url_callback?: string;
  is_payment_multiple?: boolean;
  lifetime?: number;
  to_currency?: string;
  subtract?: number;
  accuracy_payment_percent?: number;
  additional_data?: string;
  currencies?: Array<{ currency: string; network?: string }>;
  except_currencies?: Array<{ currency: string; network?: string }>;
  course_source?: string;
  from_referral_code?: string;
  discount_percent?: number;
  is_refresh?: boolean;
}

interface CryptomusResponse {
  state: number;
  result?: CryptomusPayment;
  message?: string;
}

class CryptomusOfficialService {
  private apiKey: string;
  private merchantId: string;
  private baseUrl = 'https://api.cryptomus.com/v1';

  constructor() {
    this.apiKey = process.env.CRYPTOMUS_API_KEY || '';
    this.merchantId = process.env.CRYPTOMUS_MERCHANT_ID || '';
    
    if (!this.apiKey || !this.merchantId) {
      console.warn('Cryptomus API credentials not provided');
    }
  }

  private generateSignature(data: any): string {
    const jsonString = JSON.stringify(data, Object.keys(data).sort());
    const base64Data = Buffer.from(jsonString, 'utf8').toString('base64');
    const signature = crypto.createHash('md5').update(base64Data + this.apiKey).digest('hex');
    return signature;
  }

  async createInvoice(params: CreateInvoiceRequest): Promise<{ success: boolean; data?: CryptomusPayment; error?: string }> {
    try {
      const signature = this.generateSignature(params);
      
      const response = await fetch(`${this.baseUrl}/payment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'merchant': this.merchantId,
          'sign': signature
        },
        body: JSON.stringify(params)
      });

      const result: CryptomusResponse = await response.json();
      
      if (result.state === 0 && result.result) {
        return { success: true, data: result.result };
      } else {
        return { success: false, error: result.message || 'Failed to create invoice' };
      }
    } catch (error) {
      console.error('Cryptomus API error:', error);
      return { success: false, error: 'Network error' };
    }
  }

  async getPaymentInfo(uuid: string): Promise<{ success: boolean; data?: CryptomusPayment; error?: string }> {
    try {
      const params = { uuid };
      const signature = this.generateSignature(params);
      
      const response = await fetch(`${this.baseUrl}/payment/info`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'merchant': this.merchantId,
          'sign': signature
        },
        body: JSON.stringify(params)
      });

      const result: CryptomusResponse = await response.json();
      
      if (result.state === 0 && result.result) {
        return { success: true, data: result.result };
      } else {
        return { success: false, error: result.message || 'Payment not found' };
      }
    } catch (error) {
      console.error('Cryptomus payment info error:', error);
      return { success: false, error: 'Network error' };
    }
  }

  validateWebhook(body: any, signature: string): boolean {
    try {
      const expectedSignature = this.generateSignature(body);
      return expectedSignature === signature;
    } catch (error) {
      console.error('Webhook validation error:', error);
      return false;
    }
  }

  getPaymentPackages() {
    return [
      { id: 'starter', amount: 100, bonus: 0, price: { ru: 100, en: 1.5, kz: 700 } },
      { id: 'basic', amount: 200, bonus: 0, price: { ru: 200, en: 3.0, kz: 1400 } },
      { id: 'popular', amount: 500, bonus: 50, price: { ru: 500, en: 7.5, kz: 3500 } },
      { id: 'premium', amount: 1000, bonus: 150, price: { ru: 1000, en: 15.0, kz: 7000 } },
      { id: 'ultimate', amount: 3000, bonus: 500, price: { ru: 3000, en: 45.0, kz: 21000 } },
      { id: 'pro', amount: 5000, bonus: 1000, price: { ru: 5000, en: 75.0, kz: 35000 } }
    ];
  }

  getSupportedCurrencies(): string[] {
    return ['USDT', 'BTC', 'ETH', 'LTC', 'BCH', 'ADA', 'XRP', 'TRX', 'BNB', 'TON', 'DOGE'];
  }

  // Convert ruble amount to cryptocurrency amount (approximate)
  async convertRubleToCrypto(rubleAmount: number, currency: string): Promise<string> {
    // This is a simplified conversion - in production use real exchange rates
    const rates: Record<string, number> = {
      'USDT': 0.011, // 1 RUB ≈ 0.011 USDT
      'BTC': 0.00000023, // 1 RUB ≈ 0.00000023 BTC
      'ETH': 0.0000034, // 1 RUB ≈ 0.0000034 ETH
      'TON': 0.00018, // 1 RUB ≈ 0.00018 TON
      'TRX': 0.7, // 1 RUB ≈ 0.7 TRX
      'LTC': 0.000015, // 1 RUB ≈ 0.000015 LTC
      'BNB': 0.000002, // 1 RUB ≈ 0.000002 BNB
      'DOGE': 0.0028 // 1 RUB ≈ 0.0028 DOGE
    };

    const rate = rates[currency.toUpperCase()] || rates['USDT'];
    const cryptoAmount = rubleAmount * rate;
    
    // Format with appropriate decimal places
    if (currency === 'BTC') {
      return cryptoAmount.toFixed(8);
    } else if (currency === 'ETH' || currency === 'LTC' || currency === 'BNB') {
      return cryptoAmount.toFixed(6);
    } else {
      return cryptoAmount.toFixed(2);
    }
  }
}

export const cryptomusOfficialService = new CryptomusOfficialService();