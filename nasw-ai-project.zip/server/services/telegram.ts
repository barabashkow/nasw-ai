import crypto from "crypto";
import type { User, Ticket } from "@shared/schema";

class TelegramService {
  private botToken: string;
  private adminChatId: string;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || "";
    this.adminChatId = process.env.TELEGRAM_ADMIN_CHAT_ID || "";
  }

  validateWebAppData(data: any): any {
    // In development mode, allow development user data
    if (process.env.NODE_ENV === 'development') {
      // If no proper Telegram data is provided, create a development user
      if (!data.hash && !data.user) {
        return {
          id: 12345,
          username: "dev_user",
          first_name: "Development",
          last_name: "User",
          language_code: "ru"
        };
      }
      
      // If user data is provided directly (for development)
      if (data.user && typeof data.user === 'object') {
        return data.user;
      }
    }

    // Production validation
    if (!data.hash || !this.botToken) {
      return null;
    }

    try {
      const secret = crypto.createHmac('sha256', 'WebAppData').update(this.botToken).digest();
      const checkString = Object.keys(data)
        .filter(key => key !== 'hash')
        .sort()
        .map(key => `${key}=${data[key]}`)
        .join('\n');

      const hash = crypto.createHmac('sha256', secret).update(checkString).digest('hex');
      
      if (hash !== data.hash) return null;

      return JSON.parse(data.user || '{}');
    } catch (error) {
      console.error('Telegram validation error:', error);
      return null;
    }
  }

  async notifyAdmins(ticket: Ticket, user: User): Promise<void> {
    if (!this.adminChatId) return;

    const message = `
🎫 Новый тикет #${ticket.id}

👤 Пользователь: ${user.firstName} ${user.lastName} (@${user.username})
📱 Telegram ID: ${user.telegramId}
📝 Тема: ${ticket.title}
💬 Описание: ${ticket.description}
⏰ Создан: ${ticket.createdAt}
`;

    try {
      await this.sendMessage(this.adminChatId, message);
    } catch (error) {
      console.error('Failed to notify admins:', error);
    }
  }

  async sendMessage(chatId: string, text: string): Promise<void> {
    const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
      }),
    });

    if (!response.ok) {
      throw new Error(`Telegram API error: ${response.statusText}`);
    }
  }

  async checkSubscription(telegramId: string): Promise<boolean> {
    const channelId = "@Mister_nasway";
    const url = `https://api.telegram.org/bot${this.botToken}/getChatMember`;
    
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: channelId,
          user_id: telegramId,
        }),
      });

      if (!response.ok) return false;

      const data = await response.json();
      return data.result && ['member', 'administrator', 'creator'].includes(data.result.status);
    } catch (error) {
      console.error('Failed to check subscription:', error);
      return false;
    }
  }
}

export const telegramService = new TelegramService();
