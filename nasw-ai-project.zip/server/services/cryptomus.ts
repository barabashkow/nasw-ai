/**
 * Cryptomus Payment Service
 * Integration with Cryptomus for accepting cryptocurrency payments
 */

import crypto from 'crypto';
import { z } from 'zod';

interface CryptomusPayment {
  uuid: string;
  order_id: string;
  amount: string;
  currency: string;
  payer_currency: string;
  payer_amount: string;
  url: string;
  status: string;
  is_final: boolean;
  created_at: string;
  updated_at: string;
}

interface CreatePaymentRequest {
  amount: string;
  currency: string;
  order_id: string;
  url_return?: string;
  url_callback?: string;
  url_success?: string;
  url_cancel?: string;
  additional_data?: string;
  to_currency?: string;
  lifetime?: number;
}

interface CryptomusResponse {
  state: number;
  result?: CryptomusPayment;
  message?: string;
}

class CryptomusService {
  private apiKey: string;
  private merchantId: string;
  private baseUrl = 'https://api.cryptomus.com/v1';

  constructor() {
    this.apiKey = process.env.CRYPTOMUS_API_KEY || '';
    this.merchantId = process.env.CRYPTOMUS_MERCHANT_ID || '';
  }

  private generateSignature(data: any): string {
    // Remove undefined/null values and sort
    const sortedData = Object.keys(data)
      .filter(key => data[key] !== undefined && data[key] !== null)
      .sort()
      .reduce((obj: any, key) => {
        obj[key] = data[key];
        return obj;
      }, {});

    const jsonString = JSON.stringify(sortedData);
    const base64 = Buffer.from(jsonString).toString('base64');
    
    return crypto
      .createHash('md5')
      .update(base64 + this.apiKey)
      .digest('hex');
  }

  async createPayment(params: CreatePaymentRequest): Promise<{ success: boolean; data?: CryptomusPayment; error?: string }> {
    try {
      if (!this.apiKey || !this.merchantId) {
        return { success: false, error: 'Cryptomus credentials not configured' };
      }

      const data: any = {
        amount: params.amount,
        currency: params.currency,
        order_id: params.order_id
      };

      // Add optional fields only if they exist
      if (params.url_return) data.url_return = params.url_return;
      if (params.url_callback) data.url_callback = params.url_callback;
      if (params.url_success) data.url_success = params.url_success;
      if (params.url_cancel) data.url_cancel = params.url_cancel;
      if (params.lifetime) data.lifetime = params.lifetime;
      if (params.to_currency) data.to_currency = params.to_currency;
      if (params.additional_data) data.additional_data = params.additional_data;

      const signature = this.generateSignature(data);

      const response = await fetch(`${this.baseUrl}/payment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'merchant': this.merchantId,
          'sign': signature
        },
        body: JSON.stringify(data)
      });

      const result: CryptomusResponse = await response.json();

      if (result.state === 0 && result.result) {
        return { success: true, data: result.result };
      } else {
        return { success: false, error: result.message || 'Payment creation failed' };
      }
    } catch (error: any) {
      console.error('Cryptomus payment error:', error);
      return { success: false, error: error.message };
    }
  }

  async getPaymentInfo(uuid: string): Promise<{ success: boolean; data?: CryptomusPayment; error?: string }> {
    try {
      const data = { uuid };
      const signature = this.generateSignature(data);

      const response = await fetch(`${this.baseUrl}/payment/info`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'merchant': this.merchantId,
          'sign': signature
        },
        body: JSON.stringify(data)
      });

      const result: CryptomusResponse = await response.json();

      if (result.state === 0 && result.result) {
        return { success: true, data: result.result };
      } else {
        return { success: false, error: result.message || 'Failed to get payment info' };
      }
    } catch (error: any) {
      console.error('Cryptomus get payment error:', error);
      return { success: false, error: error.message };
    }
  }

  validateWebhook(body: any, signature: string): boolean {
    const calculatedSignature = this.generateSignature(body);
    return calculatedSignature === signature;
  }

  getPaymentPackages() {
    return [
      { tokens: 10, rubles: 100, dollars: 1.5, tenge: 700, bonus: 0 },
      { tokens: 50, rubles: 450, dollars: 7, tenge: 3150, bonus: 5 },
      { tokens: 100, rubles: 800, dollars: 12, tenge: 5600, bonus: 20 },
      { tokens: 500, rubles: 3500, dollars: 50, tenge: 24500, bonus: 100 }
    ];
  }

  async getCryptoRates(): Promise<{ [key: string]: number }> {
    // This would fetch real-time crypto rates from Cryptomus API
    // For now, return mock rates
    return {
      'BTC': 65000,
      'ETH': 3500,
      'USDT': 1,
      'USDC': 1,
      'BNB': 600,
      'SOL': 150,
      'TRX': 0.15,
      'LTC': 110,
      'DOGE': 0.12,
      'TON': 5.5
    };
  }

  async convertRubleToCrypto(rubleAmount: number, currency: string): Promise<string> {
    const rates = await this.getCryptoRates();
    const usdAmount = rubleAmount / 100; // Approximate RUB to USD
    const cryptoRate = rates[currency] || 1;
    const cryptoAmount = usdAmount / cryptoRate;
    return cryptoAmount.toFixed(8);
  }

  getSupportedCurrencies(): string[] {
    return ['BTC', 'ETH', 'USDT', 'USDC', 'BNB', 'SOL', 'TRX', 'LTC', 'DOGE', 'TON'];
  }
}

export const cryptomusService = new CryptomusService();