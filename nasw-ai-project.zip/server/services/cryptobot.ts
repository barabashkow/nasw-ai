/**
 * CryptoBot Payment Service
 * Интеграция с CryptoBot для приема криптоплатежей в Telegram
 */

interface CryptoBotPayment {
  invoice_id: number;
  status: 'active' | 'paid' | 'expired';
  hash: string;
  currency_type: string;
  asset: string;
  amount: string;
  pay_url: string;
  created_at: string;
  allow_comments: boolean;
  allow_anonymous: boolean;
  description: string;
}

interface CreateInvoiceRequest {
  asset: string;
  amount: number;
  description?: string;
  hidden_message?: string;
  paid_btn_name?: 'viewItem' | 'openChannel' | 'openBot' | 'callback';
  paid_btn_url?: string;
  payload?: string;
  allow_comments?: boolean;
  allow_anonymous?: boolean;
  expires_in?: number;
}

class CryptoBotService {
  private apiToken: string;
  private baseUrl = 'https://pay.crypt.bot/api';

  constructor() {
    this.apiToken = process.env.CRYPTOBOT_TOKEN || '';
    if (!this.apiToken) {
      console.warn('CRYPTOBOT_TOKEN not set');
    }
  }

  async createInvoice(params: CreateInvoiceRequest): Promise<{ success: boolean; data?: CryptoBotPayment; error?: string }> {
    try {
      if (!this.apiToken) {
        return { success: false, error: 'CryptoBot API token not configured' };
      }

      const response = await fetch(`${this.baseUrl}/createInvoice`, {
        method: 'POST',
        headers: {
          'Crypto-Pay-API-Token': this.apiToken,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params)
      });

      const result = await response.json();

      if (result.ok && result.result) {
        return { success: true, data: result.result };
      } else {
        return { success: false, error: result.error?.name || 'Payment creation failed' };
      }
    } catch (error) {
      console.error('CryptoBot API error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async getInvoice(invoiceId: number): Promise<{ success: boolean; data?: CryptoBotPayment; error?: string }> {
    try {
      if (!this.apiToken) {
        return { success: false, error: 'CryptoBot API token not configured' };
      }

      const response = await fetch(`${this.baseUrl}/getInvoices?invoice_ids=${invoiceId}`, {
        headers: {
          'Crypto-Pay-API-Token': this.apiToken,
        }
      });

      const result = await response.json();

      if (result.ok && result.result.items.length > 0) {
        return { success: true, data: result.result.items[0] };
      } else {
        return { success: false, error: 'Invoice not found' };
      }
    } catch (error) {
      console.error('CryptoBot API error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async getBalance(): Promise<{ success: boolean; data?: any; error?: string }> {
    try {
      if (!this.apiToken) {
        return { success: false, error: 'CryptoBot API token not configured' };
      }

      const response = await fetch(`${this.baseUrl}/getBalance`, {
        headers: {
          'Crypto-Pay-API-Token': this.apiToken,
        }
      });

      const result = await response.json();

      if (result.ok) {
        return { success: true, data: result.result };
      } else {
        return { success: false, error: result.error?.name || 'Failed to get balance' };
      }
    } catch (error) {
      console.error('CryptoBot API error:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  validateWebhook(body: any, signature: string): boolean {
    // Implement webhook signature validation
    // For now, return true for development
    return true;
  }

  // Convert package price to crypto amount
  getCryptoAmount(rubleAmount: number, asset: string = 'USDT'): number {
    // Simplified conversion rates - in production use real-time rates
    const rates: Record<string, number> = {
      'USDT': rubleAmount / 95, // ~95 RUB per USDT
      'TON': rubleAmount / 200, // ~200 RUB per TON
      'BTC': rubleAmount / 9500000, // ~9.5M RUB per BTC
      'ETH': rubleAmount / 350000, // ~350K RUB per ETH
    };

    return Math.round((rates[asset] || rates['USDT']) * 100) / 100;
  }

  getAvailableAssets(): string[] {
    return ['USDT', 'TON', 'BTC', 'ETH', 'LTC', 'BNB', 'TRX'];
  }
}

export const cryptoBotService = new CryptoBotService();