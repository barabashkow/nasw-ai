class N8NService {
  private videoWebhookUrl: string;
  private balanceWebhookUrl: string;
  private topupWebhookUrl: string;

  constructor() {
    this.videoWebhookUrl = "https://nasway.app.n8n.cloud/webhook-test/f839c50e-d6d0-4929-9b7a-d926a6339074";
    this.balanceWebhookUrl = "https://nasway.app.n8n.cloud/webhook/balance";
    this.topupWebhookUrl = "https://nasway.app.n8n.cloud/webhook/topup";
  }

  async generateVideo(prompt: string, style?: string): Promise<{ success: boolean; data?: any; error?: string }> {
    try {
      const response = await fetch(this.videoWebhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt,
          style,
          timestamp: Date.now(),
        }),
      });

      if (!response.ok) {
        throw new Error(`N8N webhook error: ${response.statusText}`);
      }

      const data = await response.json();
      return {
        success: true,
        data: {
          videoUrl: data.video_url,
          thumbnailUrl: data.thumbnail_url,
          duration: data.duration,
          status: data.status,
        }
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async checkBalance(telegramId: string): Promise<{ success: boolean; balance?: number; error?: string }> {
    try {
      const response = await fetch(this.balanceWebhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          telegram_id: telegramId,
          action: "check_balance",
        }),
      });

      if (!response.ok) {
        throw new Error(`N8N balance check error: ${response.statusText}`);
      }

      const data = await response.json();
      return {
        success: true,
        balance: data.balance,
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async processTopup(telegramId: string, amount: number): Promise<{ success: boolean; paymentUrl?: string; transactionId?: string; error?: string }> {
    try {
      const response = await fetch(this.topupWebhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          telegram_id: telegramId,
          amount,
          currency: "RUB",
          timestamp: Date.now(),
        }),
      });

      if (!response.ok) {
        throw new Error(`N8N topup error: ${response.statusText}`);
      }

      const data = await response.json();
      return {
        success: true,
        paymentUrl: data.payment_url,
        transactionId: data.transaction_id,
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}

export const n8nService = new N8NService();
