/**
 * Telegram Bot Handler - Redesigned according to technical requirements
 * No emojis, exact structure as specified
 */

import { storage } from "./storage";
import { cryptomusService } from "./services/cryptomus";

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const WEBAPP_URL = 'https://telegram-video-bot-opteinnity.replit.app/';

interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    from: {
      id: number;
      is_bot: boolean;
      first_name: string;
      username?: string;
      language_code?: string;
    };
    chat: {
      id: number;
      first_name: string;
      username?: string;
      type: string;
    };
    date: number;
    text?: string;
    dice?: {
      emoji: string;
      value: number;
    };
  };
  callback_query?: {
    id: string;
    from: {
      id: number;
      first_name: string;
      username?: string;
    };
    message: {
      message_id: number;
      chat: {
        id: number;
      };
    };
    data: string;
  };
}

export class TelegramBot {
  private botToken: string;
  private userLanguages: Map<number, string> = new Map();
  private userDiceGames: Map<number, { guess: number; messageId: number }> = new Map();
  private userDiceCooldowns: Map<number, number> = new Map();

  constructor() {
    this.botToken = TELEGRAM_BOT_TOKEN || '';
  }

  async sendMessage(chatId: number, text: string, extra: any = {}) {
    const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
        ...extra
      }),
    });

    return response.json();
  }

  async handleUpdate(update: TelegramUpdate) {
    try {
      // Handle callback queries
      if (update.callback_query) {
        await this.handleCallbackQuery(update.callback_query);
        return;
      }

      // Handle dice messages
      if (update.message?.dice) {
        await this.handleDiceResult(update.message);
        return;
      }

      // Handle text messages
      if (!update.message?.text) {
        return;
      }

      const { message } = update;
      const chatId = message.chat.id;
      const text = message.text;
      const firstName = message.from.first_name;
      const userId = message.from.id;

      console.log(`Получено сообщение от ${firstName} (${chatId}): ${text}`);

      if (text.startsWith('/start')) {
        await this.handleStartCommand(chatId, firstName, userId);
      } else {
        await this.handleDefaultMessage(chatId, firstName);
      }
    } catch (error) {
      console.error('Error handling update:', error);
    }
  }

  // STEP 1: /start command shows language selection
  private async handleStartCommand(chatId: number, firstName: string, userId: number) {
    await this.showLanguageSelection(chatId);
  }

  private async showLanguageSelection(chatId: number) {
    const text = `Выберите язык / Choose language`;

    await this.sendMessage(chatId, text, {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Русский', callback_data: 'lang_ru' },
            { text: 'English', callback_data: 'lang_en' },
            { text: 'Қазақша', callback_data: 'lang_kz' }
          ]
        ]
      }
    });
  }

  private async handleCallbackQuery(callbackQuery: any) {
    const chatId = callbackQuery.message.chat.id;
    const userId = callbackQuery.from.id;
    const data = callbackQuery.data;
    const firstName = callbackQuery.from.first_name;

    // Answer callback query
    await this.answerCallbackQuery(callbackQuery.id);

    if (data.startsWith('lang_')) {
      const language = data.split('_')[1];
      this.userLanguages.set(userId, language);
      
      // Save to database
      await storage.updateUserLanguage(userId.toString(), language);
      
      // Delete language selection message
      await this.deleteMessage(chatId, callbackQuery.message.message_id);
      
      // STEP 2: Show main interface with welcome text
      await this.showMainInterface(chatId, firstName, userId, language);
    } else if (data === 'select_language') {
      await this.showLanguageSelection(chatId);
    } else if (data === 'free_generation') {
      await this.handleFreeGeneration(chatId, userId);
    } else if (data === 'about_bot') {
      await this.showAboutBot(chatId, userId);
    } else if (data.startsWith('dice_')) {
      const guess = parseInt(data.split('_')[1]);
      await this.handleDiceGuess(chatId, guess, userId);
    } else if (data === 'back_to_menu') {
      const language = this.userLanguages.get(userId) || 'ru';
      await this.showMainInterface(chatId, firstName, userId, language);
    }
  }

  // STEP 2: Welcome message with exact text as specified
  private async showMainInterface(chatId: number, firstName: string, userId: number, language: string) {
    const texts = {
      ru: `Добро пожаловать в NASW AI

NASW AI — это интеллектуальная платформа нового поколения для генерации мультимедийного контента с помощью искусственного интеллекта.

Доступные возможности:
— Генерация видео с помощью Veo 3 от Google
— Создание изображений по текстовому описанию
— Генерация собственой музыки
— Личный кабинет с галереей всех созданных работ
— Поддержка 24/7 и удобное пополнение баланса`,
      en: `Welcome to NASW AI

NASW AI is a next-generation intelligent platform for generating multimedia content using artificial intelligence.

Available features:
— Video generation using Veo 3 from Google
— Image creation from text descriptions
— Custom music generation
— Personal cabinet with gallery of all created works
— 24/7 support and convenient balance top-up`,
      kz: `NASW AI-ге қош келдіңіз

NASW AI — жасанды интеллект көмегімен мультимедиа мазмұнын генерациялау үшін жаңа буын интеллектуалды платформасы.

Қолжетімді мүмкіндіктер:
— Google-дің Veo 3 көмегімен бейне генерациясы
— Мәтіндік сипаттамадан кескін жасау
— Өзіндік музыка генерациясы
— Барлық жасалған жұмыстардың галереясы бар жеке кабинет
— 24/7 қолдау және ыңғайлы баланс толықтыру`
    };

    // STEP 3: 4 buttons as specified - no top-up button (moved to WebApp)
    const buttons = {
      ru: [
        [{ text: 'Генерировать', web_app: { url: WEBAPP_URL } }],
        [{ text: 'Язык', callback_data: 'select_language' }],
        [{ text: 'Бесплатная генерация', callback_data: 'free_generation' }],
        [{ text: 'О боте', callback_data: 'about_bot' }]
      ],
      en: [
        [{ text: 'Generate', web_app: { url: WEBAPP_URL } }],
        [{ text: 'Language', callback_data: 'select_language' }],
        [{ text: 'Free generation', callback_data: 'free_generation' }],
        [{ text: 'About bot', callback_data: 'about_bot' }]
      ],
      kz: [
        [{ text: 'Генерациялау', web_app: { url: WEBAPP_URL } }],
        [{ text: 'Тіл', callback_data: 'select_language' }],
        [{ text: 'Тегін генерация', callback_data: 'free_generation' }],
        [{ text: 'Бот туралы', callback_data: 'about_bot' }]
      ]
    };

    await this.sendMessage(chatId, texts[language as keyof typeof texts], {
      reply_markup: {
        inline_keyboard: buttons[language as keyof typeof buttons]
      }
    });
  }

  // Button 4: О боте - show about information
  private async showAboutBot(chatId: number, userId: number) {
    const language = this.userLanguages.get(userId) || 'ru';
    
    const texts = {
      ru: `NASW AI — интеллектуальная платформа нового поколения для генерации мультимедийного контента. Генерация видео с помощью Veo 3, изображений по тексту, музыки через Sora API, галерея и баланс`,
      en: `NASW AI is a next-generation intelligent platform for multimedia content generation. Video generation with Veo 3, text-to-image, music via Sora API, gallery and balance`,
      kz: `NASW AI — мультимедиа мазмұнын генерациялау үшін жаңа буын интеллектуалды платформа. Veo 3 арқылы бейне генерациясы, мәтіннен сурет, Sora API арқылы музыка, галерея және баланс`
    };

    await this.sendMessage(chatId, texts[language as keyof typeof texts], {
      reply_markup: {
        inline_keyboard: [
          [{ text: language === 'ru' ? 'Назад' : language === 'en' ? 'Back' : 'Артқа', callback_data: 'back_to_menu' }]
        ]
      }
    });
  }

  // Button 3: Бесплатная генерация - dice game with inline buttons
  private async handleFreeGeneration(chatId: number, userId: number) {
    const language = this.userLanguages.get(userId) || 'ru';
    const now = Date.now();
    const cooldownEnd = this.userDiceCooldowns.get(userId) || 0;

    // Check 24-hour cooldown
    if (now < cooldownEnd) {
      const remainingHours = Math.ceil((cooldownEnd - now) / (1000 * 60 * 60));
      const cooldownTexts = {
        ru: `Не повезло, попытку можно повторить через ${remainingHours} часов`,
        en: `Bad luck, you can try again in ${remainingHours} hours`,
        kz: `Сәтсіздік, ${remainingHours} сағаттан кейін қайталауға болады`
      };
      
      await this.sendMessage(chatId, cooldownTexts[language as keyof typeof cooldownTexts], {
        reply_markup: {
          inline_keyboard: [
            [{ text: language === 'ru' ? 'Назад' : language === 'en' ? 'Back' : 'Артқа', callback_data: 'back_to_menu' }]
          ]
        }
      });
      return;
    }

    const texts = {
      ru: `Выберите число от 1 до 6:`,
      en: `Choose a number from 1 to 6:`,
      kz: `1-ден 6-ға дейін санды таңдаңыз:`
    };

    // Show inline number buttons
    await this.sendMessage(chatId, texts[language as keyof typeof texts], {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '1', callback_data: 'dice_1' },
            { text: '2', callback_data: 'dice_2' },
            { text: '3', callback_data: 'dice_3' }
          ],
          [
            { text: '4', callback_data: 'dice_4' },
            { text: '5', callback_data: 'dice_5' },
            { text: '6', callback_data: 'dice_6' }
          ]
        ]
      }
    });
  }

  private async handleDiceGuess(chatId: number, guess: number, userId: number) {
    const language = this.userLanguages.get(userId) || 'ru';
    
    // Show user choice first
    const choiceTexts = {
      ru: `Вы выбрали: ${guess}`,
      en: `You chose: ${guess}`,
      kz: `Сіз таңдадыңыз: ${guess}`
    };

    await this.sendMessage(chatId, choiceTexts[language as keyof typeof choiceTexts]);
    
    // Send Telegram dice
    const diceMessage = await this.sendDice(chatId);
    
    // Store the game to handle result
    this.userDiceGames.set(userId, { 
      guess, 
      messageId: diceMessage.result.message_id 
    });
  }

  private async handleDiceResult(message: any) {
    const userId = message.from.id;
    const chatId = message.chat.id;
    const diceValue = message.dice.value;
    const language = this.userLanguages.get(userId) || 'ru';
    
    const game = this.userDiceGames.get(userId);
    if (!game) return;

    this.userDiceGames.delete(userId);
    
    // Show dice result
    const resultTexts = {
      ru: `Выпало: ${diceValue}`,
      en: `Rolled: ${diceValue}`,
      kz: `Шықты: ${diceValue}`
    };

    await this.sendMessage(chatId, resultTexts[language as keyof typeof resultTexts]);
    
    // Determine win/lose
    const isWin = game.guess === diceValue;
    
    if (isWin) {
      const winTexts = {
        ru: `Поздравляем! Вам начислена бесплатная генерация`,
        en: `Congratulations! You received a free generation`,
        kz: `Құттықтаймыз! Сізге тегін генерация берілді`
      };

      await this.sendMessage(chatId, winTexts[language as keyof typeof winTexts], {
        reply_markup: {
          inline_keyboard: [
            [{ text: language === 'ru' ? 'Назад' : language === 'en' ? 'Back' : 'Артқа', callback_data: 'back_to_menu' }]
          ]
        }
      });
      
      // TODO: Add 1 credit to user balance in database
      
    } else {
      // Set 24-hour cooldown
      const cooldownEnd = Date.now() + (24 * 60 * 60 * 1000);
      this.userDiceCooldowns.set(userId, cooldownEnd);

      const loseTexts = {
        ru: `Не повезло, попытку можно повторить через 24 часа`,
        en: `Bad luck, you can try again in 24 hours`,
        kz: `Сәтсіздік, 24 сағаттан кейін қайталауға болады`
      };

      await this.sendMessage(chatId, loseTexts[language as keyof typeof loseTexts], {
        reply_markup: {
          inline_keyboard: [
            [{ text: language === 'ru' ? 'Назад' : language === 'en' ? 'Back' : 'Артқа', callback_data: 'back_to_menu' }]
          ]
        }
      });
    }
  }

  private async sendDice(chatId: number) {
    const url = `https://api.telegram.org/bot${this.botToken}/sendDice`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        emoji: '🎲'
      })
    });
    return response.json();
  }

  private async answerCallbackQuery(callbackQueryId: string, text?: string) {
    const url = `https://api.telegram.org/bot${this.botToken}/answerCallbackQuery`;
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        callback_query_id: callbackQueryId,
        text,
        show_alert: true
      })
    });
  }

  private async deleteMessage(chatId: number, messageId: number) {
    const url = `https://api.telegram.org/bot${this.botToken}/deleteMessage`;
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId
      })
    });
  }


      const paymentResult = await cryptomusService.createPayment({
        amount: amount.toString(),
        currency: 'RUB',
        order_id: orderId,
        url_callback: `${WEBAPP_URL}webhook/cryptomus`,
        additional_data: JSON.stringify({
          userId,
          bonus: selectedPackage.bonus,
          language
        })
      });

      if (!paymentResult.success || !paymentResult.data) {
        throw new Error(paymentResult.error || 'Payment creation failed');
      }

      // Save transaction to database
      await storage.createBalanceTransaction({
        userId: parseInt(userId.toString()),
        type: 'topup',
        amount: selectedPackage.totalCredits,
        currency: 'RUB',
        cryptoAmount: amount.toString(),
        cryptoCurrency: 'RUB',
        bonus: selectedPackage.bonus,
        paymentUuid: paymentResult.data.uuid,
        status: 'pending',
        description: `Top-up balance: ${amount} RUB + ${selectedPackage.bonus} bonus`,
        transactionId: orderId
      });

      const texts = {
        ru: `Пополнение на ${amount} ₽ ${selectedPackage.bonus > 0 ? `(+${selectedPackage.bonus} бонус)` : ''}

Нажмите кнопку ниже для оплаты:`,
        en: `Top-up for ${amount} ₽ ${selectedPackage.bonus > 0 ? `(+${selectedPackage.bonus} bonus)` : ''}

Click the button below to pay:`,
        kz: `${amount} ₽ толықтыру ${selectedPackage.bonus > 0 ? `(+${selectedPackage.bonus} бонус)` : ''}

Төлем үшін төмендегі батырманы басыңыз:`
      };

      await this.sendMessage(chatId, texts[language as keyof typeof texts], {
        reply_markup: {
          inline_keyboard: [
            [{
              text: language === 'ru' ? 'Оплатить' : language === 'en' ? 'Pay' : 'Төлеу',
              url: paymentResult.data.url
            }],
            [{
              text: language === 'ru' ? 'Назад' : language === 'en' ? 'Back' : 'Артқа',
              callback_data: 'back_to_menu'
            }]
          ]
        }
      });

    } catch (error: any) {
      console.error('Top-up error:', error);
      
      const errorTexts = {
        ru: `Ошибка создания платежа. Попробуйте позже.`,
        en: `Payment creation error. Try again later.`,
        kz: `Төлем жасау қатесі. Кейінірек қайталаңыз.`
      };

      await this.sendMessage(chatId, errorTexts[language as keyof typeof errorTexts], {
        reply_markup: {
          inline_keyboard: [
            [{
              text: language === 'ru' ? 'Назад' : language === 'en' ? 'Back' : 'Артқа',
              callback_data: 'back_to_menu'
            }]
          ]
        }
      });
    }
  }

  async notifySuccessfulPayment(userId: number, amount: number, currency: string, bonus: number) {
    const language = this.userLanguages.get(userId) || 'ru';
    
    const texts = {
      ru: `Баланс успешно пополнен на ${amount} ${currency}. Бонус: +${bonus}`,
      en: `Balance successfully topped up by ${amount} ${currency}. Bonus: +${bonus}`,
      kz: `Баланс сәтті толықтырылды ${amount} ${currency}. Бонус: +${bonus}`
    };

    await this.sendMessage(userId, texts[language as keyof typeof texts], {
      reply_markup: {
        inline_keyboard: [
          [{
            text: language === 'ru' ? 'Главное меню' : language === 'en' ? 'Main menu' : 'Басты мәзір',
            callback_data: 'back_to_menu'
          }]
        ]
      }
    });
  }

  private async handleDefaultMessage(chatId: number, firstName: string) {
    const texts = {
      ru: `Используйте команду /start для начала работы с ботом.`,
      en: `Use /start command to begin working with the bot.`,
      kz: `Ботпен жұмысты бастау үшін /start командасын пайдаланыңыз.`
    };

    await this.sendMessage(chatId, texts.ru);
  }
}

export const telegramBot = new TelegramBot();