/**
 * Telegram Bot Handler - Clean version without payment functionality
 * All payments moved to WebApp only
 */

import { storage } from './storage';

const WEBAPP_URL = 'https://t.me/nasw_AI_bot/myapp';

interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    from: {
      id: number;
      is_bot: boolean;
      first_name: string;
      username?: string;
      language_code?: string;
    };
    chat: {
      id: number;
      first_name: string;
      username?: string;
      type: string;
    };
    date: number;
    text?: string;
    dice?: {
      emoji: string;
      value: number;
    };
  };
  callback_query?: {
    id: string;
    from: {
      id: number;
      first_name: string;
      username?: string;
    };
    message: {
      message_id: number;
      chat: {
        id: number;
      };
    };
    data: string;
  };
}

export class TelegramBot {
  private botToken: string;
  private userLanguages: Map<number, string> = new Map();
  private userDiceGames: Map<number, { guess: number; messageId: number }> = new Map();
  private userDiceCooldowns: Map<number, number> = new Map();

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN!;
    if (!this.botToken) {
      throw new Error('TELEGRAM_BOT_TOKEN is required');
    }
  }

  async sendMessage(chatId: number, text: string, extra: any = {}) {
    const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
        ...extra
      })
    });
    return response.json();
  }

  async handleUpdate(update: TelegramUpdate) {
    try {
      if (update.message?.text?.startsWith('/start')) {
        // Extract referral code if present
        const text = update.message.text;
        const parts = text.split(' ');
        const referralCode = parts.length > 1 ? parts[1] : null;
        
        await this.handleStartCommand(
          update.message.chat.id,
          update.message.from.first_name,
          update.message.from.id,
          referralCode
        );
      } else if (update.message?.dice) {
        await this.handleDiceResult(update.message);
      } else if (update.callback_query) {
        await this.handleCallbackQuery(update.callback_query);
      } else if (update.message?.text) {
        await this.handleDefaultMessage(update.message.chat.id, update.message.from.first_name);
      }
    } catch (error) {
      console.error('Bot error:', error);
    }
  }

  // STEP 1: /start command shows language selection only
  private async handleStartCommand(chatId: number, firstName: string, userId: number, referralCode?: string | null) {
    // Create or get user from database
    let user = await storage.getUserByTelegramId(userId.toString());
    const isNewUser = !user;
    
    if (!user) {
      try {
        user = await storage.createUser({
          telegramId: userId.toString(),
          username: firstName,
          languageCode: 'ru',
          balance: 0,
          tokens: 0
        });
      } catch (error) {
        console.error('Error creating user:', error);
      }
    }

    // Handle referral if it's a new user and referral code is provided
    if (isNewUser && referralCode && user) {
      try {
        // Check if referrer exists
        const referrer = await storage.getUserByTelegramId(referralCode);
        if (referrer && referrer.telegramId !== userId.toString()) {
          // Update referrer's stats
          await storage.updateUser(referralCode, {
            referralCount: (referrer.referralCount || 0) + 1,
            referralEarnings: (referrer.referralEarnings || 0) + 1, // 1 token per referral
            tokens: (referrer.tokens || 0) + 1 // Give referrer 1 token bonus
          });
          
          // Give new user bonus tokens
          await storage.updateUserBalance(userId.toString(), (user.tokens || 0) + 3); // 3 tokens bonus for joining via referral
          
          console.log(`Referral processed: ${userId} referred by ${referralCode}`);
        }
      } catch (error) {
        console.error('Error processing referral:', error);
      }
    }

    // Always show language selection first
    await this.showLanguageSelection(chatId);
  }

  private async showLanguageSelection(chatId: number) {
    const text = `Выберите язык/Choose language`;

    await this.sendMessage(chatId, text, {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Русский', callback_data: 'lang_ru' },
            { text: 'English', callback_data: 'lang_en' },
            { text: 'Қазақша', callback_data: 'lang_kz' }
          ]
        ]
      }
    });
  }

  private async handleCallbackQuery(callbackQuery: any) {
    const chatId = callbackQuery.message.chat.id;
    const userId = callbackQuery.from.id;
    const data = callbackQuery.data;
    const firstName = callbackQuery.from.first_name;

    // Answer callback query
    await this.answerCallbackQuery(callbackQuery.id);

    if (data.startsWith('lang_')) {
      const language = data.split('_')[1];
      this.userLanguages.set(userId, language);
      
      // Save to database
      await storage.updateUserLanguage(userId.toString(), language);
      
      // Delete language selection message
      await this.deleteMessage(chatId, callbackQuery.message.message_id);
      
      // Show main interface
      await this.showMainInterface(chatId, firstName, userId, language);
    } else if (data === 'about_bot') {
      await this.showAboutBot(chatId, userId);
    }
  }

  // Main interface with 2 buttons: Generate and About bot
  private async showMainInterface(chatId: number, firstName: string, userId: number, language: string) {
    // Welcome message with username
    const texts = {
      ru: `Добро пожаловать, ${firstName}!`,
      en: `Welcome, ${firstName}!`,
      kz: `Қош келдіңіз, ${firstName}!`
    };

    // Only 2 buttons as specified
    const buttons = {
      ru: [
        [{ text: 'Сгенерировать', web_app: { url: WEBAPP_URL } }],
        [{ text: 'О боте', callback_data: 'about_bot' }]
      ],
      en: [
        [{ text: 'Generate', web_app: { url: WEBAPP_URL } }],
        [{ text: 'About bot', callback_data: 'about_bot' }]
      ],
      kz: [
        [{ text: 'Генерациялау', web_app: { url: WEBAPP_URL } }],
        [{ text: 'Бот туралы', callback_data: 'about_bot' }]
      ]
    };

    await this.sendMessage(chatId, texts[language as keyof typeof texts], {
      reply_markup: {
        inline_keyboard: buttons[language as keyof typeof buttons]
      }
    });
  }

  private async showAboutBot(chatId: number, userId: number) {
    const language = this.userLanguages.get(userId) || 'ru';
    
    const texts = {
      ru: `NASW AI — это интеллектуальная платформа нового поколения для генерации мультимедийного контента с помощью искусственного интеллекта.

— Генерация видео с помощью Veo 3 от Google
— Создание изображений по текстовому описанию
— Генерация собственной музыки и голосов
— Личный кабинет с галереей всех созданных работ
— Поддержка 24/7 и удобное пополнение баланса`,
      en: `NASW AI is a next-generation intelligent platform for generating multimedia content using artificial intelligence.

— Video generation using Veo 3 from Google
— Image creation from text descriptions
— Custom music and voice generation
— Personal cabinet with gallery of all created works
— 24/7 support and convenient balance top-up`,
      kz: `NASW AI — жасанды интеллект көмегімен мультимедиа мазмұнын генерациялау үшін жаңа буын интеллектуалды платформасы.

— Google-дің Veo 3 көмегімен бейне генерациясы
— Мәтіндік сипаттамадан кескін жасау
— Өзіндік музыка және дауыс генерациясы
— Барлық жасалған жұмыстардың галереясы бар жеке кабинет
— 24/7 қолдау және ыңғайлы баланс толықтыру`
    };

    await this.sendMessage(chatId, texts[language as keyof typeof texts], {
      reply_markup: {
        inline_keyboard: [
          [{ text: language === 'ru' ? 'Сгенерировать' : language === 'en' ? 'Generate' : 'Генерациялау', web_app: { url: WEBAPP_URL } }]
        ]
      }
    });
  }

  private async handleFreeGeneration(chatId: number, userId: number) {
    const language = this.userLanguages.get(userId) || 'ru';
    const now = Date.now();
    const cooldownEnd = this.userDiceCooldowns.get(userId) || 0;

    // Check 24-hour cooldown
    if (now < cooldownEnd) {
      const remainingHours = Math.ceil((cooldownEnd - now) / (1000 * 60 * 60));
      
      const cooldownTexts = {
        ru: `Следующую попытку можно сделать через ${remainingHours} часов`,
        en: `Next attempt available in ${remainingHours} hours`,
        kz: `Келесі әрекет ${remainingHours} сағаттан кейін қолжетімді`
      };

      // Show alert
      await this.answerCallbackQuery('', cooldownTexts[language as keyof typeof cooldownTexts]);
      return;
    }

    const texts = {
      ru: `Угадайте число от 1 до 6. Если угадаете результат кубика, получите бесплатную генерацию!`,
      en: `Guess a number from 1 to 6. If you guess the dice result, you get a free generation!`,
      kz: `1-ден 6-ға дейін санды болжаңыз. Кубик нәтижесін болжасаңыз, тегін генерация аласыз!`
    };

    const buttons = [];
    for (let i = 1; i <= 6; i++) {
      buttons.push([{ text: i.toString(), callback_data: `dice_${i}` }]);
    }
    buttons.push([{ text: language === 'ru' ? 'Назад' : language === 'en' ? 'Back' : 'Артқа', callback_data: 'back_to_menu' }]);

    await this.sendMessage(chatId, texts[language as keyof typeof texts], {
      reply_markup: { inline_keyboard: buttons }
    });
  }

  private async handleDiceGuess(chatId: number, guess: number, userId: number) {
    const language = this.userLanguages.get(userId) || 'ru';

    const diceMessage = await this.sendDice(chatId);
    
    // Store guess for later comparison
    this.userDiceGames.set(userId, { 
      guess, 
      messageId: diceMessage.result.message_id 
    });
  }

  private async handleDiceResult(message: any) {
    const userId = message.from.id;
    const chatId = message.chat.id;
    const diceValue = message.dice.value;
    const language = this.userLanguages.get(userId) || 'ru';
    
    const game = this.userDiceGames.get(userId);
    if (!game) return;

    this.userDiceGames.delete(userId);
    
    // Show dice result
    const resultTexts = {
      ru: `Выпало: ${diceValue}`,
      en: `Rolled: ${diceValue}`,
      kz: `Шықты: ${diceValue}`
    };

    await this.sendMessage(chatId, resultTexts[language as keyof typeof resultTexts]);
    
    // Determine win/lose
    const isWin = game.guess === diceValue;
    
    if (isWin) {
      const winTexts = {
        ru: `Поздравляем! Вам начислена бесплатная генерация`,
        en: `Congratulations! You received a free generation`,
        kz: `Құттықтаймыз! Сізге тегін генерация берілді`
      };

      await this.sendMessage(chatId, winTexts[language as keyof typeof winTexts], {
        reply_markup: {
          inline_keyboard: [
            [{ text: language === 'ru' ? 'Назад' : language === 'en' ? 'Back' : 'Артқа', callback_data: 'back_to_menu' }]
          ]
        }
      });
      
      // Add 1 credit to user balance
      try {
        await storage.updateUserBalance(userId.toString(), 1);
      } catch (error) {
        console.error('Error updating balance:', error);
      }
      
    } else {
      // Set 24-hour cooldown
      const cooldownEnd = Date.now() + (24 * 60 * 60 * 1000);
      this.userDiceCooldowns.set(userId, cooldownEnd);

      const loseTexts = {
        ru: `Не повезло, попытку можно повторить через 24 часа`,
        en: `Bad luck, you can try again in 24 hours`,
        kz: `Сәтсіздік, 24 сағаттан кейін қайталауға болады`
      };

      await this.sendMessage(chatId, loseTexts[language as keyof typeof loseTexts], {
        reply_markup: {
          inline_keyboard: [
            [{ text: language === 'ru' ? 'Назад' : language === 'en' ? 'Back' : 'Артқа', callback_data: 'back_to_menu' }]
          ]
        }
      });
    }
  }

  private async sendDice(chatId: number) {
    const url = `https://api.telegram.org/bot${this.botToken}/sendDice`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        emoji: '🎲'
      })
    });
    return response.json();
  }

  private async answerCallbackQuery(callbackQueryId: string, text?: string) {
    const url = `https://api.telegram.org/bot${this.botToken}/answerCallbackQuery`;
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        callback_query_id: callbackQueryId,
        text,
        show_alert: true
      })
    });
  }

  private async deleteMessage(chatId: number, messageId: number) {
    const url = `https://api.telegram.org/bot${this.botToken}/deleteMessage`;
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId
      })
    });
  }

  private async handleDefaultMessage(chatId: number, firstName: string) {
    const texts = {
      ru: `Используйте команду /start для начала работы с ботом.`,
      en: `Use /start command to begin working with the bot.`,
      kz: `Ботпен жұмысты бастау үшін /start командасын пайдаланыңыз.`
    };

    await this.sendMessage(chatId, texts.ru);
  }
}

export const telegramBot = new TelegramBot();